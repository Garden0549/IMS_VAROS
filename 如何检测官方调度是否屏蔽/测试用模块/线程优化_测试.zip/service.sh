wait_sys_boot_completed() {
	local i=9
	until [ "$(getprop sys.boot_completed)" == "1" ] || [ $i -le 0 ]; do
		i=$((i-1))
		sleep 9
	done
}
wait_sys_boot_completed
MODDIR=${0%/*}
cd $MODDIR


killall -15 AppOpt
nohup ${MODDIR}/AppOpt >/dev/null 2>&1 &


