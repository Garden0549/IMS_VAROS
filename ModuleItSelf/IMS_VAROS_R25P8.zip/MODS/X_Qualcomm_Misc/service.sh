CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

Perf(){
    QSPM(){
        if [ "$QSPM_Disable" = "1" ]; then
            stop "vendor.qspmsvc"
            stop "qspmhal"
            echo "『QSPM』已尝试停止服务"
        else
            echo "『QSPM』不做修改"
        fi
    }
    
    QSPM
}

QLM_Service(){
    if [ -e "/vendor/bin/qlm-service" ]
    then
        stop vendor.qlm-service >/dev/null 2>&1
        sleep 1
        PidOfQLM="$(pidof qlm-service)"
        if [ -z "$PidOfQLM" ]; then
            echo "『QLM_Service』服务已停止"
        else
            echo "『QLM_Service』服务未停止，进程PID：'$PidOfQLM'"
        fi
    else
        echo "『QLM_Service』本设备不存在QLM_Service，不做处理"
    fi
}

Walt(){
    local DirFin="/proc/sys/walt"
    [ -z "$DirFin" ] && {
        echo "『Walt』未找到参数目录，不做处理"
        return 1
    }
    InputBoost(){
        local InputBoost_Dir="$DirFin/input_boost"


        find "$InputBoost_Dir" -mindepth 1 -type f -print0 | while IFS= read -r -d '' FileAddress
        do
            if [ "${FileAddress#$InputBoost_Dir/}" = "input_boost_freq" ]; then
                mask_val "0 0 0 0 0 0 0 0" "$FileAddress"
            else
                mask_val "0" "$FileAddress"
            fi
        done
    }
    Smart_Freq(){
        if [ -e "$DirFin/cluster0/smart_freq/ipc_freq_levels" ]
        then
            for i in $DirFin/cluster*
            do
                mask_val "2147483647 2147483647 2147483647 2147483647 2147483647" "$i/smart_freq/ipc_freq_levels" >/dev/null 2>&1
            done
        fi
        
        echo "『Walt』已阻止系统根据IPC分阶段限制CPU频率"
    }
    

    if [ "$Walt_InputBoost_Enable" = 0 ]; then
        InputBoost >/dev/null 2>&1
        echo "『Walt』已尝试关闭'输入事件临时性能提升'"
    else
        echo "『Walt』不修改'输入事件临时性能提升'的相关参数"
    fi    
    Smart_Freq
}

MSM_Performance(){
    local Dir1="/sys/kernel/msm_performance/parameters"
    local Dir2="/sys/module/msm_performance/parameters"
    local DirFin=""
    for i in "$Dir1" "$Dir2"
    do
        [ -e "$i" ] && DirFin="$i"
    done
    [ -z "$DirFin" ] && {
        echo "『MSM_Performance』未找到参数目录，不做处理"
        return 1
    }
    CPUFreqLimits(){
        mask_val '0:0 1:0 2:0 3:0 4:0 5:0 6:0 7:0' "$DirFin/cpu_min_freq"
        mask_val '0:2147483647 1:2147483647 2:2147483647 3:2147483647 4:2147483647 5:2147483647 6:2147483647 7:2147483647' "$DirFin/cpu_max_freq"
        mask_val "0" "$DirFin/core_ctl_register"
        mask_val "0" "$DirFin/evnt_gplaf_pid"
    }

    
    CPUFreqLimits
    echo "『MSM_Performance』已尝试关闭'CPU频率范围限制'等功能"
}

Kgsl3d0(){
    local Dir1="/sys/class/kgsl/kgsl-3d0"
    local Dir2_1="$Dir1/devfreq"
    local Dir2_2="$Dir1/gmu/dcvs_tunables"
    local Dir2=""
    for i in "$Dir2_1" "$Dir2_2"
    do
        [ -e "$i" ] && Dir2="$i"
    done
    [ -z "$Dir2" ] && {
        echo "『Kgsl3d0』未找到必要的参数目录，程序尚未执行操作，程序终止"
        return 1
    }
    #【——————↓［Dir1］↓——————】#
    ##确保DCVS(动态电压频率调整)启用
    lock_val "1" "$Dir1/pwrscale"    
    ##尝试确保GPU能按需请求DDR、L3频率
    lock_val "1" "$Dir1/bus_split"
    lock_val "1" "$Dir1/gmu_ab"
    lock_val "1" "$Dir1/l3_vote"
    

    ##关闭电流限制
    #电压补偿
    lock_val "0" "$Dir1/acd" >/dev/null 2>&1
    #电流阈值
    lock_val "0" "$Dir1/bcl"
    #精细电流限制
    lock_val "0" "$Dir1/clx"
    #根据温度与负载阈值限制频率
    lock_val "0" "$Dir1/lm"
    #控制LM的限流功能
    lock_val "0" "$Dir1/throttling"

    ##关闭造成无谓耗电的调试功能
    #强制总线(BUS)始终开启
    lock_val "0" "$Dir1/force_bus_on" >/dev/null 2>&1
    #强制GPU核心始终始终开启
    mask_val "0" "$Dir1/force_clk_on" >/dev/null 2>&1
    #禁止GPU浅休眠
    mask_val "0" "$Dir1/force_no_nap" >/dev/null 2>&1
    #强制GPU的电源轨(CX/GX)始终保持供电
    mask_val "0" "$Dir1/force_rail_on" >/dev/null 2>&1


    ##尝试确保一些功能启用
    #启用低功耗辅助渲染管道
    lock_val "1" "$Dir1/lpac"
    #允许在执行长任务时抢占当前上下文以执行更高优先级的上下文
    lock_val "1" "$Dir1/preemption"
    #允许进入IFPC状态(此状态会完全关闭GPU核心电源轨(GX)以深度省电)
    lock_val "1" "$Dir1/ifpc"
    #启用GPU时钟门控(自动关闭未使用逻辑模块的时钟)
    lock_val "1" "$Dir1/hwcg"
    #允许GPU页表遍历器(负责将GPU虚拟地址转换为物理地址)使用LLC切片(可加速页表访问)
    lock_val "1" "$Dir1/gpu_llc_slice_enable"
    #允许GPU主核心(GFX)使用LLC(LastLevelCache)切片(有助于降低DDR访问延迟和功耗)
    lock_val "1" "$Dir1/gpuhtw_llc_slice_enable"


    ##阻止［未知目录］的GPU频率范围限制
    chmod 0444 "/sys/kernel/gpu/gpu_max_clock" >/dev/null 2>&1
    chmod 0444 "/sys/kernel/gpu/gpu_min_clock" >/dev/null 2>&1
    ##解除［目录1］的GPU频率范围限制和触控升频
    PwrlevelNum="$(cat $Dir1/num_pwrlevels)"
    PwrlevelMin="$((PwrlevelNum - 1))"
    mask_val "$PwrlevelMin" "$Dir1/default_pwrlevel" >/dev/null 2>&1
    lock_val "$PwrlevelMin" "$Dir1/min_pwrlevel"
    lock_val "0" "$Dir1/max_pwrlevel"
    lock_val "0" "$Dir1/thermal_pwrlevel"
    #【——————↑［Dir1］↑——————】#    
    #【——————↓［Dir2］↓——————】#       
    ##阻止GPU负载计算被干扰
    lock_val "100" "$Dir2/mod_percent"
    ##解除［目录2］的GPU频率范围限制
    lock_val "9999000000" "$Dir2/max_freq" >/dev/null 2>&1
    lock_val "0" "$Dir2/min_freq" >/dev/null 2>&1
    lock_val "9999" "$Dir2/max_freq_mhz" >/dev/null 2>&1
    lock_val "0" "$Dir2/min_freq_mhz" >/dev/null 2>&1
    ##解除［目录2］的BUS频率范围限制
    lock_val "100000" "$Dir2/bus_max_freq_mhz" >/dev/null 2>&1
    lock_val "0" "$Dir2/bus_min_freq_mhz" >/dev/null 2>&1
    #【——————↑［Dir2］↑——————】#

    echo -e "『Kgsl3d0』已尝试优化部分功能\n"
    
    

    Kgsl3d0_TrueMax_Freq="$(NumSelector "$Kgsl3d0_Max_Freq" "$Dir1/freq_table_mhz")" >/dev/null
    lock_val "$Kgsl3d0_TrueMax_Freq" "$Dir1/max_clock_mhz"
    Kgsl3d0_TrueMin_Freq="$(NumSelector "$Kgsl3d0_Min_Freq" "$Dir1/freq_table_mhz")" >/dev/null
    lock_val "$Kgsl3d0_TrueMin_Freq" "$Dir1/min_clock_mhz"
    sleep 2
    Max_Freq="$(cat $Dir1/max_gpuclk)";Min_Freq="$(cat $Dir1/gpuclk)"
    echo "『Kgsl3d0』当前GPU频率［实际上限］为：$(echo "$Max_Freq / 1000000" | bc) MHz"
    echo "『Kgsl3d0』当前GPU频率［实际下限］为：$(echo "$Min_Freq / 1000000" | bc) MHz"
}

UFS(){
    local DeviceCount="0"
    for CoolingDevice in /sys/class/thermal/cooling_device*
    do
        case "$(cat "$CoolingDevice/type")" in
            ufs)
                DeviceCount="$(( DeviceCount + 1 ))"
                eval "local UFSCoolingDevice_${DeviceCount}=$CoolingDevice"
                ;;
        esac
    done
    
    if [ "$DeviceCount" = "0" ]; then
        echo "『UFS』没有找到驱动所属冷却设备，不做处理"
    else
        #关闭 I/O CPUBoost
        for i in "$(seq 1 $DeviceCount)"
        do
            [ "$DeviceCount" = "0" ] && break
            eval "CurrentCoolingDevice=\$UFSCoolingDevice_${DeviceCount}"
            lock_val "1" "$CurrentCoolingDevice/cur_state"
            echo "『UFS』已尝试修改驱动所属冷却设备的冷却状态以关闭'I/O CPUBoost'"
            DeviceCount="$(( DeviceCount - 1 ))"
        done
    fi
}


#————————————————————————————————————————


if [ "$(getprop ro.hardware)" = "qcom" ]
then
    echo -e "\n■ 高通平台，执行高通特别屏蔽\n"
    echo "<——————————————————>"
    Perf
    echo "<——————————————————>"
    QLM_Service
    echo "<——————————————————>"
    Walt
    echo "<——————————————————>"
    MSM_Performance
    echo "<——————————————————>"
    Kgsl3d0
    echo "<——————————————————>"
    UFS
    echo "<——————————————————>"
else
    echo "□ 非高通平台，不执行高通特别屏蔽"
fi


#————————————————————————————————————————




