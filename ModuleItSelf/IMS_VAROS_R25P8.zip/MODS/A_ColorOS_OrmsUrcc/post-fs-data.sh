CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】


#——————————————————————————#

FileDir="$CURMODDIR/File"
OriginOrmsConf="/odm/etc/orms/orms_core_config.xml"
EditedOrmsConf="$FileDir/orms_core_config.xml"
CustomOrmsConfDir="/data/system/orms"

OriginUahConf="/odm/etc/uah/uahconfig.pb"
EditedUahConf="$FileDir/uahconfig.pb"
UahUrccCache="/data/vendor/uah/ /data/vendor/urcc/"

#——————————————————————————#

if [ -e "$OriginOrmsConf" ]
then
    echo "————［■ Orms配置存在］————"
    echo "开始处理："
    
    SingleMount -u "$OriginOrmsConf" >/dev/null 2>&1 && \
    echo "✔️ 已卸载被挂载的Orms配置"
    
    if SingleMount -m "$EditedOrmsConf" "$OriginOrmsConf" >/dev/null
    then
        echo "✔️ 成功等效替换Orms配置"
    else
        echo "⭕ 未能成功挂载Orms配置"
    fi
    
    for i in $CustomOrmsConfDir
    do
        if [ -e "$i" ]; then
            rm -r "$i" && \
            echo "✔️ 已删除Orms自定义配置目录：'$i'"
        fi
    done
    
    echo "———————————————————————————"
else
    echo "————［□ Orms配置不存在］————"
    echo "略过。"
    
    echo "———————————————————————————"
fi



if [ -e "$OriginUahConf" ]
then
    echo "————［■ Uah配置存在］————"
    echo "开始处理："
    
    SingleMount -u "$OriginUahConf" >/dev/null 2>&1 && \
    echo "✔️ 已卸载被挂载的Uah配置"
    
    if SingleMount -m "$EditedUahConf" "$OriginUahConf" >/dev/null
    then
        echo "✔️ 成功等效替换Uah配置"
    else
        echo "⭕ 未能成功挂载Uah配置"
    fi
    
    for i in $UahUrccCache
    do
        if [ -e "$i" ]; then
            rm -r "$i" && \
            echo "✔️ 已删除UahUrcc缓存目录：'$i'"
        fi
    done
    
    echo "———————————————————————————"
else
    echo "————［□ Uah配置不存在］————"
    echo "略过。"
    
    echo "———————————————————————————"
fi












