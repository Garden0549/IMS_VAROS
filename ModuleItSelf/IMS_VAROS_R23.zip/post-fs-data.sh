MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



run_post_fs_data(){
    echo -e "\n\n【————LOG_STARTS_HERE————】\n\n"
    for i in $(find ${0%/*}/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
        if [ -f "$i/post-fs-data.sh" ]; then
          echo "###############——————###############"
          echo "【 $i： 】"
          echo "【 $(date +"%Y-%m-%d %H:%M:%S") 】"
          sh $i/post-fs-data.sh
          echo "###############——————###############"
          echo -e "\n\n"
        fi
    done
    echo -e "\n\n【————LOG_ENDS_HERE————】\n\n"
}


CACHE_Remover

mkdir -p $MODDIR/LOG;rm -f $MODDIR/LOG/LOG_post-fs-data.txt
run_post_fs_data 2>&1 | tee -a $MODDIR/LOG/LOG_post-fs-data.txt
