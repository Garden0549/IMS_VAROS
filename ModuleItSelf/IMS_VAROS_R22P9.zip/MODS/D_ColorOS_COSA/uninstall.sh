if [ -n "$1" ]; then
    #解决使用action.sh执行该脚本时"$0（本脚本地址）"异常引起的变量错误问题
    CURFILE="$1"
else
    CURFILE="$0"
fi
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】

#————————————————————————————————————————

Backup_Dir=$CURMODDIR/COSABackup
Backup=$Backup_Dir/GameSchedulingConf.sql
Last_Backup=/data/cache/GameSchedulingConf.sql
COSA_Database_Dir=/data/data/com.oplus.cosa/databases
COSA_Database=$COSA_Database_Dir/db_game_database
sqlite3=$ROOTMODDIR/Bin/sqlite3
new_sqlite3=/data/cache/sqlite3
COSAService=com.oplus.cosa/com.oplus.cosa.service.COSAService
AB_COSA=$CURMODDIR/AB_COSA.txt

#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){

    #向[应用增强服务]的数据库注入[应用性能调度配置]的准备
    cp -f $sqlite3 $new_sqlite3 > /dev/null 2>&1
    cp -f $Backup $Last_Backup > /dev/null 2>&1

}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){


    echo "【阶段一】启用[应用增强服务]中被模块禁用的组件"
    #1.启用[应用增强服务]中被模块禁用的组件
    DEnable "e" "com.oplus.cosa/.gpalibrary.service.GPAService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.HyperBoostService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.CosaHyperBoostService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.oiface.OifaceService" > /dev/null 2>&1
    echo "已确保开启会被模块关闭的[应用增强服务]组件：俩Hyper GPA OiFace(如果有)"
    
    echo
    
    echo "【阶段二】检测是否满足条件：向[应用增强服务]的数据库注入备份的[应用性能调度配置]"
    #2.检测[应用增强服务]是否已安装且已启用
    #  未启用，报未启用、停止注入
    #  已启用，检查备份的[应用性能调度配置]是否存在：
    #    不存在，报不存在，报并清空[应用增强服务]数据，以尝试恢复其[应用性能调度配置]
    #    存在，报存在、开始注入
    if $(AppStateChecker "e" "com.oplus.cosa"); then
        echo "[应用增强服务]已安装且已启用"
        if [ -f $Last_Backup ]; then
            echo "备份的[应用性能调度配置]存在，开始将其注入[应用增强服务]数据库"
        else
            echo "备份的[应用性能调度配置]不存在，不执行注入"
            pm clear "com.oplus.cosa" > /dev/null 2>&1 && echo "已成功清空[应用增强服务]数据，以尝试恢复其[应用性能调度配置]"
            rm -f $Last_Backup $new_sqlite3 && echo "已清除残留文件"
            return 1
        fi
    else
        echo "[应用增强服务]未安装或未启用，停止向其注入备份的[应用性能调度配置]"
        return 1
    fi
    
    echo
    
    echo "【阶段三】启动[应用增强服务]，检测其是否异常，等待数据库创建"
    #3.启动[应用增强服务]，等待5秒以确保检测到其异常时的自行终止
    #  未能启动，报未能启动，采集日志并提示提交模块开发者，报停止处理
    #  成功启动，报成功启动，等待10秒以等待数据库的创建，再检查数据库是否存在：
    #   不存在，报不存在，报停止处理
    #   存在，报存在、将向其注入[应用性能调度配置表]
    DEnable "e" "$COSAService" > /dev/null 2>&1
    am startservice -n "$COSAService" > /dev/null 2>&1
    sleep 5
    if ! pidof "com.oplus.cosa" > /dev/null 2>&1; then
        echo "未能启动[应用增强服务]，已采集其日志，请提交模块开发者"
        echo "日志位于：'$AB_COSA'"
        echo "停止处理"
        timeout 3 logcat | grep -i "cosa" > "$AB_COSA"
        return 1
    else
        echo "成功启动[应用增强服务]，等待10秒以确保数据库正常创建"
        sleep 10
        if [ ! -f $COSA_Database ]; then
            echo "[应用增强服务]数据库不存在，停止处理"
            return 1
        else
            echo "[应用增强服务]数据库存在，尝试向其注入[应用性能调度配置表]"
        fi
    fi
    
    echo
    
    echo "【阶段四】注入[应用性能调度配置表]"
    #4.杀死[应用增强服务]和[游戏助手]以彻底关闭数据库保护
    #  再向[应用增强服务]数据库注入[应用性能调度配置表]
    #  等待sqlite3运行3秒
    am force-stop com.oplus.games
    am force-stop com.oplus.cosa
    $new_sqlite3 "$COSA_Database" "DROP TABLE IF EXISTS PackageConfigBean;"
    $new_sqlite3 $COSA_Database < $Last_Backup
    sleep 3
    echo "已尝试注入[应用性能调度配置表]"
    
    echo
    
    echo "【阶段五】复启动[应用增强服务]，检测其是否异常，检测[应用性能调度配置表]是否存在"
    #5.复启动[应用增强服务]，等待5秒以确保检测到其异常时的自行终止
    #  未能启动，报未能启动，采集日志并提示提交模块开发者，报停止处理
    #  成功启动，报成功启动，检查[应用性能调度配置表]是否存在：
    #    存在，报恢复成功
    #    不存在，报恢复失败
    am startservice -n "$COSAService" > /dev/null 2>&1
    sleep 5
    if ! pidof "com.oplus.cosa" > /dev/null 2>&1; then
        echo "未能复启动[应用增强服务]，已采集其日志，请提交模块开发者"
        echo "日志位于：'$AB_COSA'"
        echo "停止处理"
        timeout 3 logcat | grep -i "cosa" > "$AB_COSA"
        return 1
    else
        echo "成功复启动[应用增强服务]，检查[应用性能调度配置表]是否存在："
        if $sqlite3 "$COSA_Database" "SELECT 1 FROM sqlite_master WHERE name='PackageConfigBean';" | grep -q "1"; then
            echo "[应用性能调度配置表]成功恢复"
        else
            echo "[应用性能调度配置表]未能恢复"
        fi
    fi

    echo
    
    echo "【阶段六】清理残留文件"
    #6.清理残留文件
    rm -f $Last_Backup $new_sqlite3
}

#————————————————————————————————————————


AtPost
if [ -n "$1" ]; then
    AtService
else
    {
        wait_until_login;sleep 60
        AtService
    } &
fi











