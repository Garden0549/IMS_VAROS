CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】

#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){

    resetprop -p --delete ro.vendor.magt.mtk_magt_support
    
}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){

    #避免空函数异常
    echo OKAY

}

#————————————————————————————————————————

AtPost
{
    wait_until_login;sleep 60
    AtService
} &











