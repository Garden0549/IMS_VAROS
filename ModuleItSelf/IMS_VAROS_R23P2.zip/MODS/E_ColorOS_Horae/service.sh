CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



ProcessManager "Horae"\
                  "horae"\
                  "horae"

#屏蔽外壳温度（屏幕 背板 边框 软件）
Temp=29500

for i in $(seq 0 9); do
    lock_val "$i $Temp" /proc/shell-temp
done
echo "已尝试将机身外壳温度伪装为'$Temp'毫℃"


