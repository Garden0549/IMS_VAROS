CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

#Qualcomm Limits Management Service
QLM_Service(){
    if [ -e "/vendor/bin/qlm-service" ]
    then
        stop vendor.qlm-service > /dev/null 2>&1
        sleep 1
        PidOfQLM="$(pidof qlm-service)"
        if [ -z "$PidOfQLM" ]; then
            echo "QLM_Service：进程已终止"
        else
            echo "QLM_Service：进程未终止，进程PID：'$PidOfQLM'"
        fi
    else
        echo "本设备不存在QLM_Service，不做处理"
    fi
}

#CPU调速器Walt的内核模块_输入事件加速
Walt_InputBoost(){
    local Dir1="/proc/sys/walt/input_boost"
    local Dir2=""
    local DirFin=""
    for i in $Dir1 $Dir2
    do
        if [ -e "$i" ]; then
            DirFin="$i"
        fi    
    done
    if [ -n "$DirFin" ]; then
        if [ "$Walt_InputBoost_Enable" = 0 ]; then
            mask_val "0" "$DirFin/*" > /dev/null 2>&1
            echo "CPU调速器Walt的内核模块_输入事件加速：已尝试关闭"
        else
            echo "CPU调速器Walt的内核模块_输入事件加速：不修改相关参数"
        fi
    else
        echo "CPU调速器Walt的内核模块_输入事件加速：未找到参数目录"
    fi
}

#MSM_Performance_CPU频率范围限制功能
MSM_Performance_CPUFreqLimits(){
    local Dir1="/sys/kernel/msm_performance/parameters"
    local Dir2="/sys/module/msm_performance/parameters"
    local DirFin=""
    for i in $Dir1 $Dir2
    do
        if [ -e "$i" ]; then
            DirFin="$i"
        fi    
    done
    if [ -n "$DirFin" ]; then
        if [ "$MSM_Performance_CPUFreqLimits_Enable" = 0 ]; then
            mask_val '0:0 1:0 2:0 3:0 4:0 5:0 6:0 7:0' "$DirFin/cpu_min_freq"
            mask_val '0:2147483647 1:2147483647 2:2147483647 3:2147483647 4:2147483647 5:2147483647 6:2147483647 7:2147483647' "$DirFin/cpu_max_freq"
            echo "MSM_Performance的CPU频率范围限制功能：已尝试关闭"
        else
            echo "MSM_Performance的CPU频率范围限制功能：不修改相关参数"
        fi
    else
        echo "MSM_Performance的CPU频率范围限制功能：未找到参数目录'"
    fi
}

#Kgsl3d0
Kgsl3d0(){
    local Dir1="/sys/class/kgsl/kgsl-3d0"
    local Dir2_1="$Dir1/devfreq"
    local Dir2_2="$Dir1/gmu/dcvs_tunables"
    local Dir2=""
    for i in $Dir2_1 $Dir2_2
    do
        if [ -e "$i" ]; then
            Dir2="$i"
        fi    
    done
    if [ -z "$Dir2" ]; then
        echo "Kgsl3d0：未找到参数目录2，程序终止"
        return 1
    fi
    
    #Dir1：关闭无用功能，去除频率限制
    lock_val "0" $Dir1/force_bus_on > /dev/null 2>&1
    lock_val "0" $Dir1/force_clk_on > /dev/null 2>&1
    lock_val "0" $Dir1/force_no_nap > /dev/null 2>&1
    lock_val "0" $Dir1/force_rail_on > /dev/null 2>&1
    lock_val "0" $Dir1/throttling
    lock_val "0" $Dir1/bcl
    lock_val "0" $Dir1/preemption
    
    PwrlevelNum="$(cat $Dir1/num_pwrlevels)"
    PwrlevelMin="$((PwrlevelNum - 1))"
    mask_val "$PwrlevelMin" $Dir1/default_pwrlevel > /dev/null 2>&1
    lock_val "$PwrlevelMin" $Dir1/min_pwrlevel
    lock_val "0" $Dir1/max_pwrlevel
    lock_val "0" $Dir1/thermal_pwrlevel
    
           
    #Dir2：关闭无用功能，去除频率限制，设置和读取频率上限、频率下限
    lock_val "100" $Dir2/mod_percent
    mask_val "9999000000" $Dir2/max_freq > /dev/null 2>&1
    mask_val "0" $Dir2/min_freq > /dev/null 2>&1
    mask_val "9999" $Dir2/max_freq_mhz > /dev/null 2>&1
    mask_val "0" $Dir2/min_freq_mhz > /dev/null 2>&1
    
    echo -e "Kgsl3d0：已尝试关闭无用功能，去除频率限制\n"
    
    [ "$Kgsl3d0_Max_Freq" != "DEFAULT" ] && lock_val "$Kgsl3d0_Max_Freq" "$Dir1/max_clock_mhz"
    [ "$Kgsl3d0_Min_Freq" != "DEFAULT" ] && lock_val "$Kgsl3d0_Min_Freq" "$Dir1/min_clock_mhz"
    sleep 3
    Max_Freq="$(cat $Dir1/max_gpuclk)"
    Min_Freq="$(cat $Dir1/gpuclk)"
    echo "Kgsl3d0：GPU频率［实际上限］设为：$(echo "$Max_Freq / 1000000" | bc) MHz"
    echo "Kgsl3d0：GPU频率［实际下限］设为：$(echo "$Min_Freq / 1000000" | bc) MHz"
}

#————————————————————————————————————————

if [ "$(getprop ro.hardware)" = "qcom" ]
then
    echo -e "\n高通芯片，执行高通特别屏蔽\n"
    echo "<——————————————————>"
    QLM_Service
    echo "<——————————————————>"
    Walt_InputBoost
    echo "<——————————————————>"
    MSM_Performance_CPUFreqLimits_Enable=0
    MSM_Performance_CPUFreqLimits
    echo "<——————————————————>"
    Kgsl3d0
    echo "<——————————————————>"
else
    echo "非高通芯片，不执行高通特别屏蔽"
fi

#————————————————————————————————————————




