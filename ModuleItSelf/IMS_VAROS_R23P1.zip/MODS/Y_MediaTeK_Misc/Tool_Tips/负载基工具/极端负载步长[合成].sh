
LB_New_UltraStep_Bit0_7=2
LB_New_UltraStep_Bit8_15=1


LB_New_UltraStep_FinValue=$(( (LB_New_UltraStep_Bit8_15 << 8) | LB_New_UltraStep_Bit0_7 ))

echo "LB_New_UltraStep_FinValue：$LB_New_UltraStep_FinValue（十六进制：$(echo "obase=16; $LB_New_UltraStep_FinValue" | bc)）"




