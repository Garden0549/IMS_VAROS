CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



ProcessManager "GameOpt"\
                  "gameopt_hal_service-1-0"\
                  "vendor.oplus.hardware.gameopt-service"


GamePID=/proc/game_opt/game_pid
RTInfo=/proc/game_opt/rt_info
FreqLimit=/proc/game_opt/disable_cpufreq_limit
Debug=/proc/game_opt/debug_enable
FakeCPU7=/proc/game_opt/fake_cpu7_cpuinfo_max_freq

EarlyDetect1=/proc/game_opt/early_detect/ed_enable
EarlyDetect2=/proc/oplus_cpu_game/early_detect/ed_enable

YieldOpt=/proc/game_opt/yield_opt

TB=/proc/game_opt/task_boost
TB_CT=$TB/ct_enable
TB_HTB=$TB/htb_enable

FLT=/proc/game_opt/frame_load_track/flt_enable

MT=/proc/game_opt/multi_task/multi_task_util_enable

SGS=/proc/game_opt/skip_gameself_setaffinity

if [ -e /proc/game_opt/ ]; then
    if [ -e $GamePID ]; then
        mask_val "-1" $GamePID > /dev/null 2>&1
        echo "已移除GameOpt的所有［目标进程］，并阻止新进程加入"
    fi
    if [ -e $RTInfo ]; then
        mask_val "-1" $RTInfo > /dev/null 2>&1
        echo "已移除GameOpt的所有［目标渲染线程］，并阻止新渲染线程加入"
    fi
    if [ -e $FreqLimit ]; then
        mask_val "1" $FreqLimit > /dev/null 2>&1
        echo "已全局关闭GameOpt的［频率限制］功能"
    fi
    if [ -e $Debug ]; then
        mask_val "0" $Debug > /dev/null 2>&1
        echo "已全局关闭GameOpt的［调试］功能"
    fi
    if [ -e $FakeCPU7 ]; then
        mask_val "0" $FakeCPU7 > /dev/null 2>&1
        echo "已关闭GameOpt的［CPU7频率伪装］功能"
    fi
    
    if [ -e $EarlyDetect1 ] || [ -e $EarlyDetect2 ]; then
        mask_val "0" $EarlyDetect1 > /dev/null 2>&1
        mask_val "0" $EarlyDetect2 > /dev/null 2>&1
        echo "已全局关闭GameOpt的［帧率早期预测］功能"
    fi
    
    if [ -e $YieldOpt ]; then
        mask_val "0 120 10" $YieldOpt > /dev/null 2>&1
        echo "已关闭GameOpt的［Yield优化］功能"
    fi
    
    if [ -e $TB ]; then
        mask_val "0" $TB_CT > /dev/null 2>&1
        mask_val "0" $TB_HTB > /dev/null 2>&1
        echo "已关闭GameOpt的［特定任务加速］功能"
    fi
    
    if [ -e $FLT ]; then
        mask_val "0" $FLT > /dev/null 2>&1
        echo "已关闭GameOpt的［帧负载跟踪］功能"
    fi
    
    if [ -e $MT ]; then
        mask_val "0" $MT > /dev/null 2>&1
        echo "已关闭GameOpt的［多任务监控］功能"
    fi

    if [ -e $SGS ]; then
        mask_val "0" $SGS > /dev/null 2>&1
        echo "已关闭GameOpt的［调试与跳过游戏自放置线程］功能"
    fi
else
    echo "GameOpt的Procfs参数目录不存在，不做修改"
fi












