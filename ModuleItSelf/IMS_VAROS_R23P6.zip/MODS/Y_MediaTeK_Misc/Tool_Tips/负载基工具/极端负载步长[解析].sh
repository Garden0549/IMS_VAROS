#!/bin/sh


LB_New_UltraStep_FinValue=258

# 解析 LB_STEP_UltraHigh (低8位的值)
LB_New_UltraStep_Bit0_7=$(( LB_New_UltraStep_FinValue & 0xFF ))

# 解析 LB_STEP_UltraLow (左移8位后的值)
LB_New_UltraStep_Bit8_15=$(( LB_New_UltraStep_FinValue >> 8 ))


# 输出结果
echo "LB_New_UltraStep_Bit0_7: $LB_New_UltraStep_Bit0_7"
echo "LB_New_UltraStep_Bit8_15: $LB_New_UltraStep_Bit8_15"
