#!/bin/sh

# 假设 LB_MARGIN_FinValue 已经设置
# LB_MARGIN_FinValue=某个值

LB_MARGIN_FinValue=84215582


# 提取各个字段的值
LB_MARGIN_StaticMargin=$((LB_MARGIN_FinValue & 0xFF))
LB_MARGIN_DynEnable=$(((LB_MARGIN_FinValue >> 8) & 0x1))
LB_MARGIN_DynUsePipeTime=$(((LB_MARGIN_FinValue >> 9) & 0x1))
LB_MARGIN_DynPerfMode=$(((LB_MARGIN_FinValue >> 10) & 0x1))
LB_MARGIN_DynFixTargetFPS30=$(((LB_MARGIN_FinValue >> 11) & 0x1))
LB_MARGIN_DynMinMargin=$(((LB_MARGIN_FinValue >> 16) & 0xFF))
LB_MARGIN_DynStepSize=$(((LB_MARGIN_FinValue >> 24) & 0xFF))

# 打印解析结果
echo "LB_MARGIN_StaticMargin: $LB_MARGIN_StaticMargin"
echo "LB_MARGIN_DynEnable: $LB_MARGIN_DynEnable"
echo "LB_MARGIN_DynUsePipeTime: $LB_MARGIN_DynUsePipeTime"
echo "LB_MARGIN_DynPerfMode: $LB_MARGIN_DynPerfMode"
echo "LB_MARGIN_DynFixTargetFPS30: $LB_MARGIN_DynFixTargetFPS30"
echo "LB_MARGIN_DynMinMargin: $LB_MARGIN_DynMinMargin"
echo "LB_MARGIN_DynStepSize: $LB_MARGIN_DynStepSize"