#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh
#配置表(仅引用该表的脚本有)
source ${0%/*/*}/Scheduler.cfg


###↓↓↓<<———GED———>>↓↓↓###
#<——————————————————————————————————————>#

SpecificFunc(){
    DCS=/sys/kernel/ged/hal/dcs_mode
    FastDVFS=/sys/kernel/ged/hal/fastdvfs_mode
    SmartBoost=/sys/module/ged/parameters/ged_smart_boost
    
    for i in DCS FastDVFS SmartBoost
    do
        eval File=\$$i
        eval FileSwitch=\$${i}_Disable
        if [ -f $File ]
        then
            if [ $FileSwitch = 1 ]
            then
                mask_val 0 "$File"
                echo "已关闭：'$i'"
            else
                echo "未修改：'$i'——'$File'"
            fi
        else
            echo "不存在而未处理：'$i'——'$File'"
        fi
    done
}

#<——————————————————————————————————————>#

GED_KPI(){
    if [ $GED_KPI_Enable = 0 ]; then
        immu_mask_val 0 /sys/module/ged/parameters/is_GED_KPI_enabled
        echo "已关闭GED_KPI"
    else
        immu_mask_val 1 /sys/module/ged/parameters/is_GED_KPI_enabled
        echo "已开启GED_KPI"
    fi
}

#<——————————————————————————————————————>#

Custom_MaxMinFreq(){
    lock_val $Custom_Max_Freq /sys/kernel/ged/hal/custom_upbound_gpu_freq
    echo "GPU实际频率［上限］设为：$(cat /sys/module/ged/parameters/gpu_cust_upbound_freq) KHz"

    lock_val $Custom_Min_Freq /sys/kernel/ged/hal/custom_boost_gpu_freq
    echo "GPU实际频率［下限］设为：$(cat /sys/module/ged/parameters/gpu_cust_boost_freq) KHz"
}

#<——————————————————————————————————————>#

LB_New_Margin(){
    LB_New_Margin_FinValue=$((LB_New_Margin_StaticMargin))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynEnable << 8)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynUsePipeTime << 9)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynPerfMode << 10)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynFixTargetFPS30 << 11)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynMinMargin << 16)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynStepSize << 24)))
    
    echo "'负载基-新'余量值：$LB_New_Margin_FinValue"
    mask_val $LB_New_Margin_FinValue /sys/kernel/ged/hal/timer_base_dvfs_margin
}

#<——————————————————————————————————————>#

LB_New_Step(){
    LB_New_Step_FinValue=$(( (LB_New_Step_UltraLow << 8) | LB_New_Step_UltraHigh ))
    
    echo "'负载基-新'极端负载下步长值：$LB_New_Step_FinValue"
    mask_val $LB_New_Step_FinValue /sys/kernel/ged/hal/loading_base_dvfs_step
}

#<——————————————————————————————————————>#

LB_Old(){
    if [ $LB_Old_Enable = 0 ]; then
        lock_val 0 /sys/module/ged/parameters/g_gpu_timer_based_emu
        echo "已关闭'负载基-旧'模式"
    else
        lock_val 1 /sys/module/ged/parameters/g_gpu_timer_based_emu
        echo "已开启'负载基-旧'模式，其将取代'负载基-新'模式"
    fi
}

#<——————————————————————————————————————>#

Force_LB(){
    if [ $Force_LB_Enable = 1 ]; then
        lock_val 1 /sys/kernel/ged/hal/force_loading_base > /dev/null 2>&1
        lock_val 120 /sys/module/ged/parameters/g_fb_dvfs_threshold > /dev/null 2>&1
        echo "强制只使用'负载基'模式"
    else
        lock_val 0 /sys/kernel/ged/hal/force_loading_base > /dev/null 2>&1
        lock_val 80 /sys/module/ged/parameters/g_fb_dvfs_threshold > /dev/null 2>&1
        echo "恢复系统默认设置，自动切换调频模式"
    fi
}

#<——————————————————————————————————————>#

FB_Margin(){
    if { [ "$FB_Margin" -ge 401 ] && [ "$FB_Margin" -le 499 ]; } || { [ "$FB_Margin" -ge 501 ] && [ "$FB_Margin" -le 599 ]; }; then
        FB_Margin_FinValue=$(( FB_Margin | (FB_Margin_MinStep << 10) | (FB_Margin_MinMargin << 16) ))
    else
        FB_Margin_FinValue=$FB_Margin
    fi
    
    echo "'帧基'余量值：$FB_Margin_FinValue"
    mask_val $FB_Margin_FinValue /sys/kernel/ged/hal/dvfs_margin_value
}

#<——————————————————————————————————————>#
###↑↑↑<<———GED———>>↑↑↑###



###↓↓↓<<———GPT———>>↓↓↓###
#<——————————————————————————————————————>#

GPT(){
    GPT=/sys/kernel/thermal/gpt
    if [ -f $GPT ]; then
        if [ $GPT_Enable = 1 ]; then
            echo "已尝试开启GPT功能并调整其参数"
            lock_val "enable" /sys/kernel/thermal/gpt
            lock_val "gpt 1 $GPT_Thrm1" /sys/kernel/thermal/gpt
            lock_val "gpt 2 $GPT_Thrm2" /sys/kernel/thermal/gpt
        else
            echo "已尝试关闭GPT功能！"
            lock_val "disable" /sys/kernel/thermal/gpt
        fi
    fi
}

#<——————————————————————————————————————>#
###↑↑↑<<———GPT———>>↑↑↑###

GED(){
    SpecificFunc
    
    GED_KPI

    Custom_MaxMinFreq
    
    LB_New_Margin
    
    LB_New_Step
    
    LB_Old
    
    Force_LB
    
    FB_Margin
}
[ $GED = 1 ] && GED
GPT







