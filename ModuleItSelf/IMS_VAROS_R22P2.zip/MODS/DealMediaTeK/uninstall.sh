#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh

#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){

    resetprop -p --delete ro.vendor.magt.mtk_magt_support
    
}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){

#恢复Scene配置中被替换的字符
sed -i 's/DoNOT1/force_onoff/g' /data/data/com.omarea.vtools/files/powercfg.sh
sed -i 's/DoNOT2/fpsgo_enable/g' /data/data/com.omarea.vtools/files/powercfg.sh
sed -i 's/DoNOT3/fpsgo_enable/g' /data/data/com.omarea.vtools/files/profile.json

}

#————————————————————————————————————————

AtPost
{
    wait_until_login;sleep 60
    AtService
} &











