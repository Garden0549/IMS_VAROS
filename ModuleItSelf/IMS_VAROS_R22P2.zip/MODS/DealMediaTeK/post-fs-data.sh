#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh
#配置表(仅引用该表的脚本有)
source ${0%/*/*}/Scheduler.cfg


PowerHAL_Empty_Conf(){
    if [ $PowerHAL_Conf_AppCfg_Empty != 1 ] && [ $PowerHAL_Conf_Contbl_Empty != 1 ] && [ $PowerHAL_Conf_Scntbl_Empty != 1 ]
    then
        echo "没有PowerHAL配置需要清空"
        return 0
    fi
    
    echo "<————————［挂载PowerHAL配置］————————>"
    if [ $PowerHAL_Conf_AppCfg_Empty = 1 ]
    then
        echo "［power_app_cfg］"
        echo "〔尝试卸载已挂载配置〕"
        BatchMount -u "$MODDIR/Conf_AppCfg"
        echo
        echo "〔尝试挂载配置〕"
        BatchMount -m "$MODDIR/Conf_AppCfg"
    fi
    echo "<———————————>"
    if [ $PowerHAL_Conf_Contbl_Empty = 1 ]
    then
        echo "［powercontable］"
        echo "〔尝试卸载已挂载配置〕"
        BatchMount -u "$MODDIR/Conf_Contbl"
        echo
        echo "〔尝试挂载配置〕"
        BatchMount -m "$MODDIR/Conf_Contbl"
    fi
    echo "<———————————>"
    if [ $PowerHAL_Conf_Scntbl_Empty = 1 ]
    then
        echo "［powerscntbl］"
        echo "〔尝试卸载已挂载配置〕"
        BatchMount -u "$MODDIR/Conf_Scntbl"
        echo
        echo "〔尝试挂载配置〕"
        BatchMount -m "$MODDIR/Conf_Scntbl"
    fi
    echo "<————————［挂载PowerHAL配置］————————>"
}

MAGT(){
    if [ $MAGT_Enable = 0 ]; then
        resetprop -p ro.vendor.magt.mtk_magt_support 0
        echo "已尝试进一步关闭MAGT"
    else
        resetprop -p ro.vendor.magt.mtk_magt_support 1
    fi
}


if [ "$(getprop ro.hardware)" != "qcom" ]
then
    echo "联发科芯片，执行联发科特别屏蔽"
    PowerHAL_Empty_Conf
    MAGT
else
    echo "非联发科芯片，不执行联发科特别屏蔽"
fi




