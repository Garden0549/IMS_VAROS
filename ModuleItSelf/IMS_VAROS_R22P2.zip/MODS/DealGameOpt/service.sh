#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh
#配置表(仅引用该表的脚本有)
source ${0%/*/*}/Scheduler.cfg


ProcessManager "GameOpt"\
                  "gameopt_hal_service-1-0"\
                  "vendor.oplus.hardware.gameopt-service"


GamePID=/proc/game_opt/game_pid
RTInfo=/proc/game_opt/rt_info
FreqLimit=/proc/game_opt/disable_cpufreq_limit
Debug=/proc/game_opt/debug_enable
FakeCPU7=/proc/game_opt/fake_cpu7_cpuinfo_max_freq
EarlyDetect1=/proc/game_opt/early_detect/ed_enable
EarlyDetect2=/proc/oplus_cpu_game/early_detect/ed_enable
YieldOpt=/proc/game_opt/yield_opt
CT=/proc/game_opt/task_boost/ct_enable

if [ -d /proc/game_opt/ ]; then
    if [ -f $GamePID ]; then
        mask_val "-1" $GamePID
        echo "已移除GameOpt的所有［目标进程］，并阻止新进程加入"
    fi
    if [ -f $RTInfo ]; then
        mask_val "-1" $RTInfo
        echo "已移除GameOpt的所有［目标渲染线程］，并阻止新渲染线程加入"
    fi
    if [ -f $FreqLimit ]; then
        mask_val "1" $FreqLimit
        echo "已全局关闭GameOpt的［频率限制］功能"
    fi
    if [ -f $Debug ]; then
        mask_val "0" $Debug
        echo "已全局关闭GameOpt的［调试］功能"
    fi
    if [ -f $FakeCPU7 ]; then
        mask_val "0" $FakeCPU7
        #（为1则用次一级的集群作CPU7的频率）
        echo "已关闭GameOpt的［CPU7频率伪装］功能"
    fi
    if [ -f $EarlyDetect1 ] || [ -f $EarlyDetect2 ]; then
        mask_val "0" $EarlyDetect1 > /dev/null 2>&1
        mask_val "0" $EarlyDetect2 > /dev/null 2>&1
        echo "已全局关闭GameOpt的［帧率早期预测］功能"
    fi
    if [ -f $YieldOpt ]; then
        mask_val "0 120 10" $YieldOpt
        #（首参数 0 表示关闭）
        echo "已关闭GameOpt的［Yield优化］功能"
    fi
    if [ -f $CT ]; then
        mask_val "0" $CT
        echo "已关闭GameOpt的［关键任务提频］功能"
    fi
else
    echo "GameOpt的Proc参数目录不存在，不做修改"
fi












