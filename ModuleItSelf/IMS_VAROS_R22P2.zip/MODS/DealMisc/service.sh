#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh
#配置表(仅引用该表的脚本有)
source ${0%/*/*}/Scheduler.cfg


##ColorOS特有
SchedAssist=/proc/oplus_scheduler/sched_assist/sched_assist_enabled
SchedAssist_LoadBalance=/proc/oplus_scheduler/sched_assist/lb_enable
CpufreqBouncing=/sys/module/cpufreq_bouncing/parameters/enable
CpufreqEffiency=/sys/module/cpufreq_effiency/parameters/affect_mode
OplusMultipleRailGroup=/sys/devices/platform/soc/soc:oplus-omrg/oplus-omrg0/ruler_enable
TaskSchedInfo_Proc=/proc/task_info/task_sched_info/task_sched_info_enable
TaskSchedInfo_Sys=/sys/module/oplus_bsp_task_sched/parameters/sched_info_ctrl
TaskCPUstats=/proc/task_info/task_cpustats/task_cpustats_enable
TaskOverload=/proc/task_overload/skip_goplus_enabled
TaskLoadInfo=/proc/task_info/task_load_info/monitor_status
for i in SchedAssist SchedAssist_LoadBalance CpufreqBouncing CpufreqEffiency OplusMultipleRailGroup TaskSchedInfo_Proc TaskSchedInfo_Sys TaskCPUstats TaskOverload TaskLoadInfo
do
    eval File=\$$i
    eval FileSwitch=\$${i}_Disable
    if [ -f $File ]
        then
            if [ $FileSwitch = 1 ]
            then
                mask_val 0 "$File"
                echo "已关闭：'$i'"
            else
                echo "未修改：'$i'——'$File'"
            fi
        else
            echo "不存在而未处理：'$i'——'$File'"
        fi
done


##安卓设备共有
#可用CPU核心数控制
#(在MTK设备上,重启PowerHAL进程会重置以下所有文件)
KILL_CORECTL(){
    for i in /sys/devices/system/cpu/cpu*; do
        if [ -f $i/core_ctl/enable ]; then
          lock_val 1 $i/core_ctl/enable
        fi
        if [ -f $i/core_ctl/min_cpus ]; then
          lock_val 99 $i/core_ctl/min_cpus
        fi
        if [ -f $i/core_ctl/max_cpus ]; then
          lock_val 99 $i/core_ctl/max_cpus
        fi
        if [ -f $i/core_ctl/enable ]; then
          lock_val 0 $i/core_ctl/enable
        fi
    done
}
KILL_CORECTL









