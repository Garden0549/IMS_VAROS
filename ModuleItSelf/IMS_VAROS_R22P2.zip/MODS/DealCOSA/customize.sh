#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh


Backup_Dir=$MODDIR/COSABackup
Backup=$Backup_Dir/GameSchedulingConf.sql
Old_Backup=/data/adb/modules/$MOD_ID/MODS/DealCOSA/COSABackup/GameSchedulingConf.sql
COSA_Database=/data/data/com.oplus.cosa/databases/db_game_database
sqlite3=$MODDIR_ROOT/Bin/sqlite3

if [ "$1" = "RightNow" ]; then
    #解决使用action.sh执行该脚本时"$0（本脚本地址）"异常引起的变量错误问题
    MODDIR=/data/adb/modules/IMS_VAROS/MODS/DealCOSA
    MODDIR_ROOT=/data/adb/modules/IMS_VAROS
    Backup_Dir=$MODDIR/COSABackup
    Backup=$Backup_Dir/GameSchedulingConf.sql
    Old_Backup=/data/adb/modules/$MOD_ID/MODS/DealCOSA/COSABackup/GameSchedulingConf.sql
    COSA_Database=/data/data/com.oplus.cosa/databases/db_game_database
    sqlite3=$MODDIR_ROOT/Bin/sqlite3
fi




mkdir -p $Backup_Dir

echo "开始检查是否有需要备份的[应用增强服务]应用性能调度配置"
if [ -f $Old_Backup ]; then
    cp -f $Old_Backup $Backup_Dir
    echo -e "\n检测到该模块旧的[应用性能调度配置]备份，\n已将其复制到本模块，将在卸载模块时恢复(如果此时[应用增强服务]已安装)\n"
elif [ -f $COSA_Database ]; then
    $sqlite3 "$COSA_Database" ".dump PackageConfigBean" > $Backup && echo "\n已备份[应用性能调度配置]，\n将在卸载模块时恢复(如果此时[应用增强服务]已安装)\n"
else
    echo "\n未发现需要备份的[应用性能调度配置]\n"
fi

for i in com.oplus.cosa com.oplus.games
do
    if $(AppStateChecker "n" "$i"); then
        DEnable "e" "$i"
        echo "为避免可能的异常，已为当前用户矫正'$i'的启用状态"
    fi
done
pm clear "com.oplus.cosa" > /dev/null 2>&1 && echo "为避免可能的异常，已为当前用户清空'com.oplus.cosa'的数据"






