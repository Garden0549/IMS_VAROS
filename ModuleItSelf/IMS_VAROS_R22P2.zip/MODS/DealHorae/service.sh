#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh
#配置表(仅引用该表的脚本有)
source ${0%/*/*}/Scheduler.cfg


ProcessManager "Horae"\
                  "horae"\
                  "horae"

#屏蔽外壳温度（屏幕 背板 边框 软件）
Temp=20000

for i in $(seq 0 9); do
    lock_val "$i $Temp" /proc/shell-temp
done

for i in /sys/class/thermal/*
do
    if [ -f $i/temp ]; then
        case $(cat $i/type) in
              shell*)
                lock_val $Temp $i/emul_temp
              ;;
        esac
    fi
done

echo "已尝试将机身外壳温度伪装为'$Temp毫℃'"


