MODDIR=${0%/*}
source $MODDIR/MODS/PublicFuncs.sh


run_service(){
    for i in $(find ${0%/*}/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
      if [ -f "$i/service.sh" ]; then
        echo "###############——————###############"
        echo "【 $i： 】"
        echo "【 $(date +"%Y-%m-%d %H:%M:%S") 】"
        sh $i/service.sh
        echo "###############——————###############"
        echo
        echo
      fi
    done
    echo "【————ALL_ENDS_HERE————】"
}


wait_until_login;sleep 30

mkdir -p $MODDIR/LOG;rm -f $MODDIR/LOG/LOG_service.txt
run_service 2>&1 | tee -a $MODDIR/LOG/LOG_service.txt






