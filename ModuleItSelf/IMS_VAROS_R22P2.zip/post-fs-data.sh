MODDIR=${0%/*}
source $MODDIR/MODS/PublicFuncs.sh


run_post_fs_data(){
    for i in $(find ${0%/*}/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
      if [ -f "$i/post-fs-data.sh" ]; then
        echo "###############——————###############"
        echo "【 $i： 】"
        echo "【 $(date +"%Y-%m-%d %H:%M:%S") 】"
        sh $i/post-fs-data.sh
        echo "###############——————###############"
        echo
        echo
      fi
    done
    echo "【————ALL_ENDS_HERE————】"
}


CLEAR_IMS_CACHE

mkdir -p $MODDIR/LOG;rm -f $MODDIR/LOG/LOG_post-fs-data.txt
run_post_fs_data 2>&1 | tee -a $MODDIR/LOG/LOG_post-fs-data.txt
