set_perm_recursive $MODPATH 0 0 0755 0644
set_perm "$MODPATH/Bin/*" 0 0 0755
#读取模块ID，存入并用以初始化公用函数
MOD_ID=$(grep '^id=' $MODPATH/module.prop | cut -d'=' -f2 | tr -d '[:space:]')
sed -i "s|UnDentiFieD|$MOD_ID|g" $MODPATH/MODS/PublicFuncs.sh

[ -d /data/adb/modules/IMS ] && abort "请先卸载旧版模块"

run_customize(){
    echo -e "\n\n【————LOG_STARTS_HERE————】\n\n"
    echo "####################################"
    echo
    echo "  安卓版本：$(getprop 'ro.system.build.version.release')"
    echo "  设备 ABI：$(getprop 'ro.product.cpu.abi')"
    echo "  设备厂商：$(getprop 'ro.product.brand')"
    echo "  设备型号：$(getprop 'ro.product.device')"
    echo "  设备代号：$(getprop 'ro.product.model')"
    echo
    echo "  用户列表：$(pm list users)"
    echo "  当前用户：$(am get-current-user)"
    echo
    echo "####################################"
    echo -e "\n\n"
    local count=0
    for i in $(find $MODPATH/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
        let count+=1
        echo "【$count】子模块名称：$(cat $i/A_Introduction)"
        echo "（子模块文件夹：${i##*/}）"
            if [ -f "$i/customize.sh" ]; then
              echo "###############——————###############"
              echo "[ $(date +"%Y-%m-%d %H:%M:%S") ]"
              sh $i/customize.sh
              echo "###############——————###############"
            fi
            if [ -f "$i/system.prop" ]; then
              echo "#『${i##*/}/system.prop』#" >> "$MODPATH/system.prop"
              cat "$i/system.prop" >> "$MODPATH/system.prop"
              echo -e "\n#——————————————————————————#\n" >> "$MODPATH/system.prop"
            fi
        echo -e "\n\n"
    done
    echo -e "\n\n【————LOG_ENDS_HERE————】\n\n"
}


mkdir -p $MODPATH/LOG;rm -f $MODPATH/LOG/LOG_customize.txt
run_customize 2>&1 | tee -a $MODPATH/LOG/LOG_customize.txt


echo -e "\n\n"
echo "⭕［注意］———［注意］———［注意］⭕"
echo "> 可以在模块的MODS目录的ConfigTable.cfg自定义处理一些官调"
echo "> 模块具有多功能附加程序，可使用机身音量键、电源键操作"
echo
echo "> 模块无法完全屏蔽所有官调，但能助力第三方调度发挥"
echo "> 模块在开机2分钟后完全生效"
echo "> 遇到问题，尝试在模块完全生效后重启设备"
echo
echo "> 卸载模块即可恢复官调——复原除清空数据外的所有改动"
echo "> 如果发现官调没有恢复，可尝试清空［游戏助手］与［应用增强服务］的数据并重启设备"
echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n"








