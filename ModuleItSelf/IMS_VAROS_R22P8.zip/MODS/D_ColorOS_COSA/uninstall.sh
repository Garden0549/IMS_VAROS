if [ -n "$1" ]; then
    #解决使用action.sh执行该脚本时"$0（本脚本地址）"异常引起的变量错误问题
    CURFILE="$1"
else
    CURFILE="$0"
fi
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】

#————————————————————————————————————————

Backup_Dir=$CURMODDIR/COSABackup
Backup=$Backup_Dir/GameSchedulingConf.sql
Last_Backup=/data/cache/GameSchedulingConf.sql
COSA_Database_Dir=/data/data/com.oplus.cosa/databases
COSA_Database=$COSA_Database_Dir/db_game_database
sqlite3=$ROOTMODDIR/Bin/sqlite3
new_sqlite3=/data/cache/sqlite3
ReceiverCOSA=com.oplus.cosa/androidx.work.impl.background.systemalarm.RescheduleReceiver
ReceiverGames=com.oplus.games/androidx.work.impl.background.systemalarm.RescheduleReceiver
ReceiverIntent=android.intent.action.BOOT_COMPLETED

#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){

    #向[应用增强服务]的数据库注入[应用性能调度配置]的准备
    cp -f $sqlite3 $new_sqlite3 > /dev/null 2>&1
    cp -f $Backup $Last_Backup > /dev/null 2>&1

}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){

    #恢复[应用增强服务]被禁用的组件
    DEnable "e" "com.oplus.cosa/.gpalibrary.service.GPAService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.HyperBoostService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.CosaHyperBoostService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.oiface.OifaceService" > /dev/null 2>&1
    echo "已确保开启会被模块关闭的[应用增强服务]组件：俩Hyper GPA OiFace(如果有)"

    #检测当前条件是否足以继续向[应用增强服务]的数据库注入[应用性能调度配置]
    if $(AppStateChecker "e" "com.oplus.cosa"); then
        echo "[应用增强服务]已安装且已启用"
        if [ -f $Last_Backup ]; then
            echo "备份的[应用性能调度配置]存在，开始将其注入[应用增强服务]数据库"
        else
            echo "备份的[应用性能调度配置]不存在，不执行注入"
            pm clear "com.oplus.cosa" > /dev/null 2>&1 && echo "已成功清空[应用增强服务]数据，以尝试恢复其[应用性能调度配置]"
            rm -f $Last_Backup $new_sqlite3 && echo "已清除残留文件"
            return 1
        fi
    else
        echo "[应用增强服务]未安装或未启用，停止向其注入备份的[应用性能调度配置]"
        return 1
    fi

    #启动[应用增强服务]和[游戏助手(若已启用)]并等待其运行15秒以确保数据库正常创建
    DEnable "e" "$ReceiverCOSA" > /dev/null 2>&1
    am broadcast -a $ReceiverIntent -n $ReceiverCOSA > /dev/null 2>&1
    sleep 1
    if ps -A | grep "com.oplus.cosa" > /dev/null 2>&1; then
        echo "成功启动[应用增强服务]"
    else
        echo "未能启动[应用增强服务]，停止处理"
        return 1
    fi
    if $(AppStateChecker "e" "com.oplus.games"); then
        DEnable "e" "$ReceiverGames" > /dev/null 2>&1
        am broadcast -a $ReceiverIntent -n $ReceiverGames > /dev/null 2>&1
        sleep 1
        if ps -A | grep "com.oplus.games" > /dev/null 2>&1; then
            echo "成功启动[游戏助手]"
        else
            echo "未能启动[游戏助手]"
        fi
    fi
    echo "等待[应用增强服务]数据库构建中";sleep 15
    
    #杀死[应用增强服务]和[游戏助手]以关闭数据库保护，注入应用性能调度配置并给sqlite3一些运行时间
    am force-stop com.oplus.games
    am force-stop com.oplus.cosa
    $new_sqlite3 "$COSA_Database" "DROP TABLE IF EXISTS PackageConfigBean;"
    $new_sqlite3 $COSA_Database < $Last_Backup
    sleep 5
    
    #重启动[应用增强服务]和[游戏助手(若已启用)]以避免未知异常
    am broadcast -a $ReceiverIntent -n $ReceiverCOSA > /dev/null 2>&1
    sleep 1
    if ps -A | grep "com.oplus.cosa" > /dev/null 2>&1; then
        echo "成功复启动[应用增强服务]"
    else
        echo "未能复启动[应用增强服务]"
    fi
    if $(AppStateChecker "e" "com.oplus.games"); then
        am broadcast -a $ReceiverIntent -n $ReceiverGames > /dev/null 2>&1
        sleep 1
        if ps -A | grep "com.oplus.games" > /dev/null 2>&1; then
            echo "成功复启动[游戏助手]"
        else
            echo "未能复启动[游戏助手]"
        fi
    fi
    
    #检查[应用性能调度配置表]是否已恢复
    if $sqlite3 "$COSA_Database" "SELECT 1 FROM sqlite_master WHERE name='PackageConfigBean';" | grep -q "1"; then
        echo "[应用性能调度配置表]已注入[应用增强服务]数据库"
    else
        echo "[应用性能调度配置表]未能注入[应用增强服务]数据库"
    fi
    
    #清除残留文件
    rm -f $Last_Backup $new_sqlite3
}

#————————————————————————————————————————


AtPost
if [ -n "$1" ]; then
    AtService
else
    {
        wait_until_login;sleep 60
        AtService
    } &
fi











