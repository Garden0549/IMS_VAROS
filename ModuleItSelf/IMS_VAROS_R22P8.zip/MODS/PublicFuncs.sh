#【程序制作原则(V0.1)：】
# ①一劳永逸——非常坚韧玩不坏，全自动，不需要维护
# ②互斥模块化——维护轻松
# ③精简：函数功能不重复，函数内代码是已知的最简实现，注释十分清晰地讲解代码作用和逻辑——避免哪怕一丁点可能在日后造成冗余难以维护的代码
# ④必须或尽可能完成其顾及范围内的一切，并且没有别的延伸——很强的适应性
# 总目标：简单，适应性强，完全满足需求，玩不坏，利于维护
#【维护原则(V0.1)：】
# ①修改代码还需根据改变的内容，思考产生的连锁反应，以修改与之相关的东西
# ②还需提前规划好该怎么改
# ③将常用拓展功能加入该函数，减少外部代码冗余
#【进行上述一切的原则是：有需要再做】


#注意：[直接移植该脚本/取走部分函数]的注意事项
#1.考虑是否修改这个变量：CACHE_DIR_NAME——本脚本的缓存目录
#2.注意函数中是否用到该脚本中的[变量/函数]


#####——————————————————[BASIC]系列——————————————————#####
# 本脚本的：
    # 所在地址——CURFUNCFILE
    # 本脚本的名称——CURFUNCFILE_Name
CURFUNCFILE="$0"
CURFUNCFILE_Name="${CURFUNCFILE##*/}"
# 本脚本的：
    # 缓存目录名——CACHE_DIR_NAME
    # 缓存目录所在目录——CACHE_BASE_DIR
    # 缓存目录地址——CACHE_DIR
# 注意①：这三个变量的值只能由“大小写字母”“数字”“下划线”“/”组成
# 注意②：如果CACHE_DIR_NAME为空或空白字符，可能导致CACHE_BASE_DIR被chattr +i，而导致某些异常（如/data/cache被chattr +i导致无法开机）
CACHE_DIR_NAME="UnDentiFieD"
CACHE_BASE_DIR="/data/cache"
CACHE_DIR="$CACHE_BASE_DIR"/"$CACHE_DIR_NAME"
case "$CACHE_DIR_NAME" in
    *[![:space:]]*)
        # 创建本脚本缓存目录
        mkdir -p "$CACHE_DIR"
        ;;
    *)
        echo "'$CURFUNCFILE_Name'：本脚本内的变量'CACHE_DIR_NAME'的值不能为空或空白字符！"
        echo "退出脚本"
        exit 1
        ;;
esac
#####—————————————#####
#删除缓存目录
CACHE_Remover(){
  # 解除被脚本施加的"不可变性——chattr +i"
  chattr -i $CACHE_DIR/*
  # 删除整个缓存目录
  rm -rf $CACHE_DIR
}
#等待函数——等待系统完全启动，此时[数据或指令]才完全可以[编辑或使用]
wait_until_login() {
     # 确保/data加密被关闭
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done
    # 确保用户解锁屏幕
    until [ -d "/data/data/android" ]; do
        sleep 1
    done
}
#####——————————————————[BASIC]系列——————————————————#####



#####——————————————————[修改文件值]系列函数——————————————————#####
#对于以下四者，$1：输入值，$2：目标文件
#注意：加上单引号或双引号后，$2支持"通配符"但仍不能包含"空格"
#lock_val：锁值——卸载挂载，修改权限(组)
#mask_val：覆盖值——lock_val的基础上挂载同值文件
#immu_mask_val：固化覆盖值——mask_val的基础上使挂载文件不可变
#Empty_mask：等效清空文件——挂载空文件
##注意：为避免可能的[因无法读取原文件的死机或报错]，如效果足够，尽可能使用lock_val
lock_val() {
    local file
    
    find $2 -type f | while read -r file; do
        file="$(realpath "$file")"
        umount "$file" > /dev/null 2>&1
        chown root:root "$file" > /dev/null 2>&1
        chmod 0644 "$file" > /dev/null 2>&1
        echo "$1" >"$file"
        chmod 0444 "$file" > /dev/null 2>&1
    done
}
mask_val() {
    local file

    for file in $(find $2); do
        lock_val "$1" "$file"

        TIME="$(date "+%s%N")"
        echo "$1" >"$CACHE_DIR/mount_mask_$TIME"
        mount --bind "$CACHE_DIR/mount_mask_$TIME" "$file"
        restorecon -R -F "$file" > /dev/null 2>&1 || echo "mask_val：恢复安全上下文失败"
    done
}
immu_mask_val() {
    local file
    
    for file in $(find $2); do
        lock_val "$1" "$file"

        TIME="$(date "+%s%N")"
        echo "$1" >"$CACHE_DIR/mount_mask_$TIME"
        chattr +i "$CACHE_DIR/mount_mask_$TIME"
        mount --bind "$CACHE_DIR/mount_mask_$TIME" "$file"
        restorecon -R -F "$file" > /dev/null 2>&1 || echo "immu_mask_val：恢复安全上下文失败"
    done
}
Empty_mask(){
    local file
    
    for file in $(find $1); do
        umount "$file" > /dev/null 2>&1
        TIME="$(date "+%s%N")"
        touch "$CACHE_DIR/mount_mask_$TIME"
        mount --bind "$CACHE_DIR/mount_mask_$TIME" "$file"
        echo "已等效清空："$file""
    done
}
#####——————————————————[修改文件值]系列函数——————————————————#####



#####——————————————————[挂载]系列函数——————————————————#####
#单个地[挂载/卸载挂载点]兼恢复安全上下文
#检测选项合规性→校验参数个数→检测文件是否存在→[挂载/卸载挂载点]并恢复上下文
#$1：选项 若为-m(挂载)，$2：挂载文件 $3：挂载点
#$1：选项 若为-u(卸载挂载点)，$2：挂载点
Singlemount() {
    if [ $1 = "-m" ]; then
        local file="$2"
        local point="$3"
        
        if [ ! -e "$file" ]; then
            echo "挂载文件 '$file' 不存在。"
            return 1
        elif [ ! -e "$point" ]; then
            echo "挂载点 '$point' 不存在"
            return 1
        fi
        
        if mount --bind "$file" "$point" > /dev/null 2>&1; then
            echo "挂载成功：'$file' → '$point'"
            restorecon -RF "$point" > /dev/null 2>&1 || echo "恢复安全上下文失败"
        else
            echo "挂载失败：'$file'"
            return 1
        fi
        
    elif [ $1 = "-u" ]; then
        local point="$2"
        
        if [ ! -e "$point" ]; then
            echo "挂载点 '$point' 不存在"
            return 1
        fi
        
        if umount "$point" > /dev/null 2>&1; then
            echo "卸载挂载点成功：'$point'"
            restorecon -RF "$point" > /dev/null 2>&1 || echo "恢复安全上下文失败"
        else
            echo "卸载挂载点失败：'$point'"
            return 1
        fi
        
    else
        echo "错误：选项不合规"
        echo "函数[挂载]用法：Singlemount -m <挂载文件> <挂载点>"
        echo "函数[卸载挂载点]用法：Singlemount -u <挂载点>"
        return 1
        
    fi
}
#批量地[挂载/卸载挂载点]兼恢复安全上下文
#将[指定目录]里[第二层开始]的每个文件，挂载到对应的系统文件上，或对应地卸载被挂载的系统文件
#检测选项合规性→校验参数个数→[挂载/卸载挂载点]并恢复上下文
#$1：选项 -m(挂载) -u(卸载挂载点)，$2：[指定目录]
BatchMount(){
    if [ $1 = "-m" ]; then
        local target="$2"
        
        if [ ! -d "$2" ]; then
            echo "指定目录不存在：[$2]"
            return 1
        fi
        
        for C in $(find "$2" -type f -mindepth 2)
        do
            Singlemount "$1" "$C" "${C#$2}"
        done
    
    elif [ $1 = "-u" ]; then
        local target="$2"
        
        if [ ! -d "$2" ]; then
            echo "指定目录不存在：[$2]"
            return 1
        fi
        
        for C in $(find "$2" -type f -mindepth 2)
        do
            Singlemount "$1" "${C#$2}"
        done

    else
        echo "错误：选项不合规"
        echo "函数[挂载]用法：BatchMount -m <指定目录>"
        echo "函数[卸载挂载点]用法：BatchMount -u <指定目录>"
        return 1
        
    fi
}
#根据[挂载点]寻找被绑定的[源路径]
#如果能找到，返回[源路径]，如果找不到，返回1
#$1：挂载点
FindMount() {
    mount_point="$1"
    # 找到 mountinfo 中的行
    info=$(grep " $mount_point " /proc/self/mountinfo | head -n1)

    if [ -z "$info" ]; then
        return 1
    fi

    # 提取设备路径
    rel_src=$(echo "$info" | awk '{print $4}')
    device=$(echo "$info" | awk -F' - ' '{print $2}' | awk '{print $2}')
    # 查找设备挂载点（如 /data）
    mount_point_of_dev=$(mount | grep "$device" | awk '{print $3}' | head -n1)

    # 拼出完整路径
    echo "${mount_point_of_dev}${rel_src}"
}
#####——————————————————[挂载]系列函数——————————————————#####



#####——————————————————[进程、应用]系列函数——————————————————#####
#进程处理函数
#1.pidof获取进程pid，为空(进程不存在)，函数终止，不为空(进程存在)则继续→
#2.根据[自定义名]、[进程名]和其[服务名]，按照扩展[自定义项目名]得到的值处理进程，值有五种情况
#RESTART：stop&&start重启进程 PAUSE：kill -SIGSTOP暂停进程
#STOP：STOP关闭服务 ON：不做处理 其它值：报错并且不做处理
# 用例：
# 自定义项目名=值(可在其它配置文件定义再引用之)
# ProcessManager "自定义项目名" "服务名" "进程名"
ProcessManager(){
    #自定义项目名、服务名、进程名
    local Scheduler=$1
    local ServiceName=$2
    local ProcessName=$3
    local SchedulerValue=$(eval "echo \$$Scheduler")
    
    #进程PID
    local ProcessPid=$(pidof $ProcessName)

    echo "<————————————————————————————>"
    
    if [[ -n "$ProcessPid" ]]
    then
        echo ""$Scheduler"的进程"$ProcessName"运行中"
        echo "按照'$Scheduler'的值'$SchedulerValue'处理进程：'$ProcessName'"
        case $SchedulerValue in
            ON)
                echo "（$SchedulerValue）$Scheduler：不处理"
                ;;
            STOP)
                echo "（$SchedulerValue）$Scheduler：关闭"
                stop $ServiceName > /dev/null 2>&1 || echo "进程"$ProcessName"关闭失败！"$Scheduler"："$ServiceName"："$ProcessName""
                ;;
            PAUSE)
                echo "（$SchedulerValue）$Scheduler：暂停"
                kill -SIGSTOP $ProcessPid > /dev/null 2>&1 || echo "进程"$ProcessName"暂停失败！"$Scheduler"："$ServiceName"："$ProcessName""
                ;;
            RESTART)
                echo "（$SchedulerValue）$Scheduler：重启"
                stop $ServiceName > /dev/null 2>&1 || echo "进程"$ProcessName"重启(关闭)失败！"$Scheduler"："$ServiceName"："$ProcessName""
                start $ServiceName > /dev/null 2>&1 || echo "进程"$ProcessName"重启(启动)失败！"$Scheduler"："$ServiceName"："$ProcessName""
                ;;
            *)
                echo ""$Scheduler"的值"$SchedulerValue"不合规，不做处理"
                ;;
        esac
    else
        echo "进程"$ProcessName"不存在，不做处理"
    fi
    
    echo "<————————————————————————————>"
}
#检测[指定状态]是否符合[指定用户空间]的[指定应用]，[符合/不符合]反馈[0/1]
#输入参数有两种形式：
#$1：状态选项 $2：应用包名（不指定用户空间时，默认其为当前用户空间）
#$1：状态选项 $2：指定用户 $3：应用包名
#$1选项及含义：n未启用 e已启用 d已冻结 s已限制使用 i已安装
#其它：
#未指定检测应用是否安装但应用不存在会反馈：2
#[函数输入参数数量错误/检测选项不支持]会反馈：3
AppStateChecker() {
    local info
    local enabled
    local suspended

    if [ $# = 2 ]; then
        info=$(dumpsys package "$2" | grep -i "user $(am get-current-user)")
    elif [ $# = 3 ]; then
        info=$(dumpsys package "$3" | grep -i "user $2")
    else
        echo "参数数量错误"
        return 3
    fi

    if [ "$1" = "i" ]; then
        [ -n "$info" ] && return 0 || return 1
    else
        [ -z "$info" ] && return 2
    fi

    enabled=$(echo "$info" | tr ' ' '\n' | grep "enabled=" | cut -d= -f2 | tr -d '\n')
    suspended=$(echo "$info" | tr ' ' '\n' | grep "suspended=" | cut -d= -f2 | tr -d '\n')

    case "$1" in
        n) 
            [ "$enabled" = "0" ] && return 0 || return 1
            ;;
        e) 
            [ "$enabled" = "1" ] && return 0 || return 1
            ;;
        d) 
            [ "$enabled" = "2" ] || [ "$enabled" = "3" ] && return 0 || return 1
            ;;
        s) 
            [ "$suspended" = "true" ] && return 0 || return 1
            ;;
        *)
            echo "不支持的检测项"
            return 3
            ;;
    esac
}
###【PM指令集】###
#UInstall：
#输入参数有两种形式：
#$1：性质选项 $2：应用包名/apk文件
#$1：性质选项 $2：指定用户 $3：应用包名/apk文件
#$1各选项的含义：
#i：系统级安装指定安装包，再将其安装到指定用户（若不指定用户，默认其为主用户(0)）
#ie：将已系统级安装的应用安装到指定用户（若不指定用户，默认其为当前用户）（注意：将自动启用安装的应用）
#u：将应用从指定用户卸载（若不指定用户，默认其为所有用户(此时若应用在系统共享目录的APK无法删除时，该指令彻底无效)）
UInstall(){
    if [ $# = 2 ]; then
        if [ $1 = i ]; then
            echo "尝试为 '主用户(0) '安装' '$2'，结果："
            pm install "$2"
        elif [ $1 = ie ]; then
            echo "尝试为 '用户$(am get-current-user)' '安装并启用' '$2'，结果："
            pm install-existing "$2"
            pm enable "$2"
        elif [ $1 = u ]; then
            echo "尝试为 '所有用户' '卸载' '$2'，结果："
            pm uninstall "$2"
        else
            echo "不支持的选项"
            return 1
        fi
    elif [ $# = 3 ]; then
        if [ $1 = i ]; then
            echo "尝试为 '用户$2' '安装' '$3'，结果："
            pm install --user "$2" "$3"
        elif [ $1 = ie ]; then
            echo "尝试为 '用户$2' '安装并启用' '$3'，结果："
            pm install-existing --user "$2" "$3"
            pm enable --user "$2" "$3"
        elif [ $1 = u ]; then
            echo "尝试为 '用户$2' '卸载' '$3'，结果："
            pm uninstall --user "$2" "$3"
        else
            echo "不支持的选项"
            return 1
        fi
    else
        echo "参数数量错误"
        return 1
    fi
}
#DEnable：
#输入参数有两种形式：
#$1：性质选项 $2：应用包名/应用组件
#$1：性质选项 $2：指定用户 $3：应用包名/应用组件
#$1各选项的含义：
#e/d：在指定用户，[启用/禁用]指定[应用、应用组件]（若不指定用户，默认其为当前用户）
DEnable(){
    if [ $# = 2 ]; then
        if [ $1 = e ]; then
            echo "尝试为 '用户$(am get-current-user)' '启用' '$2'，结果："
            pm enable "$2"
        elif [ $1 = d ]; then
            echo "尝试为 '用户$(am get-current-user)' '禁用' '$2'，结果："
            pm disable "$2"
        else
            echo "不支持的选项"
            return 1
        fi
    elif [ $# = 3 ]; then
        if [ $1 = e ]; then
            echo "尝试为 '用户$2' '启用' '$3'，结果："
            pm enable --user "$2" "$3"
        elif [ $1 = d ]; then
            echo "尝试为 '用户$2' '禁用' '$3'，结果："
            pm disable --user "$2" "$3"
        else
            echo "不支持的选项"
            return 1
        fi
    else
        echo "参数数量错误"
        return 1
    fi
}
#Ususpend：
#输入参数有两种形式：
#$1：性质选项 $2：应用包名
#$1：性质选项 $2：指定用户 $3：应用包名
#$1各选项的含义：
#u/s：在指定用户，[解除限制使用/限制使用]指定应用（若不指定用户，默认其为当前用户）
USuspend(){
    if [ $# = 2 ]; then
        if [ $1 = u ]; then
            echo "尝试为 '用户$(am get-current-user)' '解除限制使用' '$2'，结果："
            pm unsuspend "$2"
        elif [ $1 = s ]; then
            echo "尝试为 '用户$(am get-current-user)' '限制使用' '$2'，结果："
            pm suspend "$2"
        else
            echo "不支持的选项"
            return 1
        fi
    elif [ $# = 3 ]; then
        if [ $1 = u ]; then
            echo "尝试为 '用户$2' '解除限制使用' '$3'，结果："
            pm unsuspend --user "$2" "$3"
        elif [ $1 = s ]; then
            echo "尝试为 '用户$2' '限制使用' '$3'，结果："
            pm suspend --user "$2" "$3"
        else
            echo "不支持的选项"
            return 1
        fi
    else
        echo "参数数量错误"
        return 1
    fi
}
#####——————————————————[进程、应用]系列函数——————————————————#####



#####——————————————————[按键选择]系列函数——————————————————#####
# 小结：
# key_register注册项目，key_running_lite/full执行项目
# 同一脚本内，可做到多次运行key_running_lite/full而不[打乱选择顺序]和[记录的选择]

#项目注册函数
#根据计数器设置动态变量以分别记录输入的五个参数：'项目名' '选择1的描述' '选择1的指令' '选择2的描述' '选择2的指令' 
#注意①：同一脚本内，项目名不能重复，不能[是/含有]空或空白字符
#注意②：为避免可能的复杂问题，建议将指令封装在函数里
key_register() {
    count_register=$((count_register + 1))
    eval "subject_${count_register}=\"$1\""
    eval "description1_${count_register}=\"$2\""
    eval "commands1_${count_register}=\"$3\""
    eval "description2_${count_register}=\"$4\""
    eval "commands2_${count_register}=\"$5\""
}
#按键信号检测函数
#key_click输出执行该函数后按下的第一个按键
# 还可输入一个参数$1——等待输入时长(时间格式同sleep指令)，此时暴露的TimeLeft表示剩余时间
# key_click是否为空可用于检测是否超时
# Time_Window_Interval表示采集按键的时间窗口，同时也是每次采集的时间间隔
key_checker() {
    key_click=""
    local TMP_EVENT_FILE="$CACHE_DIR/event_$$.tmp"
    local TimeTotal="$1"
    TimeLeft=""
    Time_Window_Interval="0.3"
    
    if [ -z "$TimeTotal" ]
    then
        while [ -z "$key_click" ]; do
            event_info=$(getevent -qlc 1)
            key_click=$(echo "$event_info" | awk '{ if ($2 == "EV_KEY" && $4 == "DOWN") print $3 }')
        done
    else
        TimeLeft="$TimeTotal"
        while [ -z "$key_click" ]; do
            TimeLeft=$(echo "$TimeLeft - $Time_Window_Interval" | bc)
    
            (getevent -qlc 1 > "$TMP_EVENT_FILE" &)
            sleep "$Time_Window_Interval"

            if [ -s "$TMP_EVENT_FILE" ]; then
                event_info=$(cat "$TMP_EVENT_FILE")
                key_click=$(echo "$event_info" | awk '{ if ($2 == "EV_KEY" && $4 == "DOWN") print $3 }')
            fi

            if [ $(echo "$TimeLeft <= 0" | bc) -eq 1 ]; then
                break
            fi
        done
    fi
}
#项目执行函数
#原理：根据计数器分别扩展来自key_register的5个变量，然后：[给出项目名和选择项描述] [接收按键信号，根据按键信号选择并执行对应代码]
#提示：
#  ①另可输入1个参数：等待时长(不带单位，单位为秒)，当存在该变量需决定是否开启"选择超时自动跳过"功能，不存在该变量时当作"不开启超时自动跳过"功能继续执行
#  ②按下音量键将直接退出该函数
#  ③为兼容key_running_full，在每次选择时，记录[项目名和所选选择的描述]
key_running_lite() {
    [ -z "$count_running" ] && count_running=0
    local description
    local subject
    local description1
    local commands1
    local description2
    local commands2
    local TimeTotal=$1
    local OUT="0"
    
    if [ -n "$TimeTotal" ]; then
        echo "是否开启'选择超时自动跳过'功能？（'$TimeTotal秒'超时）"
        echo "[音量 ↑ 键]：开启  [音量 ↓ 键]：关闭"
        TIMEOUT(){
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "> [开启]'超时自动跳过'功能（'$TimeTotal秒'超时）\n"
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "> [关闭]'超时自动跳过'功能 \n"
                    TimeTotal=""
                    ;;
                *)
                    key_checker;TIMEOUT
                    ;;
            esac
        }
        key_checker;TIMEOUT
    fi

    while [ $count_register -gt $count_running ]; do
        #准备要用到的各个变量
        count_running=$((count_running + 1))
        subject=$(eval "echo \$subject_${count_running}")
        description1=$(eval "echo \$description1_${count_running}")
        commands1=$(eval "echo \$commands1_${count_running}")
        description2=$(eval "echo \$description2_${count_running}")
        commands2=$(eval "echo \$commands2_${count_running}")
        
        #给出项目名和其两个选择的描述
        DESCRIPTION() {
            sleep 0.2
            echo "#——————————————————————————#"
            echo "🔧 当前项目：$subject"
            echo "   [音量 ↑ 键] $description1"
            echo "   [音量 ↓ 键] $description2"
            echo "#——————————————————————————#"
        }
        #根据项目名和按键选择，执行对应代码，并记录选择
        CASES() {
            if [ -z "$key_click" ]; then
                echo "> 选择超时"
                echo -e "\n\n"
                return 1
            fi
            case "$key_click" in
            "KEY_VOLUMEUP")
                echo "======================================"
                echo "> [音量 ↑ 键] $description1"
                echo
                echo "《————执行结果————》："
                eval "$commands1"
                echo "======================================"
                echo -e "\n\n"
                choice="$choice > $subject：$description1 \n"
                ;;
            "KEY_VOLUMEDOWN")
                echo "======================================"
                echo "> [音量 ↓ 键] $description2"
                echo
                echo "《————执行结果————》："
                eval "$commands2"
                echo "======================================"
                echo -e "\n\n"
                choice="$choice > $subject：$description2 \n"
                ;;
            *)
                echo "> [非音量键] 退出按键选择程序"
                OUT="1"
                ;;
            esac
        }
        DESCRIPTION
        key_checker "$TimeTotal"
        CASES
        [ "$OUT" = "1" ] && return 0
    done
}
#继承key_running_lite，并在遍历结束后，输出记录的[项目名和所选选择的描述]
key_running_full() {
    key_running_lite "$1"
    echo -e "\n\n\n\n"
    echo "#——————————————————————————#"
    echo
    echo "选择结果："
    echo
    echo -e "$choice"
    echo
    echo "#——————————————————————————#"
    echo -e "\n\n\n"
}
#####——————————————————[按键选择]系列函数——————————————————#####










