if [ -n "$1" ]; then
    #解决使用action.sh执行该脚本时"$0（本脚本地址）"异常引起的变量错误问题
    CURFILE="$1"
else
    CURFILE="$0"
fi
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



Backup_Dir=$CURMODDIR/COSABackup
Backup=$Backup_Dir/GameSchedulingConf.sql

Old_Dir=/data/adb/modules/IMS_VAROS/MODS/$CURMODDIR_NAME
Old_Backup=$Old_Dir/COSABackup/GameSchedulingConf.sql

COSA_Database=/data/data/com.oplus.cosa/databases/db_game_database
sqlite3=$ROOTMODDIR/Bin/sqlite3

mkdir -p $Backup_Dir


echo "开始检查是否有需要备份的[应用增强服务]应用性能调度配置表"
if [ -f $Old_Backup ]; then

    cp -f $Old_Backup $Backup_Dir
    echo -e "\n检测到该模块旧的[应用性能调度配置]备份\n已将其复制到本模块，将在卸载模块时恢复(如果此时[应用增强服务]已安装)\n"

elif [ -f $COSA_Database ]; then

    if $sqlite3 "$COSA_Database" "SELECT 1 FROM sqlite_master WHERE name='PackageConfigBean';" | grep -q "1"; then
        $sqlite3 "$COSA_Database" ".dump PackageConfigBean" > $Backup
        echo -e "\n已备份[应用性能调度配置]\n将在卸载模块时恢复(如果此时[应用增强服务]已安装)\n"
    else
        echo -e "\n[应用增强服务]数据库存在，但[应用性能调度配置表]不存在，无法备份配置\n"
    fi

else

    echo -e "\n未发现需要备份的[应用性能调度配置]\n"

fi

for i in com.oplus.cosa com.oplus.games
do
    if $(AppStateChecker "n" "$i"); then
        DEnable "e" "$i"
        echo "为避免可能的异常，已为当前用户矫正'$i'的启用状态"
    fi
done
touch $CURMODDIR/ClearCOSA && echo "为避免可能的异常，将在模块安装后的第一次重启清空[应用增强服务]的数据"





