CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

#重启PowerHAL配置的函数
#注意：必须在重启PowerHAL之后修改以避免参数文件被系统重置

RestartPowerHAL(){
    if [ $PowerHAL_Conf_AppCfg_Empty != 1 ] && [ $PowerHAL_Conf_Contbl_Empty != 1 ] && [ $PowerHAL_Conf_Scntbl_Empty != 1 ]
    then
        echo "没有电源配置需要清空，不重载PowerHAL配置"
        return 0
    fi

    for i in power-hal-1-0 vendor.mtkpower-service.mediatek vendor.mtkpower_applist-default; do
        if stop $i > /dev/null 2>&1; then
            start $i && echo "PowerHAL服务'$i'存在，且已重启"
        else
            echo "PowerHAL服务'$i'不存在"
        fi
    done
    echo "已尝试重载已清空的PowerHAL配置"
}

#————————————————————————————————————————

#修改MTK模块参数的函数
#注意：必须在重启PowerHAL之后修改以避免参数文件被系统重置

DealFPSGO(){
    FPSGO_Enable(){
        if [ ! -d /sys/kernel/fpsgo/ ] || [ ! -d /sys/module/mtk_fpsgo/ ]
        then
            echo "FPSGO不存在"
            return 1
        fi
        #FPSGO全局[强制]开关
        mask_val 0 /sys/kernel/fpsgo/common/force_onoff
        #FPSGO进程
        stop fpsgo
    
        echo "已尝试关闭FPSGO"
    
    
        if [ ! -d /sys/kernel/gbe/ ]
        then
            echo "GBE不存在"
            return 1
        fi
        #GBE全局开关
        mask_val 0 /sys/kernel/gbe/gbe_enable1
        mask_val 0 /sys/kernel/gbe/gbe_enable2
        #GBE进程
        stop gbe
    
        echo "已尝试关闭FPSGO单独外置的子模块GBE"
    }
    if [ $FPSGO_Disable = 1 ]
    then
        FPSGO_Enable
    else
        echo "未修改'FPSGO'相应参数"
    fi
    
    if [ $FPSGO_AffinityBoost_Disable = 1 ]
    then
        mask_val 0 /sys/kernel/fpsgo/minitop/enable
        mask_val 0 /sys/module/mtk_fpsgo/parameters/boost_affinity
        echo "已关闭FPSGO的线程放置子功能"
    else
        echo "未修改'FPSGO的线程放置子功能'相应参数"
    fi
}

MAGT_Disable(){
    if [ $MAGT_Disable = 1 ]; then
        stop magt > /dev/null 2>&1
        for i in thermal_aware_threshold fpsdrop_aware_threshold advice_bat_avg_current advice_bat_max_current targetfps_throttling_temp thermal_aware_light_threshold game_suggestion_jobworker
        do
            mask_val "-1" /sys/module/mtk_perf_ioctl_magt/parameters/$i > /dev/null 2>&1
        done
        echo "已尝试通过sysfs参数更彻底地关闭MAGT"
    else
        start magt > /dev/null 2>&1
    fi
    
    MAGTProp=ro.vendor.magt.mtk_magt_support
    echo "MAGT属性'$MAGTProp'当前值：$(getprop $MAGTProp)"
    if pidof magt > /dev/null 2>&1; then
        echo "MAGT进程已启动，进程PID为'$(pidof magt)'"
    else
        echo "MAGT进程未启动"
    fi
}

DealCoreCtl(){
    #MTK设备特有
    mask_val 0 /sys/module/mtk_core_ctl/parameters/policy_enable
    
    #安卓系统共有
    #可用CPU核心数控制
    #(在MTK设备上,重启PowerHAL进程会重置以下所有文件)
    for i in /sys/devices/system/cpu/cpu*; do
        if [ -f $i/core_ctl/enable ]; then
          lock_val 1 $i/core_ctl/enable
        fi
        if [ -f $i/core_ctl/min_cpus ]; then
          lock_val 99 $i/core_ctl/min_cpus
        fi
        if [ -f $i/core_ctl/max_cpus ]; then
          lock_val 99 $i/core_ctl/max_cpus
        fi
        if [ -f $i/core_ctl/enable ]; then
          lock_val 0 $i/core_ctl/enable
        fi
    done
    
    echo "已关闭[自动关闭CPU核心的内核模块]"
    echo "已执行[阻止系统自动关闭CPU核心]的代码"
}

DealGPUCtl(){
    sh $CURMODDIR/GPU.sh
}

#————————————————————————————————————————

if [ "$(getprop ro.hardware)" != "qcom" ]
then
    echo -e "\n联发科芯片，执行联发科特别屏蔽\n"
    echo "<——————————————————>"
    RestartPowerHAL
    echo "<——————————————————>"
    DealFPSGO
    echo "<——————————————————>"
    MAGT_Disable
    echo "<——————————————————>"
    DealCoreCtl
    echo "<——————————————————>"
    DealGPUCtl
    echo "<——————————————————>"
else
    echo "非联发科芯片，不执行联发科特别屏蔽"
fi

#————————————————————————————————————————





