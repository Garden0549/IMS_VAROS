CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#可用CPU核心数控制
#(在MTK设备上,重启PowerHAL进程会重置以下所有文件)
KILL_CORECTL(){
    for i in /sys/devices/system/cpu/cpu*; do
        if [ -f $i/core_ctl/enable ]; then
          lock_val 1 $i/core_ctl/enable
        fi
        if [ -f $i/core_ctl/min_cpus ]; then
          lock_val 99 $i/core_ctl/min_cpus
        fi
        if [ -f $i/core_ctl/max_cpus ]; then
          lock_val 99 $i/core_ctl/max_cpus
        fi
        if [ -f $i/core_ctl/enable ]; then
          lock_val 0 $i/core_ctl/enable
        fi
    done
}
KILL_CORECTL
echo "已执行[阻止系统自动关闭CPU核心]的代码"









