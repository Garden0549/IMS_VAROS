MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



run_service(){
    echo -e "\n\n【————LOG_STARTS_HERE————】\n\n"
    for i in $(find ${0%/*}/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
        if [ -f "$i/service.sh" ]; then
          echo "###############——————###############"
          echo "【 $i： 】"
          echo "【 $(date +"%Y-%m-%d %H:%M:%S") 】"
          sh $i/service.sh
          echo "###############——————###############"
          echo -e "\n\n"
        fi
    done
    echo -e "\n\n【————LOG_ENDS_HERE————】\n\n"
}


wait_until_login;sleep 30

mkdir -p $MODDIR/LOG;rm -f $MODDIR/LOG/LOG_service.txt
run_service 2>&1 | tee -a $MODDIR/LOG/LOG_service.txt






