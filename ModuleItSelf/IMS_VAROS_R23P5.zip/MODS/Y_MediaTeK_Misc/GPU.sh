CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#<————————————↓↓↓———［GED］———↓↓↓————————————>#

GED_KPI(){
    if [ $GED_KPI_Enable = 0 ]; then
        mask_val 0 /sys/module/ged/parameters/is_GED_KPI_enabled
        echo "『GED』已关闭GED_KPI"
    else
        mask_val 1 /sys/module/ged/parameters/is_GED_KPI_enabled
        echo "『GED』已开启GED_KPI"
    fi
}

#<——————————————————————————————————————>#

SpecificFunc(){
    DCS=/sys/kernel/ged/hal/dcs_mode
    FastDVFS=/sys/kernel/ged/hal/fastdvfs_mode
    SmartBoost=/sys/module/ged/parameters/ged_smart_boost
    
    for i in DCS FastDVFS SmartBoost
    do
        eval File=\$$i
        eval FileSwitch=\$${i}_Disable
        if [ -f $File ]
        then
            if [ $FileSwitch = 1 ]
            then
                mask_val 0 "$File"
                echo "『GED』已关闭：'$i'"
            else
                echo "『GED』未修改：'$i'——'$File'"
            fi
        else
            echo "『GED』不存在而未处理：'$i'——'$File'"
        fi
    done
}

#<——————————————————————————————————————>#

Custom_MaxMinFreq(){
    lock_val $Custom_Max_Freq /sys/kernel/ged/hal/custom_upbound_gpu_freq
    lock_val $Custom_Min_Freq /sys/kernel/ged/hal/custom_boost_gpu_freq
    Max_Freq="$(cat /sys/module/ged/parameters/gpu_cust_upbound_freq)"
    Min_Freq="$(cat /sys/module/ged/parameters/gpu_cust_boost_freq)"
    echo "『GED』GPU频率［实际上限］设为：$(echo "$Max_Freq / 1000" | bc) MHz"
    echo "『GED』GPU频率［实际下限］设为：$(echo "$Min_Freq / 1000" | bc) MHz"
}

#<——————————————————————————————————————>#

Force_LB(){
    if [ $Force_LB_Enable = 1 ]; then
        mask_val 1 /sys/kernel/ged/hal/force_loading_base > /dev/null 2>&1
        mask_val 1000 /sys/module/ged/parameters/g_fb_dvfs_threshold > /dev/null 2>&1
        echo "『GED』强制使用'负载基'模式"
    else
        mask_val 0 /sys/kernel/ged/hal/force_loading_base > /dev/null 2>&1
        mask_val 80 /sys/module/ged/parameters/g_fb_dvfs_threshold > /dev/null 2>&1
        echo "『GED』恢复系统默认设置，自动切换调频模式"
    fi
}

#<——————————————————————————————————————>#

LB_Old(){
    if [ $LB_Old_Enable = 0 ]; then
        mask_val 0 /sys/module/ged/parameters/g_gpu_timer_based_emu
        echo "『GED』'负载基-旧'模式已关闭"
    else
        mask_val 1 /sys/module/ged/parameters/g_gpu_timer_based_emu
        echo "『GED』'负载基-旧'模式已开启，将取代'负载基-新'模式"
    fi
}

#<——————————————————————————————————————>#

LB_New_Margin(){
    LB_New_Margin_FinValue=$((LB_New_Margin_StaticMargin))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynEnable << 8)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynUsePipeTime << 9)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynPerfMode << 10)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynFixTargetFPS30 << 11)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynMinMargin << 16)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynStepSize << 24)))
    
    echo "『GED』'负载基-新''余量'各子项合成值：$LB_New_Margin_FinValue"
    mask_val $LB_New_Margin_FinValue /sys/kernel/ged/hal/timer_base_dvfs_margin
}

#<——————————————————————————————————————>#

LB_New_UltraStep(){
    LB_New_UltraStep_FinValue=$(( (LB_New_UltraStep_Bit8_15 << 8) | LB_New_UltraStep_Bit0_7 ))
    
    echo "'『GED』负载基-新''极端负载步长'各子项合成值：$LB_New_UltraStep_FinValue（十六进制：$(echo "obase=16; $LB_New_UltraStep_FinValue" | bc)）"
    mask_val $LB_New_UltraStep_FinValue /sys/kernel/ged/hal/loading_base_dvfs_step
    
    Platform=$(getprop 'ro.board.platform')
    if [ "$LB_New_UltraStep_FinValue" = 0 ]
    then
        if [ "$Platform" = "mt6895" ] || [ "$Platform" = "mt6983" ]
        then
            mask_val 0 /sys/kernel/ged/hal/loading_window_size
            echo "『GED』为避免可能的GPU无法升频的情况，已修改'loading_window_size'的值为0"
        fi
    fi
}

#<——————————————————————————————————————>#

FB_Margin(){
    if { [ "$FB_Margin" -ge 401 ] && [ "$FB_Margin" -le 499 ]; } || { [ "$FB_Margin" -ge 501 ] && [ "$FB_Margin" -le 599 ]; }; then
        FB_Margin_FinValue=$(( FB_Margin | (FB_Margin_MinStep << 10) | (FB_Margin_MinMargin << 16) ))
    else
        FB_Margin_FinValue=$FB_Margin
    fi
    
    echo "『GED』'帧基''余量'值：$FB_Margin_FinValue"
    mask_val $FB_Margin_FinValue /sys/kernel/ged/hal/dvfs_margin_value
}

#<————————————↑↑↑———［GED］———↑↑↑————————————>#


#<————————————↓↓↓———［GPT］———↓↓↓————————————>#

GPT(){
    GPT=/sys/kernel/thermal/gpt
    if [ -f $GPT ]; then
        if [ $GPT_Enable = 1 ]; then
            echo "『GPT』已尝试开启GPT功能并调整其参数"
            mask_val "enable" /sys/kernel/thermal/gpt
            mask_val "gpt 1 $GPT_Thrm1" /sys/kernel/thermal/gpt
            mask_val "gpt 2 $GPT_Thrm2" /sys/kernel/thermal/gpt
        else
            echo "『GPT』已尝试关闭GPT功能！"
            mask_val "disable" /sys/kernel/thermal/gpt
        fi
    else
        echo "『GPT』本设备不存在GPT，不做处理"
    fi
}

#<————————————↑↑↑———［GPT］———↑↑↑————————————>#

GED(){
    echo "#============#"

    GED_KPI
    
    echo "#============#"
    
    SpecificFunc
    
    echo "#============#"
    
    Custom_MaxMinFreq
    
    echo "#============#"
    
    Force_LB
    
    echo "#============#"
    
    LB_Old
    
    echo "#============#"
    
    LB_New_Margin
    
    echo "#============#"
    
    LB_New_UltraStep
    
    echo "#============#"
    
    FB_Margin
    
    echo "#============#"
}



[ $GED = 1 ] && GED
GPT







