CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

PerformanceBoosts(){
    local PerformanceBoosts_Conf="/vendor/etc/perf/perfboostsconfig.xml"
    if [ -e "$PerformanceBoosts_Conf" ]; then
        if [ "$PerformanceBoosts_Conf_Empty" = 1 ]; then
            if Empty_mask "$PerformanceBoosts_Conf" > /dev/null 2>&1
            then
                echo "『PerformanceBoosts』成功等效清空配置文件，以等效关闭本官调"
            else
                echo "『PerformanceBoosts』未能等效清空配置文件"
            fi
        else
            echo "『PerformanceBoosts』不清空配置文件"
        fi
    else
        echo "『PerformanceBoosts』未找到配置文件"
    fi
}

#————————————————————————————————————————

if [ "$(getprop ro.hardware)" = "qcom" ]
then
    echo -e "\n高通平台，执行高通特别屏蔽\n"
    echo "<——————————————————>"
    PerformanceBoosts
    echo "<——————————————————>"
else
    echo "非高通平台，不执行高通特别屏蔽"
fi

#————————————————————————————————————————
