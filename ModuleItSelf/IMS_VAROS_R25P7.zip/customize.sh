set_perm_recursive $MODPATH 0 0 0755 0644
set_perm "$MODPATH/Bin/*" 0 0 0755

#————————————————#

source $MODPATH/MODS/PublicFuncs.sh
source $MODPATH/MODS/ConfigTable.cfg

#————————————————#

[ -d /data/adb/modules/IMS ] && abort "请先卸载旧版模块"

#————————————————#



run_customize(){
    DelayedLineFeeder "2" "--0.05"
    DelayedPrinter "【————————LOG_STARTS_HERE————————】"
    DelayedPrinter "【————————LOG_STARTS_HERE————————】"
    DelayedPrinter "【————————LOG_STARTS_HERE————————】"
    DelayedLineFeeder "5" "--0.05"
    
    DelayedPrinter "####################################"
    DelayedPrinter
    DelayedPrinter "  设备厂商：$(getprop 'ro.product.brand')"
    DelayedPrinter "  设备代号：$(getprop 'ro.product.model')"
    DelayedPrinter "  搭载平台：$(getprop 'ro.board.platform')"
    DelayedPrinter "  设备 ABI：$(getprop 'ro.product.cpu.abi')"
    DelayedPrinter "  安卓版本：$(getprop 'ro.system.build.version.release')"
    DelayedPrinter "   版本号 ：$(getprop 'ro.build.display.id')"
    DelayedPrinter
    DelayedPrinter "  当前用户：$(am get-current-user)"
    DelayedPrinter "  用户列表：$(pm list users)"
    DelayedPrinter
    DelayedPrinter "####################################"
    DelayedLineFeeder "3" "--0.05"
    sleep 3

    local count=0
    for i in $(find $MODPATH/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
        let count+=1
        DelayedPrinter "【$count】『子模块文件夹名称：${i##*/}』"
        while IFS= read -r Line || [ -n "$Line" ]; do
            DelayedPrinter "$Line"
        done < "$i/A_Introduction"

        if [ -f "$i/customize.sh" ]; then
            DelayedPrinter "###########———［ $(date +"%Y-%m-%d %H:%M:%S") ］———###########"
            sh "$i/customize.sh"
            DelayedPrinter "###########———［ $(date +"%Y-%m-%d %H:%M:%S") ］———###########"
        fi
        if [ -f "$i/system.prop" ]; then
            {
                echo "#————『${i##*/}/system.prop』————#"
                cat "$i/system.prop"
                echo -e "\n#——————————————————————————#\n"
            } >> "$MODPATH/system.prop"
        fi

        DelayedLineFeeder "4" "--0.05"
        sleep 0.3
    done
    
    DelayedLineFeeder "5" "--0.05"
    DelayedPrinter "【————————LOG_ENDS_HERE————————】"
    DelayedPrinter "【————————LOG_ENDS_HERE————————】"
    DelayedPrinter "【————————LOG_ENDS_HERE————————】"
    DelayedLineFeeder "5" "--0.05"
}


mkdir -p $MODPATH/LOG;rm -f $MODPATH/LOG/LOG_customize.txt
run_customize 2>&1 | tee -a $MODPATH/LOG/LOG_customize.txt


DelayedLineFeeder "2" "--0.15"
DelayedPrinter "--0.15" "⭕［注意］———————［注意］———————［注意］⭕"
DelayedPrinter "--0.15"
DelayedPrinter "--0.15" "［——————模块额外功能——————］"
DelayedPrinter "--0.15" "> ①在模块目录的文件［/MODS/ConfigTable.cfg］里，可以自定义处理一些官调"
DelayedPrinter "--0.15" "> ②在模块目录的子目录［/Assistance/］里有如下文件："
DelayedPrinter "--0.15" "   -  更新日志.md"
DelayedPrinter "--0.15" "   -  模块介绍.md"
DelayedPrinter "--0.15" "> ③安装模块后，在模块目录里的子目录［/LOG/］里，可以找到模块运行时记录的日志"
DelayedPrinter "--0.15" "> ④本模块具有内含多个功能的附加程序，可以在ROOT管理器的模块列表里找到"
DelayedPrinter "--0.15" "  ［注意：］"
DelayedPrinter "--0.15" "  ［由于模块默认配置足够屏蔽官方调度，所以：］"
DelayedPrinter "--0.15" "  ［若非为了调试，不用在意上述内容，以避免无谓的疑问或焦虑］"
DelayedPrinter "--0.15"
DelayedPrinter "--0.15"
DelayedPrinter "--0.15" "［——————其它注意事项——————］"
DelayedPrinter "--0.15" "> ①模块在开机2分钟后完成启动"
DelayedPrinter "--0.15" "> ②模块无法完全屏蔽所有官调，但能助力第三方调度发挥"
DelayedPrinter "--0.15" "> ③卸载模块，即可复原模块除清空应用数据以外的所有改动"
DelayedPrinter "--0.15" "> ④如果已将游戏加入［游戏助手］，游戏内［游戏助手侧边栏］不出现，其核心原理是："
DelayedPrinter "--0.15" "  【［游戏助手侧边栏］依赖［应用增强服务］，后者无法启动时前者亦无法启动】"
DelayedPrinter "--0.15" "  可尝试以下方法："
DelayedPrinter "--0.15" "  ［1］开启安卓系统的'APP数据隔离'： "
DelayedPrinter "--0.15" "    - 安装应用［隐藏应用列表］并授予其ROOT权限"
DelayedPrinter "--0.15" "    - 打开其内'App data 隔离'这个开关"
DelayedPrinter "--0.15" "    - 最后，重启设备"
DelayedPrinter "--0.15" "  【原理】若安卓系统的'APP数据隔离'关闭，可能会导致［应用增强服务］无法读写其数据目录而崩溃并终止，无法启动"
DelayedPrinter "--0.15" "  ［2］在LSPosed中，关闭Thanox，重启设备"
DelayedPrinter "--0.15" "  【原理】Thanox的某个功能可能阻止了［应用增强服务］［游戏助手］在游戏里自启动"
DelayedPrinter "--0.15" "  ［3］彻底关闭已安装的“墓碑”，重启设备"
DelayedPrinter "--0.15" "  【原理】“墓碑”可能冻结而阻止了［应用增强服务］［游戏助手］在游戏里自启动"
DelayedPrinter "--0.15" "  ［4］卸载再安装［应用增强服务］"
DelayedPrinter "--0.15" "  【原理】确保［应用增强服务］已安装且已启用"
DelayedPrinter "--0.15"
DelayedPrinter "--0.15" "⭕［注意］———————［注意］———————［注意］⭕"
DelayedLineFeeder "14" "--0.15"
sleep 3









