CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

ConfigDisposer(){
    #功能：
    #   在 指定遍历目录，寻找 指定文件，根据 开关变量的值 决定是否用 指定挂载源 挂载之
    #用法：
    # Mounter "日志输出对象名" \
    #     "指定文件之名" "指定文件之后缀" "指定遍历目录" \
    #     "指定挂载源" \
    #     "开关变量名" \
    #注意：
    #   ①本函数引用的外来函数：SingleMount
    #   ②"指定挂载源"必须是1个文件
    #   ③开关变量的值为1时挂载文件，否则不挂载文件
    Mounter(){
        local Object="$1"
        local CurrentFileName="$2"
        local CurrentFileSuffix="$3"
        local CurrentFile="${CurrentFileName}${CurrentFileSuffix}"
        local TraverseDirs="$4"
        local MountSourceFile="$5"
        local Switch="$(eval "echo \$$6")"
        local FileNumCount="0"
    
    
        for i in $(find $TraverseDirs -name "$CurrentFile" -type f 2>/dev/null)
        do
            FileNumCount="$(( FileNumCount + 1 ))"
            eval "local File_${FileNumCount}='$i'"
        done
        if [ "$Switch" = "1" ]
        then
            if [ "$FileNumCount" = "0" ]
            then
                echo "『$Object』未找到配置［$CurrentFile］"
                return 1
            else
                for i in $(seq 1 $FileNumCount)
                do
                    Temp="$(eval "echo \$File_${i}")"
                    SingleMount "-u" "$Temp" >/dev/null 2>&1
                    SingleMount "-m" "$MountSourceFile" "$Temp"
                done
            fi
            echo
            echo "『$Object』已尝试挂载配置［$CurrentFile］"
        else
            echo "『$Object』不挂载配置［$CurrentFile］"
        fi
    }
    #功能：
    #   （以下"元素"均属于xml语法）
    #   将 指定文件里，指定值的Name元素 到 下一Name元素 之间的 1个Enable元素 的值 改为指定值
    #注意：
    #   ①如果发现［0/多于1］个Enable元素，函数将报错并停止
    #用法：
    #   XmlEditor <指定文件> \
    #   <指定值的Name元素> <Enable元素指定值>
    XmlEditor() {
        file="$1"
        name="$2"
        newval="$3"
    
    
        if [ $# -ne 3 ]; then
            echo "『XmlEditor』用法：<指定文件> <指定值的Name元素> <Enable元素指定值>" >&2
            return 1
        elif [ ! -e "$file" ]; then
            echo "『XmlEditor』⭕ 指定文件不存在（$file）"
            return 1
        fi
    
        # 提取从 指定值的Name元素 到 下一Name元素(不含结束行) 间的 Enable元素
        block=$(sed -n "/<Name>${name}<\/Name>/,/<Name>.*<\/Name>/{
            /<Name>.*<\/Name>/!p
        }" "$file")
    
        # 统计提取内容中 Enable元素 的个数
        enable_count=$(printf '%s\n' "$block" | grep -c '^[[:space:]]*<Enable>.*</Enable>[[:space:]]*$')
    
        if [ "$enable_count" != "1" ]; then
            echo "『XmlEditor』⭕ 区间内Enable元素不为1个，而为$enable_count个，不做处理" >&2
            return 1
        fi
    
        # 转义 newval 中的特殊字符（用于 sed 替换）
        escaped_val=$(printf '%s\n' "$newval" | sed 's/[\&/]/\\&/g')
    
        # 在相同范围内替换 <Enable> 的值
        sed -i "/<Name>${name}<\/Name>/,/<Name>.*<\/Name>/{
            s|<Enable>[^<]*</Enable>|<Enable>${escaped_val}</Enable>|
        }" "$file"
    }
    #功能：
    #   将 指定文件 复制到 输出地址， 再将其内 指定词 ［全词匹配］替换为 指定替换词
    #注意：
    #   ①<指定词>只支持单个词，不能为空
    #用法：
    #   XmlReplacer \
    #   <指定文件地址> <输出地址> \
    #   <指定词> <指定替换词>
    XmlReplacer(){
        local TargetFile="$1"
        local TargetFileName="${1##*/}"
        local OutPutAddress="$2"
        local OutPutFile=""
        local TargetString="$3"
        local AlternativeString="$4"
        
        
        if [ ! -e "$TargetFile" ]; then
            echo "『XmlReplacer』指定文件［$TargetFile］不存在！"
            return 1
        elif [ -z "$TargetString" ]; then
            echo "『XmlReplacer』指定词不能为空！"
            return 1
        fi
    
        if [ -d "$OutPutAddress" ]; then
            OutPutFile="$OutPutAddress/$TargetFileName"
        elif [ -f "$OutPutAddress" ]; then
            OutPutFile="$OutPutAddress"
        else
            echo "『XmlReplacer』输出地址不存在！"
            return 1
        fi
        
        cp -p "$TargetFile" "$OutPutAddress"
        if [ "$?" = 0 ]; then
            sed -i "s/\b$TargetString\b/$AlternativeString/g" "$OutPutFile"
        else
            echo "『XmlReplacer』存在错误！"
            return 1
        fi
    }

    #——————————————————#

    CD_Perf(){
        CD_ConfigPatcher(){
            local ConfigDir="$CURMODDIR/CustomConf"
            local Configs="
                perfboostsconfig.xml\
                qapeboostsconfig.xml\
                qapeconfigstore.xml\
                QAPE.xml\
            "
            local TraverseDirs="
                /vendor\
                /odm\
            "

            for CurrentFile in $Configs
            do
                #宁愿允许后续修补失败而未能生成文件，也不能允许挂载后可能不合目的的文件的存在
                rm -f "$ConfigDir/$CurrentFile"
                for i in $(find $TraverseDirs -name "$CurrentFile" -type f 2>/dev/null)
                do
                    umount "$i" >/dev/null 2>&1
                    #既然要完全关闭配置，则不管修补哪个目录的文件，都能达到目的
                    XmlReplacer \
                        "$i" "$ConfigDir" \
                        "true" "false"
                    break
                done
            done
        }

        CD_PerformanceBoosts(){
            CD_PerformanceBoosts_ConfigCleaner(){
                local EmptyConfig="$CURMODDIR/CustomConf/perfboostsconfig.xml"
                local Configs="
                    perfboostsconfig.xml\
                "
                local TraverseDirs="
                    /vendor\
                    /odm\
                "
    
    
                echo "===========［等效关闭PerformanceBoosts配置］==========="
                for i in $Configs
                do
                    CurrentConfigName="${i%.xml}"
    
                    Mounter "PerformanceBoosts" \
                        "$CurrentConfigName" ".xml" "$TraverseDirs" \
                        "$EmptyConfig" \
                        "PerformanceBoosts_Disable"
                done
                echo "================================================="
            }
            
            CD_PerformanceBoosts_ConfigCleaner
        }
        CD_QAPE(){
            CD_QAPE_ConfigMounter(){
                local ConfigDir="$CURMODDIR/CustomConf"
                local Configs_xml="
                    qapeboostsconfig.xml\
                    qapeconfigstore.xml\
                    QAPE.xml\
                    factorsconfig.xml\
                    QGPE.xml\
                    QGPEActionMap.xml\
                "
                local Configs_txt="
                    qapegameconfig.txt\
                "
                local TraverseDirs="
                    /vendor\
                    /odm\
                "
        
                
                echo "===========［等效关闭QAPE配置］==========="
                for i in $Configs_xml
                do
                    CurrentConfigName="${i%.xml}"
                    CurrentMountSource="$ConfigDir/$i"
        
                    Mounter "QAPE" \
                        "$CurrentConfigName" ".xml" "$TraverseDirs" \
                        "$CurrentMountSource" \
                        "QAPE_Disable"
                    echo "==========================="
                done
                
                for i in $Configs_txt
                do
                    CurrentConfigName="${i%.txt}"
                    CurrentMountSource="$ConfigDir/$i"
        
                    Mounter "QAPE" \
                        "$CurrentConfigName" ".txt" "$TraverseDirs" \
                        "$CurrentMountSource" \
                        "QAPE_Disable"
                    echo "==========================="
                done
                echo "================================================="
            }

            CD_QAPE_ConfigMounter
        }
        CD_QSPM(){
            CD_QSPM_ConfigCleaner(){
                local Files="$(find /data/vendor/gaming -mindepth 1 -type f)"
                
                echo "===========［等效清空QSPM配置］==========="
                if [ -z "$Files" ]; then
                    echo "『QSPM』没有需要清空的配置"
                else
                    for i in $Files
                    do
                        Mask "$i"
                    done
                    echo "『QSPM』已尝试清空配置"
                fi
                echo "================================================="
            }

            CD_QSPM_ConfigCleaner
        }

        #后续函数会挂载此函数修补的配置文件
        #为用上正确的配置文件，必须修补
        CD_ConfigPatcher

        if [ "$PerformanceBoosts_Disable" = "1" ]
        then
            CD_PerformanceBoosts
        else
            echo -e "\n『PerformanceBoosts』不清空任何配置\n"
        fi        

        if [ "$QAPE_Disable" = "1" ]
        then
            CD_QAPE
        else
            echo -e "\n『QAPE』不清空任何配置\n"
        fi

        if [ "$QSPM_Disable" = "1" ]
        then
            CD_QSPM
        else
            echo -e "\n『QSPM』不清空任何配置\n"
        fi
    }
    CD_PowerOpt(){
        CD_PowerOpt_ConfigCleaner(){
            local EmptyConfig="$CURMODDIR/CustomConf/PowerOptFeatureEmptyConfig.xml"
            local TotalFeatureConfig="$CURMODDIR/CustomConf/PowerFeatureConfig.xml"
            local OringinTotalFeatureConfig="/vendor/etc/pwr/PowerFeatureConfig.xml"
            local Configs="
                GamePowerOptFeature.xml\
                CameraPowerOptFeature.xml\
                OffScreenPowerOptFeature.xml\
                PSMPowerOptFeature.xml\
                VideoPowerOptFeature.xml\
            "
            local TraverseDirs="
                /data/vendor/pwr\
                /vendor\
                /odm\
            "
            
            echo "===========［关闭PowerOpt特性］==========="
            rm -f "$TotalFeatureConfig"
            cp -f "$OringinTotalFeatureConfig" "$TotalFeatureConfig"

            for i in $Configs
            do
                CurrentConfigName="${i%.xml}"
                CurrentSwitch="${CurrentConfigName}_Disable"

                Mounter "PowerOpt" \
                    "$CurrentConfigName" ".xml" "$TraverseDirs" \
                    "$EmptyConfig" \
                    "$CurrentSwitch"
                
                echo "==========================="
                
                [ "$(eval "echo \$$CurrentSwitch")" = "1" ] && \
                XmlEditor "$TotalFeatureConfig" "$CurrentConfigName" "0"
                
            done
            
            PowerFeatureConfigEdited="1"
            Mounter "PowerOpt" \
                "PowerFeatureConfig" ".xml" "$TraverseDirs" \
                "$TotalFeatureConfig" \
                "PowerFeatureConfigEdited"

            echo "================================================="
        }


        

        if \
          [ "$GamePowerOptFeature_Disable" = "1" ] || \
          [ "$CameraPowerOptFeature_Disable" = "1" ] || \
          [ "$OffScreenPowerOptFeature_Disable" = "1" ] || \
          [ "$PSMPowerOptFeature_Disable" = "1" ] || \
          [ "$VideoPowerOptFeature_Disable" = "1" ]
        then
            CD_PowerOpt_ConfigCleaner
        else
            echo -e "\n『PowerOpt』不清空任何配置\n"
        fi
    }



    #————『ConfigDisposer_函数执行区』————#
    CD_Perf
    CD_PowerOpt
}

#————————————————————————————————————————

Perf(){
    QAPE(){
        if [ "$QAPE_Disable" = "1" ]; then
            resetprop -n ro.vendor.perf.qape "false"
            resetprop -n ro.vendor.perf.qgpe "false"
            echo "『QAPE』已尝试通过修改系统属性关闭QAPE"
        else
            echo "『QAPE』不做修改"
        fi
    }
    QSPM(){
        if [ "$QSPM_Disable" = "1" ]; then
            resetprop -n ro.vendor.qspm.enable "false"
            echo "『QSPM』已尝试通过修改系统属性关闭QSPM"
        else
            echo "『QSPM』不做修改"
        fi
    }
    

    QAPE
    QSPM
}


PowerOpt(){
    if [ "$GamePowerOptFeature_Disable" = "1" ]; then
        resetprop -n vendor.perf.qfps.enable "0"
        echo "『PowerOpt』GamePowerOptFeature特性已关闭，已尝试关闭附属QFPS功能"
    else
        echo "『PowerOpt』GamePowerOptFeature特性未关闭，不修改附属QFPS功能"
    fi
}

#————————————————————————————————————————


if [ "$(getprop ro.hardware)" = "qcom" ]
then
    echo -e "\n■ 高通平台，执行高通特别屏蔽\n"
    echo "<——————————————————>"
    ConfigDisposer
    echo "<——————————————————>"
    Perf
    echo "<——————————————————>"
    PowerOpt
    echo "<——————————————————>"
else
    echo "□ 非高通平台，不执行高通特别屏蔽"
fi


#————————————————————————————————————————
