CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



SingleMount -u /system_ext/etc/oiface/oiface.config 2>/dev/null && \
echo "✔️ 已卸载已挂载的oiface配置"

if SingleMount -m $CURMODDIR/File/oiface.config /system_ext/etc/oiface/oiface.config >/dev/null
then
    echo "✔️ 已等效替换oiface配置"
else
    echo "⭕ 未能成功替换oiface配置"
fi


OifaceProp=persist.sys.oiface.enable
if [ $Oiface_Prop != DEFAULT ]
then
    resetprop -n $OifaceProp $Oiface_Prop && echo "■ 已尝试修改'$OifaceProp'的值为'$Oiface_Prop'。现为：$(getprop $OifaceProp)"
else
    echo "□ 不修改'$OifaceProp'的值"
fi

