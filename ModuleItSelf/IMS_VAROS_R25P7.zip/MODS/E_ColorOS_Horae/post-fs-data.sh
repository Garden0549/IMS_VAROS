CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



HoraeProp=persist.sys.horae.enable
if [ $Horae_Prop != DEFAULT ]
then
    resetprop -n $HoraeProp $Horae_Prop && echo "■ 已尝试修改'$HoraeProp'的值为'$Horae_Prop'。现为：$(getprop $HoraeProp)"
else
    echo "□ 不修改'$HoraeProp'的值"
fi

