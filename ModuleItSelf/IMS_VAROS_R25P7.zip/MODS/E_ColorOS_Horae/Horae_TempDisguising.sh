CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



TempDisguising(){
    CustomShellTemp="/proc/shell-temp"
    if [ -e "$CustomShellTemp" ]; then
        dumpsys horae testmode >/dev/null 2>&1
        for i in $(seq 0 9)
        do   
            lock_val "$i $Horae_DisguisingTemp" "$CustomShellTemp"
        done
        for thermal_zone in /sys/class/thermal/*
        do
            if [ -f "$thermal_zone/temp" ]
            then
                case "$(cat "$thermal_zone/type")" in
                    oplus_thermal_ipa)
                        lock_val "$Horae_DisguisingTemp" "$thermal_zone/emul_temp"
                    ;;
                    shell*)
                        lock_val "$Horae_DisguisingTemp" "$thermal_zone/emul_temp"
                    ;;
                esac
            fi
        done
    
        DelayedPrinter "✔️ 已尝试将机身外壳温度伪装为'$Horae_DisguisingTemp'毫℃"
    else
    
        DelayedPrinter "□ 本设备疑似不存在Horae内核模块，不做处理"
    fi
}
if [ "$Horae_DisguisingTemp" = "Disabled" ]; then
    DelayedPrinter "□ 不伪装机身外壳温度"
else
    TempDisguising
fi