CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



ProcessManager \
"Horae" \
"horae" \
"horae" \
"/system_ext/bin/horae"

sh "$CURMODDIR/Horae_TempDisguising.sh"

IPALimit="/sys/devices/platform/oplus-thermal/clt_state_limit"
[ -f "$IPALimit" ] && \
lock_val "0 0 0 0 0 0" "$IPALimit" && \
echo "✔️ 已关闭IPA限制"













