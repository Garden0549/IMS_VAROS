CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#——————————————————————————#

echo "====================================="

#——————————————————————————#

SchedAssist="/proc/oplus_scheduler/sched_assist/sched_assist_enabled"
CpufreqBouncing="/sys/module/cpufreq_bouncing/parameters/enable"
CpufreqEffiency="/sys/module/cpufreq_effiency/parameters/affect_mode"
OplusMultipleRailGroup="/sys/devices/platform/soc/soc:oplus-omrg/oplus-omrg0/ruler_enable"
TaskCPUstats="/proc/task_info/task_cpustats/task_cpustats_enable"
TaskOverload="/proc/task_overload/skip_goplus_enabled"
TaskLoadInfo="/proc/task_info/task_load_info/monitor_status"
Geas="/proc/sys/geas/cpu/geas_cpu_enable"
FreqqosMonitor="/proc/oplus_freqreq_monitor/fqm_enable"
SmartFreq="/proc/sys/smart_freq/enable"
OSMLMonitor="/sys/module/osml_monitor/parameters/enable"

MODS="
    SchedAssist\
    CpufreqBouncing\
    CpufreqEffiency\
    OplusMultipleRailGroup\
    TaskCPUstats\
    TaskOverload\
    TaskLoadInfo\
    Geas
    FreqqosMonitor
    SmartFreq
    OSMLMonitor
"

for MOD in $MODS
do
    eval GlobalSwitch="\$$MOD"
    eval MODOnOff="\$${MOD}_Disable"
    if [ -f "$GlobalSwitch" ]
    then
        if [ "$MODOnOff" = 1 ]
        then
            mask_val "0" "$GlobalSwitch" >/dev/null 2>&1 && \
            echo "■ 已尝试关闭：'$MOD'"
        else
            echo "□ 未修改：'$MOD'"
        fi
    else
        echo "「不存在」：'$MOD'——'$GlobalSwitch'"
    fi
done

#————————————#
echo "————————————————————"
#————————————#

MOD="TaskSchedInfo"
eval MODOnOff="\$${MOD}_Disable"
Dir1="/sys/module/oplus_bsp_task_sched/parameters"
Dir1_Switch1="$Dir1/sched_info_ctrl"
Dir2="/proc/task_info/task_sched_info"
Dir2_Switch1="$Dir2/task_sched_info_enable"

if [ -e "$Dir1" ]
then
    if [ "$MODOnOff" = 1 ]
    then
        mask_val "0" "$Dir1_Switch1"
        echo "■ 已尝试关闭：'$MOD'——'$Dir1'"
    else
        echo "□ 未修改：'$MOD'——'$Dir1'"
    fi
else
    echo "「不存在」：'$MOD'——'$Dir1'"
fi
if [ -e "$Dir2" ]
then
    if [ "$MODOnOff" = 1 ]
    then
        mask_val "0" "$Dir2_Switch1"
        echo "■ 已尝试关闭：'$MOD'——'$Dir2'"
    else
        echo "□ 未修改：'$MOD'——'$Dir2'"
    fi
else
    echo "「不存在」：'$MOD'——'$Dir2'"
fi

#————————————#
echo "————————————————————"
#————————————#

MOD="CloseLoop"
eval MODOnOff="\$${MOD}_Disable"
Dir1="/proc/oplus_cl"
Dir1_Switch1="$Dir1/cl_enable"
Dir1_Switch2="$Dir1/cl_core_ctl"

if [ -e "$Dir1" ]
then
    if [ "$MODOnOff" = 1 ]
    then
        lock_val "0" "$Dir1_Switch1"
        Mask "$Dir1_Switch2"
        echo "■ 已尝试关闭：'$MOD'——'$Dir1'"
    else
        echo "□ 未修改：'$MOD'——'$Dir1'"
    fi
else
    echo "「不存在」：'$MOD'——'$Dir1'"
fi

#————————————#
echo "————————————————————"
#————————————#

MOD="FreqQoSArbiter"
eval MODOnOff="\$${MOD}_Disable"
Dir1="/sys/kernel/qos_arbiter/parameters"
Dir1_Switch1="$Dir1/cpu_min_freq"
Dir1_Switch2="$Dir1/cpu_max_freq"
Dir1_Switch3="$Dir1/thermal_max_freq"
Dir2="/proc/qos_test"
Dir2_Switch1="$Dir2/qos_test_remove_all"
Dir2_Switch2="$Dir2/qos_test_begin"

if [ -e "$Dir1" ]
then
    if [ "$MODOnOff" = 1 ]
    then
        mask_val "0:0 1:0 2:0 3:0 4:0 5:0 6:0 7:0" "$Dir1_Switch1"
        mask_val "0:9999999 1:9999999 2:9999999 3:9999999 4:9999999 5:9999999 6:9999999 7:9999999" "$Dir1_Switch2"
        mask_val "0:9999999 1:9999999 2:9999999 3:9999999 4:9999999 5:9999999 6:9999999 7:9999999" "$Dir1_Switch3"
        echo "■ 已尝试关闭：'$MOD'——'$Dir1'"
    else
        echo "□ 未修改：'$MOD'——'$Dir1'"
    fi
else
    echo "「不存在」：'$MOD'——'$Dir1'"
fi
if [ -e "$Dir2" ]
then
    if [ "$MODOnOff" = 1 ]
    then
        mask_val "1" "$Dir2_Switch1"
        mask_val "0" "$Dir2_Switch2"
        echo "■ 已尝试关闭：'$MOD'——'$Dir2'"
    else
        echo "□ 未修改：'$MOD'——'$Dir2'"
    fi
else
    echo "「不存在」：'$MOD'——'$Dir2'"
fi

#——————————————————————————#

echo "====================================="

#——————————————————————————#

Hmbird_Dir1="/proc/hmbird_sched"
Hmbird_Dir2="/proc/oplus_hmbird"
if [ -e "$Hmbird_Dir1" ]; then
    lock_val "0" "$Hmbird_Dir1/scx_enable"
    lock_val "0" "$Hmbird_Dir1/partial_ctrl"
    lock_val "0" "$Hmbird_Dir1/isolate_ctrl"
    lock_val "0" "$Hmbird_Dir1/slim_for_app"
    lock_val "0" "$Hmbird_Dir1/slim_walt/slim_walt_ctrl"
    lock_val "0" "$Hmbird_Dir1/slim_walt/slim_walt_dump"
    lock_val "0" "$Hmbird_Dir1/slim_walt/slim_walt_policy"
    lock_val "0" "$Hmbird_Dir1/slim_freq_gov/scx_gov_ctrl"
    lock_val "0" "$Hmbird_Dir1/slim_freq_gov/slim_gov_debug"
    lock_val "0" "$Hmbird_Dir1/heartbeat_enable"
    lock_val "0" "$Hmbird_Dir1/watchdog_enable"
    lock_val "0" "$Hmbird_Dir1/hmbirdcore_debug"
    echo "■ 已尝试关闭风驰调度内核模块功能"
elif [ -e "$Hmbird_Dir2" ]; then
    lock_val "-1" "$Hmbird_Dir2/manager_pid"
    lock_val "-1" "$Hmbird_Dir2/gpa_pid"
    lock_val "stop" "$Hmbird_Dir2/manager_hb_feed"
    echo "■ 已尝试关闭风驰调度内核模块功能"
    stop oplusHmbirdBpfManager && echo "■ 已关闭风驰BPF管理器"
else
    echo "□ 本设备没有风驰调度内核模块，不做处理"
fi

#——————————————————————————#

echo "====================================="

#——————————————————————————#

GAUGE_UPDATE_Dir="/proc/oplus-votable/GAUGE_UPDATE"
if [ -e "$GAUGE_UPDATE_Dir" ]
then
    lock_val "1000" "$GAUGE_UPDATE_Dir/force_val" &&\
    lock_val "1" "$GAUGE_UPDATE_Dir/force_active" &&\
    echo "■ 已精细化电流采样率"
else
    echo "□ 本设备没有电流计量内核模块接口，不做处理"
fi

#——————————————————————————#

echo "====================================="

#——————————————————————————#

Oplus_SLC_Dir="/proc/oplus_slc"
if [ -e "$Oplus_SLC_Dir" ]
then
    lock_val "0" "$Oplus_SLC_Dir/disable"
	lock_val "0" "$Oplus_SLC_Dir/disable_cdwb"
	lock_val "1,100" "$Oplus_SLC_Dir/force_ratio"
	lock_val "2,100" "$Oplus_SLC_Dir/force_ratio"
	lock_val "2" "$Oplus_SLC_Dir/priority"
	echo "■ 已尝试通过Oplus_SLC内核模块改善SLC分配"
else
    echo "□ 本设备没有Oplus_SLC内核模块，不做处理"
fi

#——————————————————————————#

echo "====================================="

#——————————————————————————#




