CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#<————————————↓↓↓———［GED］———↓↓↓————————————>#

GED_KPI(){
    if [ $GED_KPI_Enable = 0 ]; then
        mask_val 0 /sys/module/ged/parameters/is_GED_KPI_enabled && \
        echo "『GPU』已关闭GED_KPI"
    else
        mask_val 1 /sys/module/ged/parameters/is_GED_KPI_enabled && \
        echo "『GPU』已开启GED_KPI"
    fi
}

#<——————————————————————————————————————>#

SpecificFunc(){
    local Kernel_Dir="/sys/kernel/ged/hal"
    local Module_Dir="/sys/module/ged/parameters"
    local FastDVFS_Modern_Node1="$Kernel_Dir/eb_dvfs_policy"
    local FastDVFS_Old_Node1="$Kernel_Dir/fastdvfs_mode"
    local FastDVFS_Old_Node2="/proc/fastdvfs_proc"
    local DCS="$Kernel_Dir/dcs_mode"
    local SmartBoost="$Module_Dir/ged_smart_boost"
    local InputBoost_Kernel_Node="$Kernel_Dir/gpu_boost_level"
    local InputBoost_Module_Nodes="boost_gpu_enable enable_gpu_boost ged_boost_enable"
    
    if [ ! -e "$FastDVFS_Modern_Node1" ]; then
        echo "『GPU』本设备不存在当代版本的FastDVFS"
    else
        if [ "$FastDVFS_Modern_Disable" = 1 ]; then
            lock_val "0" "$FastDVFS_Modern_Node1" && \
            echo "『GPU』已关闭当代版本FastDVFS"
        else
            echo "『GPU』未干预当代版本FastDVFS"
        fi
    fi
    if [ ! -e "$FastDVFS_Old_Node1" ] || [ ! -e "$FastDVFS_Old_Node2" ]; then
        echo "『GPU』本设备不存在早期版本的FastDVFS"
    else
        if [ "$FastDVFS_Old_Disable" = 1 ]; then
            mask_val "0" "$FastDVFS_Old_Node1" || \
            mask_val "0" "$FastDVFS_Old_Node2" && \
            echo "『GPU』已关闭早期版本FastDVFS"
        else
            echo "『GPU』未干预早期版本FastDVFS"
        fi
    fi

    for i in DCS SmartBoost
    do
        eval File=\$$i
        eval FileSwitch=\$${i}_Disable
        if [ -f $File ]
        then
            if [ $FileSwitch = 1 ]
            then
                mask_val 0 "$File" && \
                echo "『GPU』已关闭：'$i'"
            else
                echo "『GPU』未干预：'$i'——'$File'"
            fi
        else
            echo "『GPU』不存在而未处理：'$i'——'$File'"
        fi
    done
   
    if [ "$InputBoost_Disable" = 1 ]; then
        mask_val "0" "$InputBoost_Kernel_Node" >/dev/null 2>&1
        for i in $InputBoost_Module_Nodes
        do
            mask_val "0" "$Module_Dir/$i" >/dev/null 2>&1
        done
        echo "『GPU』已关闭InputBoost"
    else
        echo "『GPU』未干预InputBoost"
    fi

}

#<——————————————————————————————————————>#

Custom_MaxMinFreq(){
    lock_val $Custom_Max_Freq /sys/kernel/ged/hal/custom_upbound_gpu_freq && \
    Max_Freq="$(cat /sys/module/ged/parameters/gpu_cust_upbound_freq)" && \
    echo "『GPU』GPU频率［实际上限］尝试设为：$(echo "$Max_Freq / 1000" | bc) MHz"
    
    lock_val $Custom_Min_Freq /sys/kernel/ged/hal/custom_boost_gpu_freq && \
    Min_Freq="$(cat /sys/module/ged/parameters/gpu_cust_boost_freq)" && \
    echo "『GPU』GPU频率［实际下限］尝试设为：$(echo "$Min_Freq / 1000" | bc) MHz"
}

#<——————————————————————————————————————>#

Force_LB(){
    local File1="/sys/module/ged/parameters/g_fb_dvfs_threshold"
    local File2="/sys/kernel/ged/hal/force_loading_base"
    
    if [ -e $File1 ]; then
        if [ $Force_LB_Enable = 1 ]; then
            mask_val 1000 $File1 && \
            echo "『GPU』强制使用负载基模式"
        else
            mask_val 80 $File1 && \
            echo "『GPU』不强制使用负载基模式，恢复默认设置，由系统自动切换调频模式"
        fi
    elif [ -e $File2 ]; then
        if [ $Force_LB_Enable = 1 ]; then
            mask_val 1 $File2 && \
            echo "『GPU』强制使用负载基模式"
        else
            mask_val 0 $File2 && \
            echo "『GPU』不强制使用负载基模式，恢复默认设置，由系统自动切换调频模式"
        fi
    else
        echo "『GPU』无法强制使用负载基模式——所需系统参数不存在"
    fi
}

#<——————————————————————————————————————>#

LB_Old(){
    if [ $LB_Old_Enable = 0 ]; then
        mask_val 0 /sys/module/ged/parameters/g_gpu_timer_based_emu && \
        echo "『GPU』'负载基-旧'模式已关闭"
    else
        mask_val 1 /sys/module/ged/parameters/g_gpu_timer_based_emu && \
        echo "『GPU』'负载基-旧'模式已开启，将取代负载基模式"
    fi
}

#<——————————————————————————————————————>#

LB_New_Margin(){
    LB_New_Margin_FinValue=$((LB_New_Margin_StaticMargin))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynEnable << 8)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynUsePipeTime << 9)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynPerfMode << 10)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynFixTargetFPS30 << 11)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynMinMargin << 16)))
    LB_New_Margin_FinValue=$((LB_New_Margin_FinValue | (LB_New_Margin_DynStepSize << 24)))
      
    lock_val $LB_New_Margin_FinValue /sys/kernel/ged/hal/timer_base_dvfs_margin && \
    echo "『GPU』负载基余量各子项合成值：$LB_New_Margin_FinValue"
}

#<——————————————————————————————————————>#

LB_New_UltraStep(){
    LB_New_UltraStep_FinValue=$(( (LB_New_UltraStep_Bit8_15 << 8) | LB_New_UltraStep_Bit0_7 ))
    
    lock_val $LB_New_UltraStep_FinValue /sys/kernel/ged/hal/loading_base_dvfs_step && \
    echo "『GPU』负载基极端负载步长各子项合成值：$LB_New_UltraStep_FinValue（十六进制：$(echo "obase=16; $LB_New_UltraStep_FinValue" | bc)）"
    
    Platform="$(getprop "ro.board.platform")"
    local File1="/sys/kernel/ged/hal/loading_window_size"
    [ "$LB_New_UltraStep_FinValue" = 0 ] && {
        case "$Platform" in
            mt6895|mt6983)
                [ -e "$File1" ] && \
                mask_val "0" "$File1" && \
                echo "『GPU』修改loading_window_size的值为0，以避免特定平台GPU几乎不升频的问题"
                ;;
        esac
    }
}

#<——————————————————————————————————————>#

FB_Margin(){
    if { [ "$FB_Margin" -ge 401 ] && [ "$FB_Margin" -le 499 ]; } || { [ "$FB_Margin" -ge 501 ] && [ "$FB_Margin" -le 599 ]; }
    then
        FB_Margin_FinValue=$(( FB_Margin | (FB_Margin_MinStep << 10) | (FB_Margin_MinMargin << 16) ))
    else
        FB_Margin_FinValue=$FB_Margin
    fi
    
    mask_val $FB_Margin_FinValue /sys/kernel/ged/hal/dvfs_margin_value && \
    echo "『GPU』帧基余量值：$FB_Margin_FinValue"
    
    IgnoreFPSGOFPSMargin="/sys/kernel/ged/hal/default_fps_margin_support"
    [ -e "$IgnoreFPSGOFPSMargin" ] && \
    mask_val "1" "$IgnoreFPSGOFPSMargin" && \
    echo "『GPU』帧基忽略FPSGO传递的FPS余量，改用内核默认的FPS余量(余量为4)"
}

#<——————————————————————————————————————>#

LoadMode(){
    local File1="/sys/kernel/ged/hal/dvfs_loading_mode"
    local File2="/sys/kernel/ged/hal/dvfs_workload_mode"
    
    [ -e $File1 ] && \
    mask_val $LoadingMode $File1 && \
    echo "『GPU』dvfs_loading_mode设为：$LoadingMode"

    [ -e $File2 ] && \
    mask_val $WorkloadMode $File2 && \
    echo "『GPU』dvfs_workload_mode设为：$WorkloadMode"
}

#<————————————↑↑↑———［GED］———↑↑↑————————————>#


#<————————————↓↓↓———［OTHERS］———↓↓↓————————————>#

GPT(){
    GPT=/sys/kernel/thermal/gpt
    if [ -e $GPT ]; then
        if [ $GPT_Enable = 1 ]; then
            mask_val "enable" /sys/kernel/thermal/gpt && \
            mask_val "gpt 1 $GPT_Thrm1" /sys/kernel/thermal/gpt && \
            mask_val "gpt 2 $GPT_Thrm2" /sys/kernel/thermal/gpt && \
            echo "『GPU』已尝试开启GPT功能并调整其参数"
        else
            mask_val "disable" /sys/kernel/thermal/gpt && \
            echo "『GPU』已尝试关闭GPT功能！"
        fi
    else
        echo "『GPU』本设备不存在GPT，不做处理"
    fi
}

#<————————————↑↑↑———［OTHERS］———↑↑↑————————————>#

GED(){
    echo "#============#"

    GED_KPI
    
    echo "#============#"
    
    SpecificFunc
    
    echo "#============#"
    
    Custom_MaxMinFreq
    
    echo "#============#"
    
    Force_LB
    
    echo "#============#"
    
    LB_Old
    
    echo "#============#"
    
    LB_New_Margin
    
    echo "#============#"
    
    LB_New_UltraStep
    
    echo "#============#"
    
    FB_Margin
    
    echo "#============#"
    
    LoadMode
    
    echo "#============#"
}



[ "$GPU" = "1" ] && GED
GPT







