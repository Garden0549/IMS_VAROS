CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

ConfigDisposer(){
    #功能：
    #   重启指定服务
    #用法：
    # ServiceRestarter "日志输出对象名" \
    #     "服务名列表" \
    ServiceRestarter(){
        local Object="$1"
        local ServiceList="$2"
        
        echo "===========［重启$Object］==========="
        
        for SVC in $ServiceList
        do
            if stop "$SVC" 2>/dev/null; then
                echo "『$Object』服务 '$SVC' 存在"
                start "$SVC" && \
                echo "『$Object』服务 '$SVC' 重启成功" || \
                echo "『$Object』服务 '$SVC' 重启失败！"
            else
                echo "『$Object』服务 '$SVC' 无法停止，可能不存在"
            fi
            echo "==========================="
        done
        
        echo "『$Object』已尝试重启服务，以重载可能受其读取的已挂载配置文件"
        
        echo "============================================"
    
    }
    CD_PowerHAL(){
        #注意：后续参数必须在重启PowerHAL服务之后修改，以避免随其重启被重置
        CD_PowerHAL_ServiceRestarter(){
            local ServiceList="
                power-hal-1-0\
                vendor.mtkpower-service.mediatek\
                vendor.mtkpower_applist-default\
            "
        
            ServiceRestarter "PowerHAL" \
                "$ServiceList"
        }


        if \
          [ "$PowerHAL_power_app_cfg_Empty" = "1" ] || \
          [ "$PowerHAL_powerscntbl_Empty" = "1" ] || \
          [ "$PowerHAL_powercontable_Empty" = "1" ] || \
          [ "$PowerHAL_RelatedConf_Empty" = "1" ]
        then
            CD_PowerHAL_ServiceRestarter
        else
            echo "『PowerHAL』没有需要清空的配置，不重启服务"
        fi
    }


    #————『ConfigDisposer_函数执行区』————#
    CD_PowerHAL
}

#————————————————————————————————————————

FPSGO(){
    local KernelDir="/sys/kernel/fpsgo"
    local ModuleDir1="/sys/module/fbt_cpu/parameters"
    local ModuleDir2="/sys/module/mtk_fpsgo/parameters"
    local ModuleDir=""
    local ChildMOD_GBE_Dir1="/sys/kernel/gbe"
    local ChildMOD_GBE_Dir2="/sys/kernel/fpsgo/gbe"
    local ChildMOD_GBE_DirFin=""
    local TouchBoost="/proc/tchbst/user/usrtch"
    for i in "$ModuleDir1" "$ModuleDir2"
    do
        [ -e "$i" ] && ModuleDir="$i"
    done
    for i in "$ChildMOD_GBE_Dir1" "$ChildMOD_GBE_Dir2"
    do
        [ -e "$i" ] && ChildMOD_GBE_DirFin="$i"
    done
    [ ! -e "$KernelDir" ] && [ -z "$ModuleDir" ] && {
        echo "『FPSGO』本设备不存在FPSGO内核模块，不做处理"
        return 0
    }    


    ##内核模块
    mask_val "0" "$KernelDir/common/force_onoff"
    echo "『FPSGO』已尝试全局关闭FPSGO内核模块"

    if [ -n "$ChildMOD_GBE_DirFin" ]
    then
        mask_val "0" "$ChildMOD_GBE_DirFin/gbe_enable1"
        mask_val "0" "$ChildMOD_GBE_DirFin/gbe_enable2"
        echo "『FPSGO』已全局关闭FPSGO内核模块子模块'GBE'"
    fi
    
    if [ -e "$TouchBoost" ]
    then
        mask_val "enable 0" "$TouchBoost"
        echo "『FPSGO』已尝试关闭FPSGO内核模块子模块'触摸性能提升'"
    fi


    ##内核模块关联用户空间进程
    for Service in fpsgo gbe xgf touch_boost
    do
        stop $Service >/dev/null 2>&1 && \
        echo "『FPSGO』已尝试关闭 $Service 进程"
    done
}

MAGT(){
    local Dir="/sys/module/mtk_perf_ioctl_magt/parameters"
    [ ! -e "$Dir" ] && {
        echo "『MAGT』未找到参数目录，不做处理"
        return 0
    }
    local Parameters="
        thermal_aware_threshold\
        fpsdrop_aware_threshold\
        advice_bat_avg_current\
        advice_bat_max_current\
        targetfps_throttling_temp\
        thermal_aware_light_threshold\
        game_suggestion_jobworker\
    "        
    for i in $Parameters
    do
        mask_val "-1" "$Dir/$i" >/dev/null 2>&1
    done
    
    
    echo "『MAGT』已尝试关闭MAGT内核模块"
}

SBE(){
    local Dir1="/sys/module/mtk_sbe/parameters"
    local Dir2="/sys/module/sbe/parameters"
    local DirFin=""
    for i in "$Dir1" "$Dir2"
    do
        [ -e "$i" ] && DirFin="$i"
    done
    [ -z "$DirFin" ] && {
        echo "『SBE』未找到参数目录，不做处理"
        return 0
    }
    local Parameters="
        sbe_rescue_enable\
        sbe_enhance_f\
        sbe_dy_rescue_enable\
        sbe_dy_max_enhance\
        set_deplist_vip\
        set_deplist_affinity\
        set_deplist_ls\
        sbe_dptv2_enable\
        sbe_notify_fpsgo_vir_boost\
        sbe_ai_ctrl_enabled\
        sbe_affinity_task_min_cap\
        sbe_affinity_task_low_threshold_cap\
        sbe_critical_basic_cap\
        sbe_extra_sub_en_deque_enable\
        sbe_without_dptv2_enable\
        sbe_ignore_vip_task_enable\
    "        
    for i in $Parameters
    do
        mask_val "0" "$DirFin/$i" >/dev/null 2>&1
    done
    mask_val "255" "$DirFin/sbe_affinity_task" >/dev/null 2>&1
    
    
    echo "『SBE』已尝试关闭SBE内核模块"
}

MTK_CoreCtl(){
    local File1="/sys/module/mtk_core_ctl/parameters/policy_enable"
    [ -e "$File1" ] && mask_val "0" "$File1"
    
    for i in /sys/devices/system/cpu/cpu*; do
        [ -f $i/core_ctl/enable ] && {
          lock_val 1 $i/core_ctl/enable
        }
        
        [ -f $i/core_ctl/min_cpus ] && {
          lock_val 99 $i/core_ctl/min_cpus
        }
        
        [ -f $i/core_ctl/max_cpus ] && {
          lock_val 99 $i/core_ctl/max_cpus
        }
        
        [ -f $i/core_ctl/enable ] && {
          lock_val 0 $i/core_ctl/enable
        }
    done
    
    echo "『MTK_CoreCtl』已尝试阻止系统自动关闭CPU核心"
}

GPU(){
    sh "$CURMODDIR/GPU.sh"
}

MiscLimiters(){

    cpufreq_Lite_V1_V2(){
        local cpufreq_Lite_Node="/proc/cpudvfs/cpufreq_debug"
        local cpufreq_V1_Node="/proc/cpuhvfs/cpufreq_debug"
        local CurrentPolicy=""
        local CP_AvailableFrequencies=""
        local CP_MinFreq=""
        local CP_MaxFreq=""
        local CP_RelatedCPUS=""


        for CurrentPolicy in /sys/devices/system/cpu/cpufreq/policy*
        do
            CP_AvailableFrequencies="$CurrentPolicy/scaling_available_frequencies"
            CP_MinFreq="$(NumSelector "Min" "$CP_AvailableFrequencies")"
            CP_MaxFreq="$(NumSelector "Max" "$CP_AvailableFrequencies")"
            
            CP_RelatedCPUS="$(cat $CurrentPolicy/related_cpus)"
            
            for CPU in $CP_RelatedCPUS
            do
                for Node in "$cpufreq_Lite_Node" "$cpufreq_V1_Node"
                do     
                    [ -e "$Node" ] && mask_val "$CPU $CP_MinFreq $CP_MaxFreq" "$Node"
                done            
            done
        done
    }

    perfmgr(){
        local Dir="/proc/perfmgr"
        local TouchBoost=" $Dir/tchbst/user/usrtch"
        if [ -e "$Dir" ]
        then        
            chmod 444 "$Dir/global_reclaim"
            lock_val "enable 0" "$TouchBoost"
            
            SingleMount -u "$Dir/perf_ioctl"
            SingleMount -m "$Dir/xgff_ioctl" "$Dir/perf_ioctl"
        fi
    }
    
    perfmgr_powerhal(){
        local Dir="/proc/perfmgr_powerhal"
        if [ -e "$Dir" ]
        then
        
            SingleMount -u "$Dir/ioctl_powerhal"
            SingleMount -m "$Dir/ioctl_powerhal_adpf" "$Dir/ioctl_powerhal"
            
        fi
    }

    powerhal_cpu_ctrl(){
        local Dir="/proc/powerhal_cpu_ctrl"
        local CurrentPolicy=""
        local CP_AvailableFrequencies=""
        local CP_MinFreq=""
        local CP_MaxFreq=""
        local CP_Number="0"
        for CurrentPolicy in /sys/devices/system/cpu/cpufreq/policy*
        do
            CP_AvailableFrequencies="$CurrentPolicy/scaling_available_frequencies"
            CP_MinFreq="$(NumSelector "Min" "$CP_AvailableFrequencies")"
            CP_MaxFreq="$(NumSelector "Max" "$CP_AvailableFrequencies")"

            eval "local Cluster${CP_Number}_MinFreq=$CP_MinFreq"
            eval "local Cluster${CP_Number}_MaxFreq=$CP_MaxFreq"
            CP_Number="$(( CP_Number + 1 ))"
        done

        
        if [ -e "$Dir" ]
        then
        
            if [ ! -e "$Dir/adpf_enable" ] && [ ! -e "$Dir/sf_hint_low_power_enabled" ]; then
            #MT6985
                echo "$Cluster0_MinFreq $Cluster0_MaxFreq $Cluster1_MinFreq $Cluster1_MaxFreq $Cluster2_MinFreq $Cluster2_MaxFreq" > "$Dir/perfserv_freq"

            
            elif [ -e "$Dir/adpf_enable" ] && [ -e "$Dir/sf_hint_low_power_enabled" ]; then
            #MT6989
                echo 0 > "$Dir/adpf_enable"
                echo 0 > "$Dir/sf_hint_low_power_enabled"
                
                SingleMount -u "$Dir/perfserv_freq"
                echo "$Cluster0_MinFreq $Cluster0_MaxFreq $Cluster1_MinFreq $Cluster1_MaxFreq $Cluster2_MinFreq $Cluster2_MaxFreq" > "$Dir/perfserv_freq"
                SingleMount -m "$Dir/adpf_enable" "$Dir/perfserv_freq"

            
            elif [ -e "$Dir/adpf_enable" ] && [ ! -e "$Dir/sf_hint_low_power_enabled" ]; then
            #MT6991
                echo 0 > "$Dir/adpf_enable"
                
                SingleMount -u "$Dir/perfserv_freq"
                for CPUID in $(seq 0 7)
                do
                    echo "$CPUID 0 0" > "$Dir/perfserv_freq"
                done
                SingleMount -m "$Dir/adpf_enable" "$Dir/perfserv_freq"

            
            elif [ -e "$Dir/enable_cpu_timing_hint" ]; then
            #MT6993
                echo 0 > "$Dir/enable_cpu_timing_hint"
                
                SingleMount -u "$Dir/perfserv_freq"
                for CPUID in $(seq 0 7)
                do
                    echo "$CPUID 0 0" > "$Dir/perfserv_freq"
                done
                SingleMount -m "$Dir/enable_cpu_timing_hint" "$Dir/perfserv_freq"
                
            
            fi
        
        fi
    }
    
    game(){
        local EngineCooler_Dir="/sys/module/mtk_game/parameters"
        local Common_Dir="/sys/kernel/game"
        
        if [ -e "$EngineCooler_Dir" ]
        then
            mask_val "0" "$EngineCooler_Dir/engine_cooler_enable"
        fi
        
        
        if [ -e "$Common_Dir" ]
        then
        
            mask_val "0" "$Common_Dir/frame_interpolation_enable"
            mask_val "0" "$Common_Dir/fi_detect_enable"
            
            LIST="$Common_Dir/loom_enable_by_process"
            TGID_LIST=$(cat "$LIST" 2>/dev/null | grep -E '^[0-9]+$')
            if [ -n "$TGID_LIST" ]
            then
                for tgid in $TGID_LIST
                do
                    mask_val "$tgid 0" "$LIST"
                done
            fi
            mask_val "0 0 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1" "$Common_Dir/loom_task_cfg"
            mask_val "0" "$Common_Dir/ofp_enable"
        
        fi
    }

    Thermal(){
        local Dir="/sys/kernel/thermal"
        MaxTemp=105000  #单位：毫℃
        if [ -e "$Dir" ]
        then
            mask_val "MAX_TTJ $MaxTemp $MaxTemp $MaxTemp" "$Dir/max_ttj"
            mask_val "MIN_TTJ $MaxTemp" "$Dir/min_ttj"
            mask_val "TTJ $MaxTemp $MaxTemp $MaxTemp" "$Dir/ttj"
            mask_val "0" "$Dir/cg_policy_mode"
        fi
    }
    
    FRS(){
        stop frs
    }
    
    pelt_hint(){
        lock_val "0" "/sys/kernel/pelt_hint/gai_cpu_boost_enable"
    }
    
    power_throttling_related(){
        #①CPU/GPU功耗限制
        lock_val "1" /sys/devices/platform/cpu_power_throttling/boot_notify
        lock_val "1" /sys/devices/platform/gpu_power_throttling/boot_notify
        #②电流过流节流
        lock_val "Utest 0" /proc/mtk_batoc_throttling/battery_oc_protect_ut
        lock_val "stop 1" /proc/mtk_batoc_throttling/battery_oc_protect_stop
        #③电池电量百分比节流调试
        lock_val "0" /sys/kernel/debug/bp_thl/bp_thl_ut
        #④电池低电量节流
        lock_val "Utest 0" /sys/devices/platform/low_battery_throttling/low_battery_protect_ut
        lock_val "stop 1" /sys/devices/platform/low_battery_throttling/low_battery_protect_stop
        #⑤电池电量百分比节流
        lock_val "Utest 0" /sys/devices/platform/bp_thl/bp_thl_ut
        lock_val "stop 1" /sys/devices/platform/bp_thl/bp_thl_stop
        #⑥CPU频率与GPU频率彼此限制
        lock_val "2" "/sys/class/cg_ppt/cg_ppt/mode"
    }

    touch_boost(){
        local Dir="/proc/touch_boost"
        if [ -e "$Dir" ]
        then
            mask_val "0" "$Dir/enable"
            stop touch_boost
        fi
    }
    
    mtk_lpm(){
        lock_val "1" /proc/mtk_lpm/cpuidle/enable
        lock_val "1" /proc/mtk_lpm/cpuidle/cpu_ret_en
        lock_val "0" /proc/mtk_lpm/cpuidle/cpu_pf_en
    }
    
    jank_detection(){
        lock_val "0x18" "/sys/kernel/jank_detection/jank_detection"
    }

    hps(){
        lock_val "0" "/proc/hps/enabled"
    }
    
    task_turbo(){
        local Dir1="/sys/module/task_turbo/parameters"
        local Dir2="/sys/module/vip_engine/parameters"
        
        for m in "$Dir1" "$Dir2"
        do
            for n in feats enable_tt_vip
            do
                lock_val "0" "$m/$n"
            done
        done
    }
    
    #——————————————————————#
    
    ALL(){
        cpufreq_Lite_V1_V2
        perfmgr
        perfmgr_powerhal
        powerhal_cpu_ctrl
        game
        Thermal
        FRS
        pelt_hint
        power_throttling_related
        touch_boost
        mtk_lpm
        jank_detection
        hps
        task_turbo
    }
    ALL >/dev/null 2>&1
    echo "『MiscLimiters』已尝试屏蔽其它内核模块的控制"
}

#————————————————————————————————————————


if [ "$(getprop ro.hardware)" != "qcom" ]
then
    echo -e "\n■ 联发科平台，执行联发科特别屏蔽\n"
    echo "<——————————————————>"
    ConfigDisposer
    echo "<——————————————————>"
    FPSGO
    echo "<——————————————————>"
    MAGT
    echo "<——————————————————>"
    SBE
    echo "<——————————————————>"
    MTK_CoreCtl
    echo "<——————————————————>"
    GPU
    echo "<——————————————————>"
    MiscLimiters
    echo "<——————————————————>"
else
    echo "□ 非联发科平台，不执行联发科特别屏蔽"
fi


#————————————————————————————————————————





