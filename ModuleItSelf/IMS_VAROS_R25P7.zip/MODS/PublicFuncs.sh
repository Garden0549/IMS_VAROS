#［程序制作原则(V0.2)：］
#①函数及子函数的设计应以［功能原子化、结构清晰、易维护］为主（功能原子化：各函数的功能——不重复、集中单一）
#②功能相近的函数，内部逻辑应尽可能对称(相同)
#［维护原则(V0.2)：］
# ①需提前理解函数结构，规划修改
# ②建议将常用拓展功能加入该函数，减少外部代码冗余
#【↑进行上述一切的原则是：有需要再做↑】


#注意：[直接移植该脚本/取走部分函数]的注意事项
#1.考虑是否修改本脚本的缓存目录变量：CACHE_DIR
#2.检查函数中是否用到本脚本中的其它［变量/函数］


#####————————————[BASIC]系列————————————#####
# 本脚本的：
    # 所在地址——CURFUNCFILE
    # 本脚本的名称——CURFUNCFILE_Name
CURFUNCFILE="$0"
CURFUNCFILE_Name="${CURFUNCFILE##*/}"
# 本脚本的：
    # 缓存目录地址——CACHE_DIR
# 注意①：这个变量的值只能由“大小写字母”“数字”“下划线”“/”组成
CACHE_DIR="/dev/log"
mkdir -p "$CACHE_DIR"
#####—————————————#####
#等待——等待系统完全启动，以确保目录［/data］可正常使用
wait_until_login() {
     # 确保/data加密被关闭
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done
    # 确保用户解锁屏幕
    until [ -d "/data/data/android" ]; do
        sleep 1
    done
}
#延迟输出——用以逐行流畅输出文本
#用法：
#   用法①：无变量
#   用法②：$1：延迟(可填)  $2：文本
#   用法③：$1：选项 $2：延迟(可填)  $3：文本
#注①：关于"无变量"：
#   （1）无变量 时，将输出空行
#注②：关于“延迟(可填)”：
#   （1）若不填，默认为0.05s
#   （2）取值格式及范围：同sleep指令，但以2个-开头
#注③：关于"文本"：
#   （1）若同时输入多个文本，将以1个空格为间隔连接这些文本作为一行输出
#注④：关于“选项”：
#   （1）取值格式及范围：同echo指令
#注⑤：向函数传入参数时，符号可能会被解析（已知：\n）
DelayedPrinter(){
    local Option=""
    local Delay="0.05"
    local Text=""

    ##用法①
    if [ $# = "0" ]; then
        echo
        return 0
    fi
    case "$1" in
        ##用法②（填 延迟）
        --*)
            Delay="${1##*-}"
            shift 1
            Text="$*"

            sleep "$Delay"
            echo "$Text"
            ;;
        -*)
            ##用法③
            Option="$1"
            case "$2" in
                ##用法③（填 延迟）
                --*)
                    Delay="${2##*-}"
                    shift 2
                    Text="$*"

                    sleep "$Delay"
                    echo "$Option" "$Text"
                    ;;
                ##用法③（不填 延迟）
                *)
                    shift 1
                    Text="$*"

                    sleep "$Delay"
                    echo "$Option" "$Text"
                    ;;
            esac
            ;;
        ##用法②（不填 延迟）
        *)
            Text="$*"

            sleep "$Delay"
            echo "$Text"
            ;;
    esac
}
#延迟换行——用以逐行流畅输出空行
#用法：
#   用法①：$1：换行次数  $2：延迟(可填)
#注①：关于“延迟(可填)”：继承自DelayedPrinter
DelayedLineFeeder(){
    for i in $(seq 1 $1)
    do   
        DelayedPrinter "$2"
    done
}
#####————————————[BASIC]系列————————————#####





#####————————————[挂载]系列函数————————————#####
# 【单个】地[挂载文件或目录/卸载挂载点]兼尝试恢复安全上下文（支持Bind/OverlayFS挂载）
# $1：选项①［-m］(挂载)  $2：<设备源>(源文件/源目录)  $3：<挂载点>  $4：选项②［OverlayFS/Bind/其它任意值］
# $1：选项①［-u］(卸载挂载点)  $2：<挂载点>
#注①：当选项①为［-m］时，选项②各值的含义：
#   （1）［OverlayFS］优先使用OverlayFS来挂载，若失败再使用Bind来挂载，且都复制<设备源>并用其副本来挂载
#   （2）［Bind］只使用Bind来挂载，且复制<设备源>并用其副本来挂载（可能影响ROOT隐藏）
#   （3）［其它任意值］只使用Bind来挂载，且使用<设备源>本体来挂载
#【注②】：不可使用OverlayFS挂载系统节点或重要系统目录，否则其无法读写或执行，可能引起严重后果
#注③：通过OverlayFS挂载同目录多个文件时，不建议逐个挂载，以避免同一目录多重挂载可能导致的问题
#注④：使用OverlayFS将<设备源>挂载到<挂载点>时，若两者都是［目录］，OverlayFS会将其挂载到［目录内］(若［目录内］有与之同名的目录，那么两个目录将合并，且对于它们内部的同名文件，前者的将覆盖后者的)
SingleMount() {
    local Opt1="$1"
    local Opt2="$4"

    #————若选项①为［-m(挂载)］————#
    
    if [ "$Opt1" = "-m" ]; then
        #<设备源>、<挂载点>
        #借realpath移除目录地址末尾可能存在的多余“/”以便代码执行
        local MountSource="$(realpath "$2")"
        local MountPoint="$(realpath "$3")"
        if [ ! -e "$MountSource" ]; then
            echo "□ 设备源 '$MountSource' 不存在。"
            return 1
        elif [ ! -e "$MountPoint" ]; then
            echo "□ 挂载点 '$MountPoint' 不存在"
            return 1
        fi
        
        #========［OverlayFS——Bind挂载］========#
        #====对于OverlayFS：<设备源>为［目录］时，<挂载点>不能为［文件］
        #====对于Bind：<设备源>与<挂载点>的文件类型必须相同
        CacheDirCreator(){
            #OverlayFS缓存目录（Bind可使用$OFS_UpperDir里的副本来挂载）
            OFS_RootDir="$CACHE_DIR/OFS_$(date "+%s%N")"        
            OFS_UpperDir="$OFS_RootDir/UpperDir"
            OFS_WorkDir="$OFS_RootDir/WorkDir"
            mkdir -p "$OFS_UpperDir" "$OFS_WorkDir"
        }
        MountSourcePointSelector(){
            BindSource=""
            OverlayFSMountPoint=""
        
            #————若选项②为［OverlayFS/Bind］————#
            
            if [ "$Opt2" = "OverlayFS" ] || [ "$Opt2" = "Bind" ]; then
                #需要创建缓存目录
                CacheDirCreator
                
                
                #①复制<设备源>的副本，复制到的地址因文件类型有变化
                #②Bind的<设备源>因文件类型有变化——由于使用<设备源>的副本来挂载
                #③OverlayFS的<挂载点>不能是文件
                if [ -f "$MountSource" ] && [ -f "$MountPoint" ]; then
                
                    cp -af "$MountSource" "$OFS_UpperDir/${MountPoint##*/}"
                    BindSource="$OFS_UpperDir/${MountPoint##*/}"
                    OverlayFSMountPoint="${MountPoint%/*}"
                    
                elif [ -d "$MountSource" ] && [ -d "$MountPoint" ]; then
                
                    cp -af "$MountSource" "$OFS_UpperDir"
                    BindSource="$OFS_UpperDir/${MountSource##*/}"
                    OverlayFSMountPoint="$MountPoint"
                    
                elif [ -f "$MountSource" ] && [ -d "$MountPoint" ]; then
                
                    cp -af "$MountSource" "$OFS_UpperDir"
                    OverlayFSMountPoint="$MountPoint"
                    
                fi

            #————若选项②为［任意值］————#
            
            else
                #无需创建缓存目录

                #Bind的<设备源>为其本体
                BindSource="$MountSource"
                
            fi            
        }
        BindExecutor(){
            mount --bind "$BindSource" "$MountPoint"
        }        
        OverlayFSExecutor(){
            #————若选项②为［OverlayFS］————#
            if [ "$Opt2" = "OverlayFS" ]; then
                :
            #————若选项②为［其它值］————#
            else
                return 2
            fi
            
            mount -t overlay none\
                -o lowerdir="$OverlayFSMountPoint",upperdir="$OFS_UpperDir",workdir="$OFS_WorkDir"\
                "$OverlayFSMountPoint"
        }
                

        #== ①<设备源><挂载点>分别为［文件］［文件］——支持OverlayFS、Bind挂载
        #== ②<设备源><挂载点>分别为［目录］［目录］——支持OverlayFS、Bind挂载
        #== ③<设备源><挂载点>分别为［文件］［目录］——支持OverlayFS挂载，不支持Bind挂载
        #== ④<设备源><挂载点>分别为［目录］［文件］——不能挂载
        #①②均先尝试OverlayFS，失败再尝试Bind。通过在OverlayFSExecutor加入退出函数实现［先OverlayFS再Bind / 仅Bind］
        MountSourcePointSelector
        if [ -f "$MountSource" ] && [ -f "$MountPoint" ]; then
            if OverlayFSExecutor; then
                echo "✔️ OverlayFS挂载成功［文件→文件］：'$MountSource' → '$MountPoint'"
            elif BindExecutor; then
                echo "✔️ Bind挂载成功［文件→文件］：'$MountSource' → '$MountPoint'"
            else
                echo "⭕ 挂载失败［文件→文件］：'$MountSource' → '$MountPoint'"
                return 1
            fi
            
        elif [ -d "$MountSource" ] && [ -d "$MountPoint" ]; then
            if OverlayFSExecutor; then
                echo "✔️ OverlayFS挂载成功［目录→目录内］：'$MountSource' → '$MountPoint'"
            elif BindExecutor; then
                echo "✔️ Bind挂载成功［目录→目录］：'$MountSource' → '$MountPoint'"
            else
                echo "⭕ 挂载失败［目录→目录］：'$MountSource' → '$MountPoint'"
                return 1
            fi
            
        elif [ -f "$MountSource" ] && [ -d "$MountPoint" ]; then
            if OverlayFSExecutor; then
                echo "✔️ OverlayFS挂载成功［文件→目录内］：'$MountSource' → '$MountPoint'"
            elif [ "$Opt2" != "OverlayFS" ]; then
                echo "⭕ 如需将［文件］挂载到［目录内］，需使用OverlayFS进行挂载"
            else
                echo "⭕ 挂载失败［文件→目录］：'$MountSource' → '$MountPoint'"
                return 1
            fi
            
        elif [ -d "$MountSource" ] && [ -f "$MountPoint" ]; then
            echo "⭕ 错误：<设备源>为［目录］时，<挂载点>不能是［文件］"
            return 1
            
        fi
        restorecon -R -F "$MountPoint" >/dev/null 2>&1 || echo "恢复安全上下文失败"
        #========［OverlayFS——Bind挂载］========#
        
    #————若选项①为［-u(卸载挂载点)］————#
    
    elif [ "$Opt1" = "-u" ]; then
        #<挂载点>
        local MountPoint="$2"
        
        if [ ! -e "$MountPoint" ]; then
            echo "□ 挂载点 '$MountPoint' 不存在"
            return 1
        fi
        
        if umount -l "$MountPoint"; then
            echo "✔️ 卸载成功：'$MountPoint'"
            restorecon -R -F "$MountPoint" >/dev/null 2>&1 || echo "恢复安全上下文失败"
        else
            echo "⭕ 卸载失败：'$MountPoint'"
            return 1
        fi
        
    #————若选项①［不存在］————#
    
    else
        echo "⭕ 错误：选项不存在"
        return 1
    fi
}
#利用SingleMount，视<指定目录>为系统根目录，将其内所有文件［挂载］到系统对应位置，或对这些位置［卸载挂载点］（支持Bind挂载）
# $1：选项①［-m］(挂载)  $2：<指定目录>
# $1：选项①［-u］(卸载挂载点)  $2：<指定目录>
BatchMount(){
    local Opt1="$1"

    #————若选项①为［-m(挂载)］或［-u(卸载挂载点)］————#
    
    if [ "$Opt1" = "-m" ] || [ "$Opt1" = "-u" ]; then
        #<指定目录>
        local TargetDir="$2"
        
        if [ ! -e "$TargetDir" ]; then
            echo "□ 指定目录 '$TargetDir' 不存在"
            return 1
        fi
                
    find "$2" -mindepth 2 -type f -print0 | while IFS= read -r -d '' FILE
    do
        if [ "$Opt1" = "-m" ]; then
            SingleMount "$Opt1" "$FILE" "${FILE#$2}"
        elif [ "$Opt1" = "-u" ]; then
            SingleMount "$Opt1" "${FILE#$2}"
        fi
    done

    #————若选项①［不存在］————#

    else
        echo "⭕ 错误：选项不存在"
        return 1
    fi
}
#根据<挂载点>寻找<设备源>。找到则返回<设备源>，找不到则返回1
#$1：<挂载点>
FindMount() {
    MountPoint="$1"
    # 找到 mountinfo 中的行
    info=$(grep "$MountPoint" /proc/self/mountinfo | head -n1)

    if [ -n "$info" ]; then
        # 提取设备路径
        RealSource=$(echo "$info" | awk '{print $4}')
        Device=$(echo "$info" | awk -F' - ' '{print $2}' | awk '{print $2}')
        # 查找设备挂载点（如 /data）
        MountPoint_Of_Dev=$(mount | grep "$Device" | awk '{print $3}' | head -n1)
        # 拼出完整路径
        echo "${MountPoint_Of_Dev}${RealSource}"
        
        return 0
    else
        return 1
    fi
}
#####————————————[挂载]系列函数————————————#####






#####————————————[修改文件值]系列函数————————————#####
#①Mask：面具值——利用SingleMount函数在<挂载点>挂载文件(可向文件输入值)
#②lock_val：锁值——卸载<挂载点>，修改权限为［0644］，修改权限组为［root;root］
#③mask_val：锁值+面具值——在lock_val的基础上，利用Mask函数挂载同值文件
#对于①：$1：<挂载点>  $2：<值>(可留空)
#对于②③：$1：<值>  $2：<挂载点>
#【注意①】：对于上述三者的<挂载点>，输入［目录］则处理该目录内的所有［文件］，输入［文件］则处理该［文件］，包含"通配符"时不能用引号包裹
#【注意②】：为避免可能的［因无法读写原文件导致的死机或报错］［与他人模块冲突］，若效果足够，使用lock_val
Mask(){
    local FILE
    
    find "$1" -type f -print0 | while IFS= read -r -d '' FILE
    do
        FILE="$(realpath "$FILE")"
        umount -l "$FILE" >/dev/null 2>&1
        MountMask="$CACHE_DIR/MountMask_$(date "+%s%N")"
        echo "$2" > "$MountMask"
        if SingleMount "-m" "$MountMask" "$FILE" >/dev/null 2>&1
        then
            echo "[Mask]✔️ 面具值已挂载到：'$FILE'"
        else
            echo "[Mask]⭕ 挂载异常"
            return 1
        fi
    done
}
lock_val() {
    local FILE
    
    find "$2" -type f -print0 | while IFS= read -r -d '' FILE
    do
        FILE="$(realpath "$FILE")"
        umount -l "$FILE" >/dev/null 2>&1
        chown root:root "$FILE"
        chmod 0644 "$FILE"
        echo "$1" >"$FILE"
        chmod 0444 "$FILE" >/dev/null 2>&1
    done
}
mask_val() {
    local FILE

    find "$2" -type f -print0 | while IFS= read -r -d '' FILE
    do
        FILE="$(realpath "$FILE")"
        lock_val "$1" "$FILE"
        Mask "$FILE" "$1" >/dev/null
    done
}

#####————————————[修改文件值]系列函数————————————#####







#####————————————[进程、应用]系列函数————————————#####
#根据[自定义项目值]处理进程
#取值格式：［
#   先：自定义项目名="自定义项目值"
#   后：ProcessManager "自定义项目名" "服务名" "进程名" "进程的二进制文件地址(可选)"
#］
#[自定义项目值]可取值(区分大小写) 及 对应的进程处置方式：
#   ON——不处理进程                对应指令：［无］
#   STOP——停止进程                对应指令：［stop］
#   PAUSE——暂停进程              对应指令：［kill -SIGSTOP］
#   RESTART——重启进程           对应指令：［stop && start］
#   STOPDEADLY——停止进程并阻止其启动(重启恢复)    对应指令：［Mask stop］
#   其它值——报错且不处理进程     对应指令：［无］
#注意：
#   ①STOPDEADLY一项，阻止进程启动的办法是等效清空其二进制文件，而这可能造成系统频繁报错等问题，带来额外性能开销
ProcessManager(){
    #自定义项目名、自定义项目值、服务名、进程名、进程PID
    local ProjectName="$1"
    local ProjectValue="$(eval "echo \$$ProjectName")"
    local ServiceName="$2"
    local ProcessName="$3"
    local ProcessPid=$(pidof "$ProcessName")
    local PathToBinary="$4"

    #状态字段、决定字段、状态码、错误日志
    local Status=""
    local Decision=""
    local StatusCode=""
    local ErrorLog=$(mktemp)
    
    case "$ProjectValue" in
        ON)
            Decision="不处理"
            true
            StatusCode=$?
            ;;
        STOP)
            Decision="停止"
            stop "$ServiceName" 2>"$ErrorLog"
            StatusCode=$?
            ;;
        PAUSE)
            Decision="暂停"
            kill -SIGSTOP "$ProcessPid" 2>"$ErrorLog"
            StatusCode=$?
            ;;
        RESTART)
            Decision="重启"
            stop "$ServiceName" && \
            start "$ServiceName" 2>"$ErrorLog"
            StatusCode=$?
            ;;
        STOPDEADLY)
            Decision="停止进程并阻止其启动"
            {
                if [ -z "$PathToBinary" ]; then
                    echo "  ❗未提供进程的二进制文件地址";false
                elif [ ! -e "$PathToBinary" ]; then
                    echo "  ❗地址不存在：［$PathToBinary］";false
                else
                    if Mask "$PathToBinary" >/dev/null; then
                        stop "$ServiceName"
                    else 
                        false
                    fi
                fi
            }  >"$ErrorLog" 2>&1
            StatusCode=$?
            ;;
        *)
            Decision="  ❗不支持的自定义项目值"
            false
            StatusCode=$?
            echo "  ⭕ 不支持的自定义项目值：［$ProjectValue］，［不处理］该进程。" > "$ErrorLog"
            ;;
    esac
    
    if [ -z "$ProcessPid" ]; then
        Status="未找到进程"
    else
        Status="找到进程，PID：［$ProcessPid］"
    fi

    echo "◤————————————————————◥"
    
    echo "  $ProjectName："
    echo "  项目值：［$ProjectValue］——$Decision"   
    echo "  服务名：［$ServiceName］"
    echo "  进程名：［$ProcessName］，$Status"    
    
    if [ "$StatusCode" = 0 ]; then
        echo -e "\n  ✔️ 已［$Decision］该进程。"
    else
        echo -e "\n  ⭕ 存在错误，状态码：［$StatusCode］，错误详情："
        cat "$ErrorLog"
    fi
    rm "$ErrorLog"
    
    echo "◣————————————————————◢"
}
#检测[指定状态]是否符合[指定用户空间]的[指定应用]，[符合/不符合]反馈[0/1]
#输入参数有两种形式：
#$1：状态选项 $2：应用包名（不指定用户空间时，默认其为当前用户空间）
#$1：状态选项 $2：指定用户 $3：应用包名
#$1选项及含义：n未启用 e已启用 d已冻结 s已限制使用 i已安装
#（注意：系统应用未启用或卸载后enabled都=0，所以选项n不能用于检测应用是否安装）
#其它：
#[函数输入参数数量错误/检测选项不支持]会反馈：2
#使用除i以外的选项检测应用状态，但应用不存在，会反馈：3
AppStateChecker() {
    local info
    local enabled
    local suspended

    if [ $# = 2 ]; then
        info=$(dumpsys package "$2" | grep -i "user $(am get-current-user)")
    elif [ $# = 3 ]; then
        info=$(dumpsys package "$3" | grep -i "user $2")
    else
        echo "⭕ 参数数量错误"
        return 2
    fi

    installed=$(echo "$info" | tr ' ' '\n' | grep "installed=" | cut -d= -f2 | tr -d '\n') >/dev/null 2>&1
    enabled=$(echo "$info" | tr ' ' '\n' | grep "enabled=" | cut -d= -f2 | tr -d '\n') >/dev/null 2>&1
    suspended=$(echo "$info" | tr ' ' '\n' | grep "suspended=" | cut -d= -f2 | tr -d '\n') >/dev/null 2>&1

    if [ "$1" = "i" ]; then
        if [ -n "$info" ] && [ "$installed" = "true" ]; then
            return 0
        else
            return 1
        fi
    else
        [ -z "$info" ] || [ "$installed" = "false" ] && return 3
    fi

    case "$1" in
        n) 
            [ "$enabled" = "0" ] && return 0 || return 1
            ;;
        e) 
            [ "$enabled" = "1" ] && return 0 || return 1
            ;;
        d) 
            [ "$enabled" = "2" ] || [ "$enabled" = "3" ] && return 0 || return 1
            ;;
        s) 
            [ "$suspended" = "true" ] && return 0 || return 1
            ;;
        *)
            echo "⭕ 不支持的检测项"
            return 2
            ;;
    esac
}
###【PM指令集】###
#UInstall：
#输入参数有两种形式：
#$1：性质选项 $2：应用包名/apk文件
#$1：性质选项 $2：指定用户 $3：应用包名/apk文件
#$1各选项的含义：
#i：系统级安装指定安装包，再将其安装到指定用户（若不指定用户，默认其为主用户(0)）
#ie：将已系统级安装的应用安装到指定用户（若不指定用户，默认其为当前用户）（注意：将自动启用安装的应用）
#u：将应用从指定用户卸载（若不指定用户，默认其为所有用户(此时若应用在系统共享目录的APK无法删除时，该指令彻底无效)）
UInstall(){
    if [ $# = 2 ]; then
        if [ $1 = i ]; then
            echo "■ 尝试为 '主用户(0) '安装' '$2'，结果："
            pm install "$2"
        elif [ $1 = ie ]; then
            echo "■ 尝试为 '用户$(am get-current-user)' '安装并启用' '$2'，结果："
            pm install-existing "$2"
            pm enable "$2"
        elif [ $1 = u ]; then
            echo "■ 尝试为 '所有用户' '卸载' '$2'，结果："
            pm uninstall "$2"
        else
            echo "⭕ 不支持的选项"
            return 1
        fi
    elif [ $# = 3 ]; then
        if [ $1 = i ]; then
            echo "■ 尝试为 '用户$2' '安装' '$3'，结果："
            pm install --user "$2" "$3"
        elif [ $1 = ie ]; then
            echo "■ 尝试为 '用户$2' '安装并启用' '$3'，结果："
            pm install-existing --user "$2" "$3"
            pm enable --user "$2" "$3"
        elif [ $1 = u ]; then
            echo "■ 尝试为 '用户$2' '卸载' '$3'，结果："
            pm uninstall --user "$2" "$3"
        else
            echo "⭕ 不支持的选项"
            return 1
        fi
    else
        echo "⭕ 参数数量错误"
        return 1
    fi
}
#DEnable：
#输入参数有两种形式：
#$1：性质选项 $2：应用包名/应用组件
#$1：性质选项 $2：指定用户 $3：应用包名/应用组件
#$1各选项的含义：
#e/d：在指定用户，[启用/禁用]指定[应用、应用组件]（若不指定用户，默认其为当前用户）
DEnable(){
    if [ $# = 2 ]; then
        if [ $1 = e ]; then
            echo "■ 尝试为 '用户$(am get-current-user)' '启用' '$2'，结果："
            pm enable "$2"
        elif [ $1 = d ]; then
            echo "■ 尝试为 '用户$(am get-current-user)' '禁用' '$2'，结果："
            pm disable "$2"
        else
            echo "⭕ 不支持的选项"
            return 1
        fi
    elif [ $# = 3 ]; then
        if [ $1 = e ]; then
            echo "■ 尝试为 '用户$2' '启用' '$3'，结果："
            pm enable --user "$2" "$3"
        elif [ $1 = d ]; then
            echo "■ 尝试为 '用户$2' '禁用' '$3'，结果："
            pm disable --user "$2" "$3"
        else
            echo "⭕ 不支持的选项"
            return 1
        fi
    else
        echo "⭕ 参数数量错误"
        return 1
    fi
}
#Ususpend：
#输入参数有两种形式：
#$1：性质选项 $2：应用包名
#$1：性质选项 $2：指定用户 $3：应用包名
#$1各选项的含义：
#u/s：在指定用户，[解除限制使用/限制使用]指定应用（若不指定用户，默认其为当前用户）
USuspend(){
    if [ $# = 2 ]; then
        if [ $1 = u ]; then
            echo "■ 尝试为 '用户$(am get-current-user)' '解除限制使用' '$2'，结果："
            pm unsuspend "$2"
        elif [ $1 = s ]; then
            echo "■ 尝试为 '用户$(am get-current-user)' '限制使用' '$2'，结果："
            pm suspend "$2"
        else
            echo "⭕ 不支持的选项"
            return 1
        fi
    elif [ $# = 3 ]; then
        if [ $1 = u ]; then
            echo "■ 尝试为 '用户$2' '解除限制使用' '$3'，结果："
            pm unsuspend --user "$2" "$3"
        elif [ $1 = s ]; then
            echo "■ 尝试为 '用户$2' '限制使用' '$3'，结果："
            pm suspend --user "$2" "$3"
        else
            echo "⭕ 不支持的选项"
            return 1
        fi
    else
        echo "⭕ 参数数量错误"
        return 1
    fi
}
#####————————————[进程、应用]系列函数————————————#####



#####————————————[按键选择]系列函数————————————#####
# 小结：
# key_register注册项目，key_running_lite/full执行项目
# 同一脚本内，可做到多次运行key_running_lite/full而不[打乱选择顺序]和[记录的选择]

#项目注册函数
#根据计数器设置动态变量以分别记录输入的五个参数：'项目名' '选择1的描述' '选择1的指令' '选择2的描述' '选择2的指令' 
#注意①：同一脚本内，项目名不能重复，不能[是/含有]空或空白字符
#注意②：为避免可能的复杂问题，建议将指令封装在函数里
key_register() {
    count_register=$((count_register + 1))
    eval "subject_${count_register}=\"$1\""
    eval "description1_${count_register}=\"$2\""
    eval "commands1_${count_register}=\"$3\""
    eval "description2_${count_register}=\"$4\""
    eval "commands2_${count_register}=\"$5\""
}
#按键信号检测函数
#key_click输出执行该函数后按下的第一个按键
# 还可输入一个参数$1——等待输入时长(时间格式同sleep指令)，此时暴露的TimeLeft表示剩余时间
# key_click是否为空可用于检测是否超时
# Time_Window_Interval表示采集按键的时间窗口，同时也是每次采集的时间间隔
key_checker() {
    key_click=""
    local TMP_EVENT_FILE="$CACHE_DIR/event_$$.tmp"
    local TimeTotal="$1"
    TimeLeft=""
    Time_Window_Interval="0.3"
    
    if [ -z "$TimeTotal" ]
    then
        while [ -z "$key_click" ]; do
            event_info=$(getevent -qlc 1)
            key_click=$(echo "$event_info" | awk '{ if ($2 == "EV_KEY" && $4 == "DOWN") print $3 }')
        done
    else
        TimeLeft="$TimeTotal"
        while [ -z "$key_click" ]; do
            TimeLeft=$(echo "$TimeLeft - $Time_Window_Interval" | bc)
    
            (getevent -qlc 1 > "$TMP_EVENT_FILE" &)
            sleep "$Time_Window_Interval"

            if [ -s "$TMP_EVENT_FILE" ]; then
                event_info=$(cat "$TMP_EVENT_FILE")
                key_click=$(echo "$event_info" | awk '{ if ($2 == "EV_KEY" && $4 == "DOWN") print $3 }')
            fi

            if [ $(echo "$TimeLeft <= 0" | bc) -eq 1 ]; then
                break
            fi
        done
    fi
}
#项目执行函数
#原理：根据计数器分别扩展来自key_register的5个变量，然后：[给出项目名和选择项描述] [接收按键信号，根据按键信号选择并执行对应代码]
#提示：
#  ①另可输入1个参数：等待时长(不带单位，单位为秒)，当存在该变量需决定是否开启"选择超时自动跳过"功能，不存在该变量时当作"不开启超时自动跳过"功能继续执行
#  ②按下音量键将直接退出该函数
#  ③为兼容key_running_full，在每次选择时，记录[项目名和所选选择的描述]
key_running_lite() {
    [ -z "$count_running" ] && count_running=0
    local description
    local subject
    local description1
    local commands1
    local description2
    local commands2
    local TimeTotal=$1
    local OUT="0"
    
    if [ -n "$TimeTotal" ]; then
        DelayedPrinter "🛠️ 是否开启'选择超时自动跳过'功能？（'$TimeTotal秒'超时）"
        DelayedPrinter "[音量 ↑ 键]：开启  [音量 ↓ 键]：关闭"
        TIMEOUT(){
            case "$key_click" in
                "KEY_VOLUMEUP")
                    DelayedPrinter -e "> 【[开启]'超时自动跳过'功能（'$TimeTotal秒'超时）】\n"
                    ;;
                "KEY_VOLUMEDOWN")
                    DelayedPrinter -e "> 【[关闭]'超时自动跳过'功能】 \n"
                    TimeTotal=""
                    ;;
                *)
                    key_checker;TIMEOUT
                    ;;
            esac
        }
        key_checker;TIMEOUT
    fi

    while [ $count_register -gt $count_running ]; do
        #准备要用到的各个变量
        count_running=$((count_running + 1))
        subject=$(eval "echo \$subject_${count_running}")
        description1=$(eval "echo \$description1_${count_running}")
        commands1=$(eval "echo \$commands1_${count_running}")
        description2=$(eval "echo \$description2_${count_running}")
        commands2=$(eval "echo \$commands2_${count_running}")
        
        #给出项目名和其两个选择的描述
        DESCRIPTION() {
            sleep 0.2
            DelayedPrinter "#——————————————————————————#"
            DelayedPrinter "🔧 当前项目：$subject"
            DelayedPrinter "   [音量 ↑ 键] $description1"
            DelayedPrinter "   [音量 ↓ 键] $description2"
            DelayedPrinter "#——————————————————————————#"
        }
        #根据项目名和按键选择，执行对应代码，并记录选择
        CASES() {
            if [ -z "$key_click" ]; then
                DelayedPrinter "> 选择超时"
                DelayedLineFeeder "4" "--0.05"
                return 1
            fi
            case "$key_click" in
            "KEY_VOLUMEUP")
                DelayedPrinter "======================================"
                DelayedPrinter "> [音量 ↑ 键] $description1"
                DelayedPrinter "--0.05"
                DelayedPrinter "《————执行结果————》："
                eval "$commands1"
                DelayedPrinter "======================================"
                DelayedLineFeeder "4" "--0.05"
                choice="$choice > $subject：$description1 \n"
                ;;
            "KEY_VOLUMEDOWN")
                DelayedPrinter "======================================"
                DelayedPrinter "> [音量 ↓ 键] $description2"
                DelayedPrinter "--0.05"
                DelayedPrinter "《————执行结果————》："
                eval "$commands2"
                DelayedPrinter "======================================"
                DelayedLineFeeder "4" "--0.05"
                choice="$choice > $subject：$description2 \n"
                ;;
            *)
                DelayedPrinter "> [非音量键] 退出按键选择程序"
                OUT="1"
                ;;
            esac
        }
        DESCRIPTION
        key_checker "$TimeTotal"
        CASES
        [ "$OUT" = "1" ] && return 0
    done
}
#继承key_running_lite，并在遍历结束后，输出记录的[项目名和所选选择的描述]
key_running_full() {
    local Line=""
    
    key_running_lite "$1"
    DelayedLineFeeder "4" "--0.05"
    DelayedPrinter "#——————————————————————————#"
    DelayedPrinter "--0.05"
    DelayedPrinter "选择结果："
    DelayedPrinter "--0.05"
    DelayedPrinter "-e" "$choice"
    DelayedPrinter "--0.05"
    DelayedPrinter "#——————————————————————————#"
    DelayedLineFeeder "4" "--0.05"
}
#####————————————[按键选择]系列函数————————————#####




#####————————————[数值处理]系列函数————————————#####
#函数功能：输入［目标数值］［包括单行任意顺序纯数字的文件］ ，给出匹配的数字
#函数用法：
#   NumSelector "<目标数值>" "<单行纯数字文件地址>"
#   ［其中］
#       "目标数值"的取值格式：
#           ①Min/Max——获取［最小数值/最大数值］
#           ②≥>≤<加纯数字（如："≤400"）
#               大于：取大于目标数值的第一个数值
#               小于：取小于目标数值的第一个数值
#注意：
#   ①❗该函数的正常运行需系统具备bc计算器程序❗
NumSelector(){
    local TargetValue="$1"
    local Orientation=""
    local TargetNum=""
    local AllOfNumbers="$(cat $2)"
    local CurrentNum=""
    local Num_Min=""
    local Num_Max=""
    local Num_FirstLowerThan_TN=""
    local Num_FirstNoMoreThan_TN=""
    local Num_FirstMoreThan_TN=""
    local Num_FirstNoLowerThan_TN=""
    local Num_Fin=""

    if [ -z "$AllOfNumbers" ]; then
        echo "❌ <单行纯数字文件地址>所指向文件为空"
        return 1
    fi

    case "$TargetValue" in
        Min)
            Orientation="Min"
            TargetNum=""
            ;;
        Max)
            Orientation="Max"
            TargetNum=""
            ;;
        "<"*)
            Orientation="<"
            TargetNum="${TargetValue#<}"
            ;;
        "≤"*)
            Orientation="≤"
            TargetNum="${TargetValue#≤}"
            ;;
        ">"*)
            Orientation=">"
            TargetNum="${TargetValue#>}"
            ;;
        "≥"*)
            Orientation="≥"
            TargetNum="${TargetValue#≥}"
            ;;
        *)
            echo "❌ <目标数值>取值格式错误" >&2
            return 1
            ;;
    esac

    #开始遍历 单行纯数字文件 中的每个数字
    #每次得到的结果，都赋予Num_Fin
    for CurrentNum in $AllOfNumbers
    do
        #选择性运算
        case "$Orientation" in
            #对于遍历到的数字：
            Min)
                #所有数字中的Min
                #   Num_Min为空时，
                #       赋予
                #   Num_Min不为空时，
                #       如果：小于当前值，赋予
                if [ -z "$Num_Min" ]; then
                    Num_Min="$CurrentNum"
                elif [ -n "$Num_Min" ]; then
                    if [ "$(echo "$CurrentNum < $Num_Min" | bc)" = "1" ]; then
                        Num_Min="$CurrentNum"
                    fi
                fi
                Num_Fin="$Num_Min"
                ;;
            Max)
                #所有数字中的Max
                #   Num_Max为空时，
                #       赋予
                #   Num_Max不为空时，
                #       如果：大于当前值，赋予
                if [ -z "$Num_Max" ]; then
                    Num_Max="$CurrentNum"
                elif [ -n "$Num_Max" ]; then
                    if [ "$(echo "$CurrentNum > $Num_Max" | bc)" = "1" ]; then
                        Num_Max="$CurrentNum"
                    fi
                fi
                Num_Fin="$Num_Max"
                ;;
            "<")
                #＜TargetNum 的第一个数字
                #   Num_FirstLowerThan_TN为空时，
                #       如果：小于TargetNum，赋予
                #   Num_FirstLowerThan_TN不为空时，
                #       如果：小于TargetNum 且 大于当前值，赋予
                if [ -z "$Num_FirstLowerThan_TN" ]; then
                    if [ "$(echo "$CurrentNum < $TargetNum" | bc)" = "1" ]; then
                        Num_FirstLowerThan_TN="$CurrentNum"
                    fi
                elif [ -n "$Num_FirstLowerThan_TN" ]; then
                    if [ "$(echo "$CurrentNum < $TargetNum" | bc)" = "1" ] && \
                      [ "$(echo "$CurrentNum > $Num_FirstLowerThan_TN" | bc)" = "1" ]; then
                        Num_FirstLowerThan_TN="$CurrentNum"
                    fi
                fi
                Num_Fin="$Num_FirstLowerThan_TN"
                ;;
            "≤")
                #≤TargetNum 的第一个数字
                #   Num_FirstNoMoreThan_TN为空时，
                #       如果：等于TargetNum，赋予，立刻赋予Num_Fin，break
                #       如果：小于TargetNum，赋予
                #   Num_FirstNoMoreThan_TN不为空时，
                #       如果：等于TargetNum，赋予，立刻赋予Num_Fin，break
                #       如果：小于TargetNum 且 大于当前值，赋予
                if [ -z "$Num_FirstNoMoreThan_TN" ]; then
                    if [ "$(echo "$CurrentNum == $TargetNum" | bc)" = "1" ]; then
                        Num_FirstNoMoreThan_TN="$CurrentNum"
                        Num_Fin="$Num_FirstNoMoreThan_TN"
                        break
                    elif [ "$(echo "$CurrentNum < $TargetNum" | bc)" = "1" ]; then
                        Num_FirstNoMoreThan_TN="$CurrentNum"
                    fi
                elif [ -n "$Num_FirstNoMoreThan_TN" ]; then
                    if [ "$(echo "$CurrentNum == $TargetNum" | bc)" = "1" ]; then
                        Num_FirstNoMoreThan_TN="$CurrentNum"
                        Num_Fin="$Num_FirstNoMoreThan_TN"
                        break
                    elif [ "$(echo "$CurrentNum < $TargetNum" | bc)" = "1" ] && \
                        [ "$(echo "$CurrentNum > $Num_FirstNoMoreThan_TN" | bc)" = "1" ]; then
                        Num_FirstNoMoreThan_TN="$CurrentNum"
                    fi
                fi
                Num_Fin="$Num_FirstNoMoreThan_TN"
                ;;
            ">")
                #＞TargetNum 的第一个数字
                #   Num_FirstMoreThan_TN为空时，
                #       如果：大于TargetNum，赋予
                #   Num_FirstMoreThan_TN不为空时，
                #       如果：大于TargetNum 且 小于当前值，赋予
                if [ -z "$Num_FirstMoreThan_TN" ]; then
                    if [ "$(echo "$CurrentNum > $TargetNum" | bc)" = "1" ]; then
                        Num_FirstMoreThan_TN="$CurrentNum"
                    fi
                elif [ -n "$Num_FirstMoreThan_TN" ]; then
                    if [ "$(echo "$CurrentNum > $TargetNum" | bc)" = "1" ] && \
                      [ "$(echo "$CurrentNum < $Num_FirstMoreThan_TN" | bc)" = "1" ]; then
                        Num_FirstMoreThan_TN="$CurrentNum"
                    fi
                fi                
                Num_Fin="$Num_FirstMoreThan_TN"
                ;;
            "≥")
                #≥TargetNum 的第一个数字
                #   Num_FirstNoLowerThan_TN为空时，
                #       如果：等于TargetNum，赋予，立刻赋予Num_Fin，break
                #       如果：大于TargetNum，赋予
                #   Num_FirstNoLowerThan_TN不为空时，
                #       如果：等于TargetNum，赋予，立刻赋予Num_Fin，break
                #       如果：大于TargetNum 且 小于当前值，赋予
                if [ -z "$Num_FirstNoLowerThan_TN" ]; then
                    if [ "$(echo "$CurrentNum == $TargetNum" | bc)" = "1" ]; then
                        Num_FirstNoLowerThan_TN="$CurrentNum"
                        Num_Fin="$Num_FirstNoLowerThan_TN"
                        break
                    elif [ "$(echo "$CurrentNum > $TargetNum" | bc)" = "1" ]; then
                        Num_FirstNoLowerThan_TN="$CurrentNum"
                    fi
                elif [ -n "$Num_FirstNoLowerThan_TN" ]; then
                    if [ "$(echo "$CurrentNum == $TargetNum" | bc)" = "1" ]; then
                        Num_FirstNoLowerThan_TN="$CurrentNum"
                        Num_Fin="$Num_FirstNoLowerThan_TN"
                        break
                    elif [ "$(echo "$CurrentNum > $TargetNum" | bc)" = "1" ] && \
                        [ "$(echo "$CurrentNum < $Num_FirstNoLowerThan_TN" | bc)" = "1" ]; then
                        Num_FirstNoLowerThan_TN="$CurrentNum"
                    fi
                fi
                Num_Fin="$Num_FirstNoLowerThan_TN"
                ;;
        esac
    done


    if [ -z "$Num_Fin" ]; then
        echo "⭕ 未找到匹配数字" >&2
        return 1
    elif [ -n "$Num_Fin" ]; then
        echo "$Num_Fin"
        return 0
    fi
}
#####————————————[数值处理]系列函数————————————#####








