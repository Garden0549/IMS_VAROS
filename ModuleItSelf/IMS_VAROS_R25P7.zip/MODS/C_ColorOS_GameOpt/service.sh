CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】

#——————————————————————————#

ProcessManager \
"GameOpt" \
"gameopt_hal_service-1-0" \
"vendor.oplus.hardware.gameopt-service" \
"/odm/bin/hw/vendor.oplus.hardware.gameopt-service"

#——————————————————————————#

GameOpt_ProcfsDir="/proc/game_opt"


GamePID="$GameOpt_ProcfsDir/game_pid"
RTInfo="$GameOpt_ProcfsDir/rt_info"
FreqLimit="$GameOpt_ProcfsDir/disable_cpufreq_limit"
Debug="$GameOpt_ProcfsDir/debug_enable"
FakeCPU7="$GameOpt_ProcfsDir/fake_cpu7_cpuinfo_max_freq"
SGS="$GameOpt_ProcfsDir/skip_gameself_setaffinity"
LS="$GameOpt_ProcfsDir/lock_stealing"

EarlyDetect1="$GameOpt_ProcfsDir/early_detect/ed_enable"
EarlyDetect2="/proc/oplus_cpu_game/early_detect/ed_enable"

YieldOpt="$GameOpt_ProcfsDir/yield_opt"

TB="$GameOpt_ProcfsDir/task_boost"
TB_CT="$TB/ct_enable"
TB_HTB="$TB/htb_enable"

FLT="$GameOpt_ProcfsDir/frame_load_track/flt_enable"

MT="$GameOpt_ProcfsDir/multi_task/multi_task_util_enable"

#——————————————————————————#

if [ -e "$GameOpt_ProcfsDir" ]
then
    [ -e "$GamePID" ] && {
        mask_val "0" "$GamePID" && \
        echo "✔️ 已移除GameOpt的所有［目标进程］，并阻止新进程加入"
    }
    [ -e "$RTInfo" ] && {
        mask_val "0" "$RTInfo"  && \
        echo "✔️ 已移除GameOpt的所有［目标渲染线程］，并阻止新渲染线程加入"
    }
    [ -e "$FreqLimit" ] && {
        mask_val "1" "$FreqLimit" && \
        echo "✔️ 已关闭GameOpt的［GPA——CPU频率限制］功能"
    }
    [ -e "$Debug" ] && {
        mask_val "0" "$Debug" && \
        echo "✔️ 已关闭GameOpt的［调试输出］功能"
    }
    [ -e "$FakeCPU7" ] && {
        mask_val "0" "$FakeCPU7" && \
        echo "✔️ 已关闭GameOpt的［CPU7频率伪装］功能"
    }
    [ -e "$SGS" ] && {
        mask_val "0" "$SGS" && \
        echo "✔️ 已关闭GameOpt的［调试与跳过游戏自放置线程］功能"
    }
    [ -e "$LS" ] && {
        mask_val "0 0" "$LS" && \
        echo "✔️ 已移除GameOpt的所有［RWSEM 读锁窃取任务］，并阻止新任务加入"
    }
    
    #————————————————————#
    
    [ -e "$EarlyDetect1" ] || [ -e "$EarlyDetect2" ] && {
        mask_val "0" "$EarlyDetect1" || \
        mask_val "0" "$EarlyDetect2" && \
        echo "✔️ 已关闭GameOpt的［帧率感知的早期检测］功能"
    }
    
    #————————————————————#
    
    [ -e "$YieldOpt" ] && {
        mask_val "0 120 10" "$YieldOpt" && \
        echo "✔️ 已关闭GameOpt的［Yield优化］功能"
    }
    
    #————————————————————#
    
    [ -e "$TB" ] && {
        mask_val "0" "$TB_CT" && \
        mask_val "0" "$TB_HTB" && \
        echo "✔️ 已关闭GameOpt的［特定任务性能提升］功能"
    }
    
    #————————————————————#
    
    [ -e "$FLT" ] && {
        mask_val "0" "$FLT" && \
        echo "✔️ 已关闭GameOpt的［帧负载跟踪］功能"
    }
    
    #————————————————————#
    
    [ -e "$MT" ] && {
        mask_val "0" "$MT" && \
        echo "✔️ 已关闭GameOpt的［多任务负载跟踪］功能"
    }
else
    echo "GameOpt的Procfs参数目录不存在，不做修改"
fi

#——————————————————————————#










