CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#可用CPU核心数控制
#(在MTK设备上,重启PowerHAL进程会重置以下所有文件)
#［26.8.15-20：26］↑这两条信息，一年又三个月前留下的，好旧，好早，好安静。下面这个函数的日志输出条件也很早了
KILL_CORECTL(){
    for i in /sys/devices/system/cpu/cpu*; do
        [ -f $i/core_ctl/enable ] && {
          lock_val 1 $i/core_ctl/enable
        }
        
        [ -f $i/core_ctl/min_cpus ] && {
          lock_val 99 $i/core_ctl/min_cpus
        }
        
        [ -f $i/core_ctl/max_cpus ] && {
          lock_val 99 $i/core_ctl/max_cpus
        }
        
        [ -f $i/core_ctl/enable ] && {
          lock_val 0 $i/core_ctl/enable
        }
    done
}
KILL_CORECTL;echo "『CoreCtl』已尝试阻止系统自动关闭CPU核心"


ThermalZone(){
    ThermalZone_CPUHWTrip(){
        #单位：毫℃
        local EmulTemp="105000"
        for thermal_zone in /sys/class/thermal/*
        do
            if [ -f "$thermal_zone/temp" ]
            then
                case "$(cat "$thermal_zone/type")" in
                    cpu-hw-trip*)
                        lock_val "$EmulTemp" "$thermal_zone/emul_temp"
                        CPUHWTripFounded="True"
                    ;;
                    *)
                        true
                    ;;
                esac
            fi
        done
        
        [ "$CPUHWTripFounded" = "True" ] && echo "『ThermalZone』已将温度墙'CPUHWTrip'温度设为105℃"
    }




    ThermalZone_CPUHWTrip
}
ThermalZone








