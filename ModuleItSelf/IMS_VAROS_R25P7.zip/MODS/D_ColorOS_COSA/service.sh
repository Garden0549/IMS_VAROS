CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



Rectifying(){
    if [ -f $CURMODDIR/ClearCOSA ]; then
        rm -f $CURMODDIR/ClearCOSA
        pm clear "com.oplus.cosa" >/dev/null && \
        DelayedPrinter "为避免可能的异常，已为当前用户清空'com.oplus.cosa'的数据"
    fi
    for i in com.oplus.cosa com.oplus.games
    do
        if $(AppStateChecker "n" "$i"); then
            DEnable "e" "$i" >/dev/null
            pm clear "$i" >/dev/null
            DelayedPrinter "--0.05"
            DelayedPrinter "为避免可能的异常，已为当前用户矫正'$i'的启用状态并清空其数据"
        fi
    done
    DelayedPrinter "矫正检测结束"
}
DealComponents(){
    DEnable "d" "com.oplus.cosa/.gpalibrary.service.GPAService" >/dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.gamemanagersdk.HyperBoostService" >/dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.gamemanagersdk.CosaHyperBoostService" >/dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.oiface.OifaceService" >/dev/null 2>&1
    DelayedPrinter "已关闭[应用增强服务]组件：俩Hyper GPA OiFace(如果有)"
}
Cleaning(){
    sqlite3=$ROOTMODDIR/Bin/sqlite3
    COSAService=com.oplus.cosa/com.oplus.cosa.service.COSAService
    AB_COSA=$CURMODDIR/AB_COSA.txt
    
    DelayedPrinter "【阶段一】启动[应用增强服务]，检测其是否异常，等待数据库创建"
    #1.启动[应用增强服务]，等待足够时间以确保检测到其正常启动或异常时的自行终止
    #  未能启动，报未能启动，采集日志并提示提交模块开发者，报停止处理
    #  成功启动，报成功启动，等待10秒以等待数据库的创建，再检查数据库是否存在：
    #   不存在，报不存在，报停止处理
    #   存在，报存在、将删除其中的[应用性能调度配置表]
    DEnable "e" "$COSAService" >/dev/null 2>&1
    am startservice -n "$COSAService" >/dev/null 2>&1
    sleep 3
    if ! pidof "com.oplus.cosa" >/dev/null 2>&1; then
        DelayedPrinter "× 未能启动[应用增强服务]，已采集其日志，请提交模块开发者"
        DelayedPrinter "日志位于：'$AB_COSA'"
        DelayedPrinter "停止处理"
        timeout 3 logcat | grep -i "cosa" > "$AB_COSA"
        return 1
    else
        DelayedPrinter "✔️ 成功启动[应用增强服务]，等待10秒以确保数据库正常创建"
        sleep 10
        #关于筛选真实数据库时的取舍：
        #   由于无论设备是否有多个用户，/data/data/通常只指向/data/user/0/
        #   所以，筛选和使用真实数据库时，优先/data/data/外的
        local COSA_Database1="/data/user/$(am get-current-user)/com.oplus.cosa/databases/db_game_database"
        local COSA_Database2="/data/user_de/$(am get-current-user)/com.oplus.cosa/databases/db_game_database"
        local COSA_Database0="/data/data/com.oplus.cosa/databases/db_game_database"
        local COSA_Database=""
        for i in "$COSA_Database1" "$COSA_Database2" "$COSA_Database0"
        do
            [ -e "$i" ] && { COSA_Database="$i";break; }
        done
        if [ -z "$COSA_Database" ]; then
            DelayedPrinter "⭕ 未找到[应用增强服务]数据库"
            DelayedPrinter "停止处理"
            return 1
        else
            DelayedPrinter "✔️ 找到[应用增强服务]数据库：'$COSA_Database'，尝试删除其中的[应用性能调度配置表]"
        fi
    fi
    
    DelayedPrinter "--0.05"
    
    DelayedPrinter "【阶段二】删除[应用性能调度配置表]"
    #2.杀死[应用增强服务]和[游戏助手]以彻底关闭数据库保护
    #  再删除[应用增强服务]数据库中的[应用性能调度配置表]
    #  等待sqlite3运行3秒
    am force-stop com.oplus.games
    am force-stop com.oplus.cosa
    $sqlite3 "$COSA_Database" "DROP TABLE IF EXISTS PackageConfigBean;"
    sleep 3
    DelayedPrinter "❓ 已尝试删除[应用性能调度配置表]"
    
    DelayedPrinter "--0.05"
    
    DelayedPrinter "【阶段三】启动[应用增强服务]，检测其是否异常，检测[应用性能调度配置表]是否存在"
    #3.复启动[应用增强服务]，等待足够时间以确保检测到其正常启动或异常时的自行终止
    #  未能启动，报未能启动，采集日志并提示提交模块开发者，报停止处理
    #  成功启动，报成功启动，检查[应用性能调度配置表]是否存在：
    #    存在，报未能删除
    #    不存在，报成功删除
    am startservice -n "$COSAService" >/dev/null 2>&1
    sleep 3
    if ! pidof "com.oplus.cosa" >/dev/null 2>&1; then
        DelayedPrinter "× 未能复启动[应用增强服务]，已采集其日志，请提交模块开发者"
        DelayedPrinter "日志位于：'$AB_COSA'"
        DelayedPrinter "停止处理"
        timeout 3 logcat | grep -i "cosa" > "$AB_COSA"
        return 1
    else
        DelayedPrinter "✔️ 成功复启动[应用增强服务]，检查[应用性能调度配置表]是否存在："
        if $sqlite3 "$COSA_Database" "SELECT 1 FROM sqlite_master WHERE name='PackageConfigBean';" | grep -q "1"; then
            DelayedPrinter "⭕ [应用性能调度配置表]未能删除！！"
        else
            DelayedPrinter "✔️ [应用性能调度配置表]成功删除"
        fi
    fi
}


if $(AppStateChecker "i" "com.oplus.cosa")
then
    if $(AppStateChecker "n" "com.oplus.cosa") || $(AppStateChecker "e" "com.oplus.cosa")
    then
        DelayedPrinter -e "\n■ [应用增强服务]已安装且已启用，开始处理\n"
        DelayedPrinter "<——————————>"
        Rectifying
        DelayedPrinter "<——————————>"
        DealComponents
        DelayedPrinter "<——————————>"
        Cleaning
        DelayedPrinter "<——————————>"
    else
        DelayedPrinter "□ [应用增强服务]已禁用，不做处理"
    fi
else
    DelayedPrinter "□ [应用增强服务]未安装，不做处理"
fi







