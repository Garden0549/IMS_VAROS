MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



Main_DealHorae(){
    local Title="①尝试［开启/关闭］Horae进程"
    local Choose_UP="开启"
    local Choose_DOWN="关闭"
    local TimeLimit=""
    
    local HoraeProp=persist.sys.horae.enable
    HoraeChecker(){
        DelayedPrinter "  〔Horae当前状态〕"
        DelayedPrinter "   Horae属性'$HoraeProp'当前值：$(getprop $HoraeProp)"
        if pidof horae > /dev/null 2>&1; then
            DelayedPrinter "   Horae进程已启动，进程PID为'$(pidof horae)'"
        else
            DelayedPrinter "   Horae进程未启动"
        fi
    }
    
    DealHorae(){
        DelayedPrinter "⭕［说明］⭕"
        DelayedPrinter "【0】若关闭Horae进程无负面影响，不建议将其开启"
        DelayedPrinter "【1】开启Horae进程的影响："
        DelayedPrinter "      ①去锁帧模块的去锁帧功能失效"
        DelayedPrinter "      ②游戏内温控锁帧严苛"
        DelayedPrinter "【2】关闭Horae进程的可能影响："
        DelayedPrinter "      ①相机对焦或录像帧率异常"
        DelayedPrinter "【3】该功能所做修改，重启失效"
        DelayedPrinter "【4】启动Horae进程时，会执行一次Horae子模块的机身外壳温度伪装脚本"
        DelayedPrinter "--0.05"
        HoraeChecker
        DelayedPrinter "--0.05"
        DelayedPrinter "⭕［二次确认］⭕"
        DelayedPrinter "   『$Title』"
        DelayedPrinter "    > [音量 ↑ 键]——[$Choose_UP]"
        DelayedPrinter "    > [音量 ↓ 键]——[$Choose_DOWN]"
    
        CASE_DealHorae(){
            if [ -z "$key_click" ]; then
                DelayedPrinter -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    DelayedPrinter -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    resetprop -n $HoraeProp 1 > /dev/null 2>&1
                    sleep 1
                    start horae > /dev/null 2>&1
                    HoraeChecker
                    DelayedPrinter "--0.05"
                    sh "$MODDIR/MODS/E_ColorOS_Horae/Horae_TempDisguising.sh"
                    ;;
                "KEY_VOLUMEDOWN")
                    DelayedPrinter -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    resetprop -n $HoraeProp 0 > /dev/null 2>&1
                    sleep 1
                    stop horae > /dev/null 2>&1
                    HoraeChecker
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_DealHorae
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_DealHorae
    }
    
    if [ -n "$1" ]; then
        DelayedPrinter "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_DealHorae" \
                 "跳过" "DelayedPrinter '你选择了[跳过]'"
    else
        DealHorae
    fi
}



Main_GamesCOSA_Uninstallation(){
    local Title="②彻底卸载［应用增强服务］和［游戏助手］"
    
    Uninstallation(){
        for i in com.oplus.games com.oplus.cosa
        do
            DelayedPrinter "卸载'$i'："
            DelayedPrinter $(UInstall "u" "$(am get-current-user)" "$i")
            DelayedPrinter "再次卸载'$i'以确保彻底卸载："
            DelayedPrinter $(UInstall "u" "$(am get-current-user)" "$i")
            DelayedPrinter "--0.05"
        done
    }
    
    GamesCOSA_Uninstallation(){
        local Choose_UP="卸载"
        local Choose_DOWN="不卸载"
        local TimeLimit=""
    
        DelayedPrinter "⭕［说明］⭕"
        DelayedPrinter "【1】如果卸载，可更彻底地去除官方调度，但也会失去［游戏助手］的所有功能"
        DelayedPrinter
        DelayedPrinter "⭕［二次确认］⭕"
        DelayedPrinter "   『$Title』"
        DelayedPrinter "    > [音量 ↑ 键]——[$Choose_UP]"
        DelayedPrinter "    > [音量 ↓ 键]——[$Choose_DOWN]"
    
        CASE_GamesCOSA_Uninstallation(){
            if [ -z "$key_click" ]; then
                DelayedPrinter -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    DelayedPrinter -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    Uninstallation
                    ;;
                "KEY_VOLUMEDOWN")
                    DelayedPrinter -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_GamesCOSA_Uninstallation
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_GamesCOSA_Uninstallation
    }
    
    if [ -n "$1" ]; then
        DelayedPrinter "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_GamesCOSA_Uninstallation" \
                 "跳过" "DelayedPrinter '你选择了[跳过]'"
    else
        GamesCOSA_Uninstallation
    fi
}



Main_GamesCOSA_Reinstallation(){
    local Title="③彻底卸载再安装系统自带版本的［游戏助手］与［应用增强服务］"
    
    Reinstallation(){
        TraverseDirs="
            /my_bigball\
            /my_carrier\
            /my_company\
            /my_engineering\
            /my_heytap\
            /my_manifest\
            /my_preload\
            /my_product\
            /my_region\
            /my_reserve\
            /my_stock\
            /odm\
            /product\
            /system\
            /system_ext\
            /vendor\
        "
        COSA_DirFin=""
        OplusGames_DirFin=""        
        for i in $(find $TraverseDirs -name "*COSA.apk*" -type f)
        do
            COSA_DirFin=$i
        done
        for i in $(find $TraverseDirs -name "*OplusGames.apk*" -type f)
        do
            OplusGames_DirFin=$i
        done
        
        if [ -z "$COSA_DirFin" ] || [ -z "$OplusGames_DirFin" ]; then
            DelayedPrinter "   功能中止，因为找不到［游戏助手］或［应用增强服务］的安装包"
            return 1
        else
            for i in "$OplusGames_DirFin" "$COSA_DirFin"
            do
                if FindMount "$i" > /dev/null 2>&1; then
                    DelayedPrinter "   功能中止，因为下述安装包被破坏："
                    DelayedPrinter "     $i"
                    DelayedPrinter "   如果想要继续恢复，请检查此路径指向的模块并关闭之："
                    DelayedPrinter "     $(FindMount "$i")"
                    return 1
                fi
            done
        fi
                
        DelayedPrinter "正在重新安装［应用增强服务］和［游戏助手］"
        
        DelayedPrinter "--0.05"
        
        for i in com.oplus.games com.oplus.cosa
        do
            DelayedPrinter "卸载'$i'："
            DelayedPrinter $(UInstall "u" "$(am get-current-user)" "$i")
            DelayedPrinter "再次卸载'$i'以确保彻底卸载："
            DelayedPrinter $(UInstall "u" "$(am get-current-user)" "$i")
            DelayedPrinter "--0.05"
        done

        DelayedPrinter "--0.05"
        
        UInstall "ie" "$(am get-current-user)" "com.oplus.cosa"
        if ! UInstall "ie" "$(am get-current-user)" "com.oplus.games" 2>/dev/null
        then
            DelayedPrinter -e "\n□在本设备上［游戏助手］不是可删除系统应用，"
            DelayedPrinter "  尝试使用系统安装包安装并启用之↓"
            UInstall "i" "$(am get-current-user)" "$OplusGames_DirFin"
            DEnable "e" "com.oplus.games"
        fi

        DelayedPrinter "--0.05"
        
        DelayedPrinter "--0.15" "> 重装结束。"
        DelayedPrinter "--0.15" "> 请通过模块附加程序启动［游戏助手］，并在里面启动游戏一次，观察［游戏助手侧边栏］是否出现"
        DelayedPrinter "--0.15" "> 如果已将游戏加入［游戏助手］，游戏内［游戏助手侧边栏］不出现，其核心原理是："
        DelayedPrinter "--0.15" "  【［游戏助手侧边栏］依赖［应用增强服务］，后者无法启动时前者亦无法启动】"
        DelayedPrinter "--0.15" "  可尝试以下方法："
        DelayedPrinter "--0.15" "  ［1］开启安卓系统的'APP数据隔离'： "
        DelayedPrinter "--0.15" "    - 安装应用［隐藏应用列表］并授予其ROOT权限"
        DelayedPrinter "--0.15" "    - 打开其内'App data 隔离'这个开关"
        DelayedPrinter "--0.15" "    - 最后，重启设备"
        DelayedPrinter "--0.15" "  【原理】若安卓系统的'APP数据隔离'关闭，可能会导致［应用增强服务］无法读写其数据目录而崩溃并终止，无法启动"
        DelayedPrinter "--0.15" "  ［2］在LSPosed中，关闭Thanox，重启设备"
        DelayedPrinter "--0.15" "  【原理】Thanox的某个功能可能阻止了［应用增强服务］［游戏助手］在游戏里自启动"
        DelayedPrinter "--0.15" "  ［3］彻底关闭已安装的“墓碑”，重启设备"
        DelayedPrinter "--0.15" "  【原理】“墓碑”可能冻结而阻止了［应用增强服务］［游戏助手］在游戏里自启动"
        DelayedPrinter "--0.15" "  ［4］卸载再安装［应用增强服务］"
        DelayedPrinter "--0.15" "  【原理】确保［应用增强服务］已安装且已启用"
    }
    
    GamesCOSA_Reinstallation(){
        local Choose_UP="重新安装"
        local Choose_DOWN="不重新安装"
        local TimeLimit=""
    
        DelayedPrinter "⭕［说明］⭕"
        DelayedPrinter "【1】重新安装时，将卸载现已安装的并安装系统自带的［游戏助手］与［应用增强服务］"
        DelayedPrinter "--0.05"
        DelayedPrinter "⭕［二次确认］⭕"
        DelayedPrinter "   『$Title』"
        DelayedPrinter "    > [音量 ↑ 键]——[$Choose_UP]"
        DelayedPrinter "    > [音量 ↓ 键]——[$Choose_DOWN]"
    
        CASE_GamesCOSA_Reinstallation(){
            if [ -z "$key_click" ]; then
                DelayedPrinter -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    DelayedPrinter -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    Reinstallation
                    ;;
                "KEY_VOLUMEDOWN")
                    DelayedPrinter -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_GamesCOSA_Reinstallation
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_GamesCOSA_Reinstallation
    }
    
    if [ -n "$1" ]; then
        DelayedPrinter "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_GamesCOSA_Reinstallation" \
                 "跳过" "DelayedPrinter '你选择了[跳过]'"
    else
        GamesCOSA_Reinstallation
    fi
}



Main_GamesStart(){
    local Title="④便捷打开［游戏助手］页面"
    
    GamesStart(){
        if ! AppStateChecker e "com.oplus.games"; then
            DelayedPrinter "  发现［游戏助手］没有安装或启用，无法打开"
            return 1
        fi
        AppStateChecker e "com.oplus.cosa" || DelayedPrinter "注意：［应用增强服务］没有正常启用，这会导致进入游戏时［游戏助手］侧边栏依然不会自启动"
        DelayedPrinter "  5秒后启动游戏助手"
        DelayedPrinter "  -  为避免因模块附加程序未结束而极易触发的按键误触，"
        DelayedPrinter "  -  将在游戏助手打开后立即退出模块附加程序"
        sleep 5;am start -n com.oplus.games/business.module.desktop.JumpSpaceActivity;exit
    }
    
    if [ -n "$1" ]; then
        DelayedPrinter "  > $Title"
        key_register "$Title" \
                 "打开" "Main_GamesStart" \
                 "不打开" "DelayedPrinter '你选择了[不打开]'"
    else
        GamesStart
    fi
}



#——————————————————————————————#



DelayedPrinter "——————————————————————————————"
DelayedPrinter "『模块附加程序，具有以下功能：』"
DelayedPrinter "--0.05"
for i in Main_DealHorae Main_GamesCOSA_Uninstallation Main_GamesCOSA_Reinstallation Main_GamesStart
do
    $i "Symbol"
done
DelayedPrinter "--0.05"
DelayedPrinter "————————————————————————————————————————"
DelayedPrinter "『如何操作附加程序：』"
DelayedPrinter "--0.05"
DelayedPrinter "  - 即将执行上述功能前，按下机身上的[非音量键]即可退出附加程序"
DelayedPrinter "  - 按下机身上的[音量 ↑ 键]或[音量 ↓ 键]以执行对应功能"
DelayedPrinter "--0.05"
DelayedPrinter "————————————————————————————————————————"
DelayedLineFeeder "4" "--0.05"


DelayedPrinter ">—————————————↓↓↓—————————————<"
DelayedPrinter "  ⭕ 是否【直接退出附加程序】？"
DelayedPrinter "  [音量 ↑ 键]：退出  [音量 ↓ 键]：继续"
DelayedPrinter -e "  （5秒后选择超时，将自动退出附加程序）\n"
ConvenientExport(){
    if [ -z "$key_click" ]; then
        DelayedPrinter "  > 【选择超时，立即退出附加程序】"
        DelayedPrinter -e ">—————————————↑↑↑—————————————<"
        exit
    fi
    case "$key_click" in
        "KEY_VOLUMEUP")
            DelayedPrinter "  > 【你按下了[音量 ↑ 键]，确认[退出]】"
            DelayedPrinter -e ">—————————————↑↑↑—————————————<"
            exit
            ;;
        "KEY_VOLUMEDOWN")
            DelayedPrinter "  > 【你按下了[音量 ↓ 键]，确认[继续]】"
            DelayedPrinter -e ">—————————————↑↑↑—————————————<"
            ;;
        *)
            key_checker "$TimeLeft";ConvenientExport
            ;;
    esac
}
sleep 0.5
key_checker "5";ConvenientExport



DelayedLineFeeder "4" "--0.05"
DelayedPrinter "［—————————————————————————————————————］"
DelayedLineFeeder "4" "--0.05"

key_running_full

DelayedLineFeeder "8" "--0.05"