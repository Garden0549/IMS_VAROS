CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

ConfigDisposer(){
    #功能：
    #   在 指定遍历目录，寻找 指定文件，根据 开关变量的值 决定是否用 指定挂载源 挂载之
    #用法：
    # Mounter "日志输出对象名" \
    #     "指定文件之名" "指定文件之后缀" "指定遍历目录" \
    #     "指定挂载源" \
    #     "开关变量名" \
    #注意：
    #   ①本函数引用的外来函数：SingleMount
    #   ②"指定挂载源"必须是1个文件
    #   ③开关变量的值为1时挂载文件，否则不挂载文件
    Mounter(){
        local Object="$1"
        local CurrentFileName="$2"
        local CurrentFileSuffix="$3"
        local CurrentFile="${CurrentFileName}${CurrentFileSuffix}"
        local TraverseDirs="$4"
        local MountSourceFile="$5"
        local Switch="$(eval "echo \$$6")"
        local FileNumCount="0"
    
    
        for i in $(find $TraverseDirs -name "$CurrentFile" -type f 2>/dev/null)
        do
            FileNumCount="$(( FileNumCount + 1 ))"
            eval "local File_${FileNumCount}='$i'"
        done
        if [ "$Switch" = "1" ]
        then
            if [ "$FileNumCount" = "0" ]
            then
                echo "『$Object』未找到配置［$CurrentFile］"
                return 1
            else
                for i in $(seq 1 $FileNumCount)
                do
                    Temp="$(eval "echo \$File_${i}")"
                    SingleMount "-u" "$Temp" >/dev/null 2>&1
                    SingleMount "-m" "$MountSourceFile" "$Temp"
                done
            fi
            echo
            echo "『$Object』已尝试挂载配置［$CurrentFile］"
        else
            echo "『$Object』不挂载配置［$CurrentFile］"
        fi
    }
    CD_PowerHAL(){
    
        # 1：等效清空  非1：不清空
        PowerHAL_power_app_cfg_Empty=1
        PowerHAL_powerscntbl_Empty=1
        PowerHAL_powercontable_Empty=1
        PowerHAL_RelatedConf_Empty=1    

        CD_PowerHAL_MainConfigCleaner(){
            local CustomConfigDir="$CURMODDIR/CustomConf"
            local Configs="
                power_app_cfg.xml\
                powerscntbl.xml\
                powercontable.xml\
            "
            local TraverseDirs="
                /data/vendor/powerhal\
                /vendor/etc\
                /odm\
            "
            
            echo "===========［清空PowerHAL主要配置］==========="

            for i in $Configs
            do
                CurrentConfigName="${i%.xml}"
                CurrentSwitch="PowerHAL_${CurrentConfigName}_Empty"

                Mounter "PowerHAL" \
                    "$CurrentConfigName" ".xml" "$TraverseDirs" \
                    "$CustomConfigDir/$i" \
                    "$CurrentSwitch"
                
                echo "==========================="
            done

            echo "================================================="
        }
        CD_PowerHAL_RelatedConf_Cleaner(){
            local EmptyConfig="$CURMODDIR/CustomConf/EmptyConfig"
            local Configs_xml="
                breakwhiteapplist.xml\
                thermalbreakboostconfig.xml\
            "
            local Configs_cfg="
                gbe.cfg\
                xgf.cfg\
                fstb.cfg\
                fteh.cfg\
            "
            local TraverseDirs="
                /vendor/etc\
                /data/vendor/powerhal\
                /data/vendor/thermal/config\
            "
    
            
            echo "===========［清空PowerHAL关联配置］==========="
            for i in $Configs_xml
            do
                CurrentConfigName="${i%.xml}"
    
                Mounter "PowerHAL" \
                    "$CurrentConfigName" ".xml" "$TraverseDirs" \
                    "$EmptyConfig" \
                    "PowerHAL_RelatedConf_Empty"
                echo "==========================="
            done
            
            for i in $Configs_cfg
            do
                CurrentConfigName="${i%.cfg}"
    
                Mounter "PowerHAL" \
                    "$CurrentConfigName" ".cfg" "$TraverseDirs" \
                    "$EmptyConfig" \
                    "PowerHAL_RelatedConf_Empty"
                echo "==========================="
            done
            echo "================================================="
        }


        if \
          [ "$PowerHAL_power_app_cfg_Empty" = "1" ] || \
          [ "$PowerHAL_powerscntbl_Empty" = "1" ] || \
          [ "$PowerHAL_powercontable_Empty" = "1" ]
        then
            CD_PowerHAL_MainConfigCleaner
        else
            echo -e "\n『PowerHAL』不清空任何配置\n"
        fi
        
        if [ "$PowerHAL_RelatedConf_Empty" = "1" ]
        then
            CD_PowerHAL_RelatedConf_Cleaner
        else
            echo -e "\n『PowerHAL』不清空任何关联配置\n"
        fi
    }
    CD_MAGT(){
        [ -e "/proc/perfmgr_magt/magt_ioctl_adpf" ] && {
            SingleMount -u "/proc/perfmgr_magt/magt_ioctl" >/dev/null 2>&1
            SingleMount -m "/proc/perfmgr_magt/magt_ioctl_adpf" "/proc/perfmgr_magt/magt_ioctl"
        }
    }
    CD_perfmgr(){
        local Dir="/proc/perfmgr"
        [ -e "$Dir" ] && {
            chmod 0444 "$Dir/global_reclaim"

            SingleMount -u "$Dir/perf_ioctl" >/dev/null 2>&1
            SingleMount -m "$Dir/xgff_ioctl" "$Dir/perf_ioctl"
        }
    }
    CD_perfmgr_powerhal(){
        local Dir="/proc/perfmgr_powerhal"
        [ -e "$Dir" ] && {
            SingleMount -u "$Dir/ioctl_powerhal" >/dev/null 2>&1
            SingleMount -m "$Dir/ioctl_powerhal_adpf" "$Dir/ioctl_powerhal"
        }
    }




    #————『ConfigDisposer_函数执行区』————#
    CD_PowerHAL
    CD_MAGT
    CD_perfmgr
    CD_perfmgr_powerhal
}

#————————————————————————————————————————

MAGT(){
    resetprop -p ro.vendor.magt.mtk_magt_support "0"
}

#————————————————————————————————————————


if [ "$(getprop ro.hardware)" != "qcom" ]
then
    echo -e "\n■ 联发科平台，执行联发科特别屏蔽\n"

    echo "<——［ConfigDisposer］——————————————>"
    ConfigDisposer
    echo "<——［MAGT］——————————————>"
    MAGT

    echo "<——————————————————>"
else
    echo "□ 非联发科平台，不执行联发科特别屏蔽"
fi


#————————————————————————————————————————

