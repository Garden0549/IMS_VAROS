CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

ConfigDisposer(){
    #功能：
    #   重启指定服务
    #用法：
    # ServiceRestarter "日志输出对象名" \
    #     "服务名列表" \
    ServiceRestarter(){
        local Object="$1"
        local ServiceList="$2"
        
        echo "===========［重启$Object］==========="
        
        for SVC in $ServiceList
        do
            if stop "$SVC" 2>/dev/null; then
                echo "『$Object』服务 '$SVC' 存在"
                start "$SVC" && \
                echo "『$Object』服务 '$SVC' 重启成功" || \
                echo "『$Object』服务 '$SVC' 重启失败！"
            else
                echo "『$Object』服务 '$SVC' 无法停止，可能不存在"
            fi
            echo "==========================="
        done
        
        echo "『$Object』已尝试重启服务，以重载可能受其读取的已挂载配置文件"
        
        echo "============================================"
    
    }
    CD_PowerHAL(){
        #注意：后续参数必须在重启PowerHAL服务之后修改，以避免随其重启被重置
        CD_PowerHAL_ServiceRestarter(){
            local ServiceList="
                power-hal-1-0\
                vendor.mtkpower-service.mediatek\
                vendor.mtkpower_applist-default\
            "
        
            ServiceRestarter "PowerHAL" \
                "$ServiceList"
        }


        CD_PowerHAL_ServiceRestarter
    }


    #————『ConfigDisposer_函数执行区』————#
    CD_PowerHAL
}

#————————————————————————————————————————

FPSGO(){
    local KernelDir="/sys/kernel/fpsgo"
    local ModuleDir1="/sys/module/fbt_cpu/parameters"
    local ModuleDir2="/sys/module/mtk_fpsgo/parameters"
    local ModuleDir3="/sys/module/mtk_fpsgo_v3/parameters"
    local ModuleDir4="/sys/module/mtk_fpsgo_v8/parameters"
    local ModuleDir=""
    local GBE_Dir1="/sys/kernel/gbe"
    local GBE_Dir2="/sys/kernel/fpsgo/gbe"
    local GBE_DirFin=""
    local TouchBoost_Dir="/proc/tchbst/user/usrtch"
    for i in "$ModuleDir1" "$ModuleDir2" "$ModuleDir3" "$ModuleDir4"
    do
        [ -e "$i" ] && ModuleDir="$i"
    done
    for i in "$GBE_Dir1" "$GBE_Dir2"
    do
        [ -e "$i" ] && GBE_DirFin="$i"
    done
    [ ! -e "$KernelDir" ] && [ -z "$ModuleDir" ] && {
        echo "『FPSGO』本设备不存在FPSGO内核模块，不做处理"
        return 0
    }    


    ##内核模块
    lock_val "0" "$KernelDir" >/dev/null 2>&1
    mask_val "0" "$KernelDir/common/force_onoff"
    mask_val "0" "$KernelDir/common/fpsgo_enable"
    mask_val "0xFFF" "$KernelDir/fbt/jank_cpu_mask"
    lock_val "0" "$ModuleDir" >/dev/null 2>&1

    if [ -n "$GBE_DirFin" ]
    then
        lock_val "0" "$GBE_DirFin"
        mask_val "0" "$GBE_DirFin/gbe_enable1"
        mask_val "0" "$GBE_DirFin/gbe_enable2"
    fi
    
    mask_val "enable 0" "$TouchBoost_Dir"


    ##内核模块关联用户空间进程
    for Service in fpsgo gbe xgf touch_boost
    do
        stop $Service >/dev/null 2>&1
    done
}

MAGT(){
    lock_val "-1" "/sys/module/mtk_perf_ioctl_magt/parameters"
    stop magt
}

MTK_CoreCtl(){
    mask_val "0" "/sys/module/mtk_core_ctl/parameters/policy_enable"
    
    for i in /sys/devices/system/cpu/cpu*; do
        [ -f "$i/core_ctl/enable" ] && {
            lock_val "1" "$i/core_ctl/enable"
            [ -f "$i/core_ctl/min_cpus" ] && {
                lock_val "99" "$i/core_ctl/min_cpus"
                lock_val "99" "$i/core_ctl/max_cpus"
                lock_val "99 1" "$i/core_ctl/min_cpus"
                lock_val "99 1" "$i/core_ctl/max_cpus"
            }
            lock_val "0" "$i/core_ctl/enable"
        }
    done
}

GPU(){
    sh "$CURMODDIR/GPU.sh"
}

MiscLimiters(){

    cpufreq_Lite_V1_V2(){
        local cpufreq_Lite_Node="/proc/cpudvfs/cpufreq_debug"
        local cpufreq_V1_Node="/proc/cpuhvfs/cpufreq_debug"
        local CurrentPolicy=""
        local CP_AvailableFrequencies=""
        local CP_MinFreq=""
        local CP_MaxFreq=""
        local CP_RelatedCPUS=""


        for CurrentPolicy in /sys/devices/system/cpu/cpufreq/policy*
        do
            CP_AvailableFrequencies="$CurrentPolicy/scaling_available_frequencies"
            CP_MinFreq="$(NumSelector "Min" "$CP_AvailableFrequencies")"
            CP_MaxFreq="$(NumSelector "Max" "$CP_AvailableFrequencies")"
            
            CP_RelatedCPUS="$(cat $CurrentPolicy/related_cpus)"
            
            for CPU in $CP_RelatedCPUS
            do
                for Node in "$cpufreq_Lite_Node" "$cpufreq_V1_Node"
                do     
                    [ -e "$Node" ] && \
                    mask_val "$CPU $CP_MinFreq $CP_MaxFreq" "$Node"
                done            
            done
        done
    }

    perfmgr(){
        lock_val "enable 0" "/proc/perfmgr/tchbst/user/usrtch"
    }

    powerhal_cpu_ctrl(){
        local Dir="/proc/powerhal_cpu_ctrl"
        local CurrentPolicy=""
        local CP_AvailableFrequencies=""
        local CP_MinFreq=""
        local CP_MaxFreq=""
        local CP_Number="0"
        for CurrentPolicy in /sys/devices/system/cpu/cpufreq/policy*
        do
            CP_AvailableFrequencies="$CurrentPolicy/scaling_available_frequencies"
            CP_MinFreq="$(NumSelector "Min" "$CP_AvailableFrequencies")"
            CP_MaxFreq="$(NumSelector "Max" "$CP_AvailableFrequencies")"

            eval "local Cluster${CP_Number}_MinFreq=$CP_MinFreq"
            eval "local Cluster${CP_Number}_MaxFreq=$CP_MaxFreq"
            CP_Number="$(( CP_Number + 1 ))"
        done


        if [ -e "$Dir" ]
        then
            if [ -e "$Dir/enable_cpu_timing_hint" ]; then
            #MT6993
                mask_val "0" "$Dir/enable_cpu_timing_hint"
                for CPUID in $(seq 0 7)
                do
                    mask_val "$CPUID 0 0" "$Dir/perfserv_freq"
                done
    
            elif [ -e "$Dir/adpf_enable" ] && [ -e "$Dir/sf_hint_low_power_enabled" ]; then
            #MT6989
                mask_val "0" "$Dir/adpf_enable"
                mask_val "0" "$Dir/sf_hint_low_power_enabled"
                mask_val "$Cluster0_MinFreq $Cluster0_MaxFreq $Cluster1_MinFreq $Cluster1_MaxFreq $Cluster2_MinFreq $Cluster2_MaxFreq" "$Dir/perfserv_freq"
    
            elif [ -e "$Dir/adpf_enable" ] && [ ! -e "$Dir/sf_hint_low_power_enabled" ]; then
            #MT6991
                mask_val "0" "$Dir/adpf_enable"
                for CPUID in $(seq 0 7)
                do 
                    mask_val "$CPUID 0 0" "$Dir/perfserv_freq"
                done
    
            else
            #MT6985
                mask_val "$Cluster0_MinFreq $Cluster0_MaxFreq $Cluster1_MinFreq $Cluster1_MaxFreq $Cluster2_MinFreq $Cluster2_MaxFreq" "$Dir/perfserv_freq"
            fi
        fi
    }
    
    mtk_game(){
        local EngineCooler_Dir="/sys/module/mtk_game/parameters"
        local Common_Dir="/sys/kernel/game"


        lock_val "0" "$EngineCooler_Dir"

        lock_val "0" "$Common_Dir"
        LIST="$Common_Dir/loom_enable_by_process"
        TGID_LIST=$(cat "$LIST" 2>/dev/null | grep -E '^[0-9]+$')
        for tgid in $TGID_LIST
        do
            mask_val "$tgid 0" "$LIST"
        done
        mask_val "0 0" "$LIST"
        mask_val "0 0 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1" "$Common_Dir/loom_task_cfg"
    }

    Thermal(){
        local Dir="/sys/kernel/thermal"
        MaxTemp=105000  #单位：毫℃
        if [ -e "$Dir" ]
        then
            mask_val "MAX_TTJ $MaxTemp $MaxTemp $MaxTemp" "$Dir/max_ttj"
            mask_val "MIN_TTJ $MaxTemp" "$Dir/min_ttj"
            mask_val "TTJ $MaxTemp $MaxTemp $MaxTemp" "$Dir/ttj"
            mask_val "0" "$Dir/sports_mode"
            mask_val "0" "$Dir/cg_policy_mode"
        fi
    }
    
    FRS(){
        stop frs
    }
    
    pelt_hint(){
        lock_val "0" "/sys/kernel/pelt_hint/common/gai_cpu_boost_enable"
        lock_val "0" "/sys/kernel/pelt_hint/gai_cpu_boost_enable"
    }
    
    power_throttling_related(){
        #①CPU/GPU功耗限制
        # 已知：MT6895: 下杠 / MT6993: 连字符
        lock_val "1" /sys/devices/platform/cpu_power_throttling/boot_notify
        lock_val "1" /sys/devices/platform/gpu_power_throttling/boot_notify
        lock_val "1" /sys/devices/platform/cpu-power-throttling/boot_notify
        lock_val "1" /sys/devices/platform/gpu-power-throttling/boot_notify
    
        #②电流过流节流
        lock_val "Utest 0" /proc/mtk_batoc_throttling/battery_oc_protect_ut
        lock_val "stop 1"  /proc/mtk_batoc_throttling/battery_oc_protect_stop
    
        #③电池电量百分比节流调试
        lock_val "0" /sys/kernel/debug/bp_thl/bp_thl_ut
    
        #④电池低电量节流
        # 已知：MT6895: 下杠 / MT6993: 连字符
        lock_val "Utest 0" /sys/devices/platform/low_battery_throttling/low_battery_protect_ut
        lock_val "stop 1"  /sys/devices/platform/low_battery_throttling/low_battery_protect_stop
        lock_val "Utest 0" /sys/devices/platform/low-battery-throttling/low_battery_protect_ut
        lock_val "stop 1"  /sys/devices/platform/low-battery-throttling/low_battery_protect_stop
    
        #⑤电池电量百分比节流
        lock_val "Utest 0" /sys/devices/platform/bp_thl/bp_thl_ut
        lock_val "stop 1"  /sys/devices/platform/bp_thl/bp_thl_stop
    
        #⑥CPU频率与GPU频率彼此限制
        lock_val "2" /sys/class/cg_ppt/cg_ppt/mode
    }

    sched_ctl(){
        lock_val "-1" "/sys/devices/system/cpu/sched_ctl/fake_cpuinfo_max_freq_cpu"
    }

    cpu_loading(){
        lock_val "0" "/proc/cpu_loading/onoff"
    }

    touch_boost(){
        lock_val "0" /proc/touch_boost/enable
        lock_val "0" /proc/touch_boost/tb_enable
        stop touch_boost
    }
    
    mtk_lpm(){
        lock_val "1" /proc/mtk_lpm/cpuidle/enable
        lock_val "1" /proc/mtk_lpm/cpuidle/cpu_ret_en
        lock_val "0" /proc/mtk_lpm/cpuidle/cpu_pf_en
    }
    
    jank_detection(){
        lock_val "0x18" "/sys/kernel/jank_detection/jank_detection"
    }

    hps(){
        lock_val "0" "/proc/hps/enabled"
    }

    SBE(){
        local Dir1="/sys/module/mtk_sbe/parameters"
        local Dir2="/sys/module/sbe/parameters"
        local DirFin=""
        for i in "$Dir1" "$Dir2"
        do
            [ -e "$i" ] && DirFin="$i"
        done
        [ -z "$DirFin" ] && {
            echo "『SBE』未找到参数目录，不做处理"
            return 0
        }

        lock_val "0" "$DirFin"
        mask_val "255" "$DirFin/sbe_affinity_task"
    }

    task_turbo(){
        local Dir1="/sys/module/task_turbo/parameters"
        local Dir2="/sys/module/vip_engine/parameters"


        lock_val "0" "$Dir1"
        lock_val "0" "$Dir2"
    }
    
    mtk_scheduler(){
        mask_val "0" "/proc/mtk_scheduler/control_idle_util_enable"
    }
    
    #——————————————————————#
    
    ALL(){
        cpufreq_Lite_V1_V2
        perfmgr
        powerhal_cpu_ctrl
        mtk_game
        Thermal
        FRS
        pelt_hint
        power_throttling_related
        sched_ctl
        cpu_loading
        touch_boost
        mtk_lpm
        jank_detection
        hps
        SBE
        task_turbo
        mtk_scheduler
    }
    ALL
}

#————————————————————————————————————————


if [ "$(getprop ro.hardware)" != "qcom" ]
then
    echo -e "\n■ 联发科平台，执行联发科特别屏蔽\n"

    echo "<——［ConfigDisposer］——————————————>"
    ConfigDisposer
    echo "<——［FPSGO］——————————————>"
    FPSGO
    echo "<——［MAGT］——————————————>"
    MAGT
    echo "<——［MTK_CoreCtl］——————————————>"
    MTK_CoreCtl
    echo "<——［GPU］——————————————>"
    GPU
    echo "<——［MiscLimiters］——————————————>"
    MiscLimiters

    echo "<——————————————————>"
else
    echo "□ 非联发科平台，不执行联发科特别屏蔽"
fi


#————————————————————————————————————————





