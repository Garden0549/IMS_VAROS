

LB_MARGIN_StaticMargin=10
LB_MARGIN_DynEnable=1
LB_MARGIN_DynUsePipeTime=0
LB_MARGIN_DynPerfMode=1
LB_MARGIN_DynFixTargetFPS30=0
LB_MARGIN_DynMinMargin=5
LB_MARGIN_DynStepSize=5


LB_MARGIN_FinValue=$((LB_MARGIN_StaticMargin))
LB_MARGIN_FinValue=$((LB_MARGIN_FinValue | (LB_MARGIN_DynEnable << 8)))
LB_MARGIN_FinValue=$((LB_MARGIN_FinValue | (LB_MARGIN_DynUsePipeTime << 9)))
LB_MARGIN_FinValue=$((LB_MARGIN_FinValue | (LB_MARGIN_DynPerfMode << 10)))
LB_MARGIN_FinValue=$((LB_MARGIN_FinValue | (LB_MARGIN_DynFixTargetFPS30 << 11)))
LB_MARGIN_FinValue=$((LB_MARGIN_FinValue | (LB_MARGIN_DynMinMargin << 16)))
LB_MARGIN_FinValue=$((LB_MARGIN_FinValue | (LB_MARGIN_DynStepSize << 24)))

echo "LB_MARGIN_FinValue：$LB_MARGIN_FinValue"