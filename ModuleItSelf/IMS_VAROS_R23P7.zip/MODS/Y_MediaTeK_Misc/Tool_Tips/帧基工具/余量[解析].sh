#!/bin/sh

FB_MARGIN_FinValue=329234

# 提取原始 FB_MARGIN 值（低10位）
FB_MARGIN=$(( FB_MARGIN_FinValue & 0x3FF ))

# 提取 FB_MARGIN_MinStep 值（位10-15）
FB_MARGIN_MinStep=$(( (FB_MARGIN_FinValue >> 10) & 0x3F ))

# 提取 FB_MARGIN_MinMargin 值（位16及以上）
FB_MARGIN_MinMargin=$(( FB_MARGIN_FinValue >> 16 ))

# 打印解析结果
echo "原始 FB_MARGIN: $FB_MARGIN"
echo "FB_MARGIN_MinStep: $FB_MARGIN_MinStep"
echo "FB_MARGIN_MinMargin: $FB_MARGIN_MinMargin"