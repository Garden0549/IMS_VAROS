set_perm_recursive $MODPATH 0 0 0755 0644
set_perm "$MODPATH/Bin/*" 0 0 0755


[ -d /data/adb/modules/IMS ] && abort "请先卸载旧版模块"

run_customize(){
    echo -e "\n\n【————LOG_STARTS_HERE————】\n\n"
    echo "####################################"
    echo
    echo "  设备厂商：$(getprop 'ro.product.brand')"
    echo "  设备代号：$(getprop 'ro.product.model')"
    echo "  搭载平台：$(getprop 'ro.board.platform')"
    echo "  设备 ABI：$(getprop 'ro.product.cpu.abi')"
    echo "  安卓版本：$(getprop 'ro.system.build.version.release')"
    echo "   版本号 ：$(getprop 'ro.build.display.id')"
    echo
    echo "  当前用户：$(am get-current-user)"
    echo "  用户列表：$(pm list users)"
    echo
    echo "####################################"
    echo -e "\n\n"
    local count=0
    for i in $(find $MODPATH/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
        let count+=1
        echo "【$count】子模块名称：$(cat $i/A_Introduction)"
        echo "（子模块文件夹：${i##*/}）"
            if [ -f "$i/customize.sh" ]; then
              echo "###############——————###############"
              echo "[ $(date +"%Y-%m-%d %H:%M:%S") ]"
              sh $i/customize.sh
              echo "###############——————###############"
            fi
            if [ -f "$i/system.prop" ]; then
              echo "#『${i##*/}/system.prop』#" >> "$MODPATH/system.prop"
              cat "$i/system.prop" >> "$MODPATH/system.prop"
              echo -e "\n#——————————————————————————#\n" >> "$MODPATH/system.prop"
            fi
        echo -e "\n\n"
    done
    echo -e "\n\n【————LOG_ENDS_HERE————】\n\n"
}


mkdir -p $MODPATH/LOG;rm -f $MODPATH/LOG/LOG_customize.txt
run_customize 2>&1 | tee -a $MODPATH/LOG/LOG_customize.txt


echo -e "\n\n"
echo "⭕［注意］———［注意］———［注意］⭕"
echo "［模块额外功能］"
echo "> 在模块目录的文件［/MODS/ConfigTable.cfg］里，可以自定义处理一些官调"
echo "> 在模块目录的子目录［/Assistance/］里有如下文件："
echo "   -  更新日志.md"
echo "   -  模块介绍.md"
echo "> 安装模块后，在模块目录里的子目录［/LOG/］里，可以找到模块运行时记录的日志"
echo "> 本模块具有内含多个功能的附加程序，可以在ROOT管理器的模块列表里找到"
echo "  ［注意：］"
echo "  ［    由于模块默认配置足够屏蔽官方调度，所以：］"
echo "  ［    若非为了调试，不用在意上述内容，以避免无谓的疑问或焦虑］"
echo
echo
echo "［其它注意事项］"
echo "> ①模块在开机2分钟后完成启动"
echo "> ②模块无法完全屏蔽所有官调，但能助力第三方调度发挥"
echo "> ③卸载模块，即可复原模块除清空应用数据以外的所有改动"
echo "> ④如果已将游戏加入［游戏助手］，游戏内［游戏助手侧边栏］不出现，其核心原理是："
echo "  【［游戏助手侧边栏］依赖［应用增强服务］，后者无法启动时前者亦无法启动】"
echo "  请尝试："
echo "  ①开启安卓系统的'APP数据隔离'： "
echo "    - 安装应用［隐藏应用列表］并授予其ROOT权限"
echo "    - 打开其内'App data 隔离'这个开关"
echo "    - 最后，重启设备"
echo "  【说明】若安卓系统的'APP数据隔离'关闭，可能会导致［应用增强服务］无法读写其数据目录而崩溃并终止，无法启动"
echo "  ②在LSPosed中，关闭Thanox，重启设备"
echo "  【说明】Thanox内部的某个功能可能阻止了［应用增强服务］启动"
echo "  ③卸载再安装［应用增强服务］"
echo "  【说明】确保［应用增强服务］已安装且已启用"
echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n"









