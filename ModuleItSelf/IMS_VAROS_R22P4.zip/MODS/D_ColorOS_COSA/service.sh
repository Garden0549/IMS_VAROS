CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



DealComponents(){
    DEnable "d" "com.oplus.cosa/.gpalibrary.service.GPAService" > /dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.gamemanagersdk.HyperBoostService" > /dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.gamemanagersdk.CosaHyperBoostService" > /dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.oiface.OifaceService" > /dev/null 2>&1
    echo "已关闭应用增强服务组件：俩Hyper GPA OiFace(如果有)"
}
Cleaning(){
    COSA_Database=/data/data/com.oplus.cosa/databases/db_game_database
    sqlite3=$ROOTMODDIR/Bin/sqlite3
    ReceiverCOSA=com.oplus.cosa/androidx.work.impl.background.systemalarm.RescheduleReceiver
    ReceiverGames=com.oplus.games/androidx.work.impl.background.systemalarm.RescheduleReceiver
    ReceiverIntent=android.intent.action.BOOT_COMPLETED

    #启动[应用增强服务]与[游戏助手(若已启用)]并等待其运行15秒以确保数据库正常创建
    DEnable "e" "$ReceiverCOSA" > /dev/null 2>&1
    am broadcast -a $ReceiverIntent -n $ReceiverCOSA > /dev/null 2>&1
    sleep 1
    if ps -A | grep "com.oplus.cosa" > /dev/null 2>&1; then
        echo "成功启动[应用增强服务]"
    else
        echo "未能启动[应用增强服务]，停止处理"
        return 1
    fi
    if $(AppStateChecker "e" "com.oplus.games"); then
        DEnable "e" "$ReceiverGames" > /dev/null 2>&1
        am broadcast -a $ReceiverIntent -n $ReceiverGames > /dev/null 2>&1
        sleep 1
        if ps -A | grep "com.oplus.games" > /dev/null 2>&1; then
            echo "成功启动[游戏助手]"
        else
            echo "未能启动[游戏助手]"
        fi
    fi
    echo "等待[应用增强服务]数据库构建中";sleep 15
    
    echo
    
   #检测数据库是否已创建
    if [ -f $COSA_Database ]; then
        echo "[应用增强服务]应用性能调度配置所在数据库存在，尝试删除[应用性能调度配置表]"
    else
        echo "[应用增强服务]应用性能调度配置所在数据库不存在，停止处理"
        return 1
    fi
    
    echo
    
    #杀死[应用增强服务]和[游戏助手]，关闭数据库保护，删除[应用增强服务]数据库中的[应用性能调度配置表]
    am force-stop com.oplus.games
    am force-stop com.oplus.cosa
    $sqlite3 "$COSA_Database" "DROP TABLE IF EXISTS PackageConfigBean;"
    
    #重启动[应用增强服务]和[游戏助手(若已启用)]以避免未知异常
    am broadcast -a $ReceiverIntent -n $ReceiverCOSA > /dev/null 2>&1
    sleep 1
    if ps -A | grep "com.oplus.cosa" > /dev/null 2>&1; then
        echo "成功复启动[应用增强服务]"
    else
        echo "未能复启动[应用增强服务]"
    fi
    if $(AppStateChecker "e" "com.oplus.games"); then
        am broadcast -a $ReceiverIntent -n $ReceiverGames > /dev/null 2>&1
        sleep 1
        if ps -A | grep "com.oplus.games" > /dev/null 2>&1; then
            echo "成功复启动[游戏助手]"
        else
            echo "未能复启动[游戏助手]"
        fi
    fi
    
    echo
    
    #检查[应用性能调度配置表]是否已删除
    if $sqlite3 "$COSA_Database" "SELECT 1 FROM sqlite_master WHERE name='PackageConfigBean';" | grep -q "1"; then
        echo "[应用性能调度配置表]未能删除"
    else
        echo "[应用性能调度配置表]已删除"
    fi
}


if [ -f $CURMODDIR/ClearCOSA ]; then
    pm clear "com.oplus.cosa" > /dev/null 2>&1 && echo "为避免可能的异常，已为当前用户清空'com.oplus.cosa'的数据"
    rm -f $CURMODDIR/ClearCOSA
fi

for i in com.oplus.cosa com.oplus.games
do
    if $(AppStateChecker "n" "$i"); then
        DEnable "e" "$i"
        echo "为避免可能的异常，已为当前用户矫正'$i'的启用状态"
    fi
done

if $(AppStateChecker "e" "com.oplus.cosa"); then
    echo "[应用增强服务]已安装且已启用，开始处理"
    echo "<——————————>"
    DealComponents
    echo "<——————————>"
    Cleaning
    echo "<——————————>"
else
    echo "[应用增强服务]未安装或未启用，不做处理"
fi







