#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh


ORMS_CONFIG_SIMPLIFICATION(){
Tool=$MODDIR_ROOT/Bin/ORMEncryption
mkdir $MODDIR/TEMP
mkdir $MODDIR/File
FILE_ORI=/odm/etc/orms/orms_core_config.xml
FILE_DE=$MODDIR/TEMP/Decoded.xml
FILE_TEMP1=$MODDIR/TEMP/TEMP1
FILE_TEMP2=$MODDIR/TEMP/TEMP2
FILE_EN=$MODDIR/File/orms_core_config.xml

umount $FILE_ORI > /dev/null 2>&1

#ORMEncryption encrypt/decrypt -i <input-file-path> -o <output-file-path>
# 1.解码
$Tool decrypt -i $FILE_ORI -o $FILE_DE > /dev/null 2>&1
# 2.提取
sed -n '/<filter-conf>/,/<\/filter-conf>/p' "$FILE_DE" > "$FILE_TEMP1"
Temp=$(cat $FILE_TEMP1)
# 3.融合提取
echo "<?xml version="1.0" encoding="utf-8"?>
<resources>
$Temp
</resources>" > $FILE_TEMP2
# 4.加密
$Tool encrypt -i $FILE_TEMP2 -o $FILE_EN > /dev/null 2>&1
rm -rf $MODDIR/TEMP
}

if [ -f /odm/etc/orms/orms_core_config.xml ]; then
    ORMS_CONFIG_SIMPLIFICATION && echo "成功复制、简化并保存Orms配置"
else
    echo "Orms配置不存在"
fi







