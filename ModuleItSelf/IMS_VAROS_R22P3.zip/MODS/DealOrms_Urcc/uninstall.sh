#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh

#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){

    rm -f /data/system/orms/*
    rm -rf /data/vendor/uah/ /data/vendor/urcc

}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){



}

#————————————————————————————————————————

AtPost
{
    wait_until_login;sleep 60
    AtService
} &











