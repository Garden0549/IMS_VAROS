#本子模块目录地址
MODDIR=${0%/*}
#模块根目录地址
MODDIR_ROOT=${0%/*/*/*}
#引用公共函数文件以便使用其内函数
source ${0%/*/*}/PublicFuncs.sh
#配置表(仅引用该表的脚本有)
source ${0%/*/*}/Scheduler.cfg


Singlemount -u /system_ext/etc/oiface/oiface.config > /dev/null 2>&1 && echo "已卸载已挂载的oiface配置"
if Singlemount -m $MODDIR/File/oiface.config /system_ext/etc/oiface/oiface.config > /dev/null 2>&1; then
    echo "已等效替换oiface配置"
else
    echo "未能成功替换oiface配置"
fi


OifaceProp=persist.sys.oiface.enable
if [ $Oiface_Prop != DEFAULT ]
then
    resetprop -n $OifaceProp $Oiface_Prop && echo "已尝试修改'$OifaceProp'的值为'$Oiface_Prop'。现为：$(getprop $OifaceProp)"
else
    echo "不修改'$OifaceProp'的值"
fi

