CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



SchedAssist=/proc/oplus_scheduler/sched_assist/sched_assist_enabled
CpufreqBouncing=/sys/module/cpufreq_bouncing/parameters/enable
CpufreqEffiency=/sys/module/cpufreq_effiency/parameters/affect_mode
OplusMultipleRailGroup=/sys/devices/platform/soc/soc:oplus-omrg/oplus-omrg0/ruler_enable
TaskSchedInfo_Proc=/proc/task_info/task_sched_info/task_sched_info_enable
TaskSchedInfo_Sys=/sys/module/oplus_bsp_task_sched/parameters/sched_info_ctrl
TaskCPUstats=/proc/task_info/task_cpustats/task_cpustats_enable
TaskOverload=/proc/task_overload/skip_goplus_enabled
TaskLoadInfo=/proc/task_info/task_load_info/monitor_status
for i in SchedAssist CpufreqBouncing CpufreqEffiency OplusMultipleRailGroup TaskSchedInfo_Proc TaskSchedInfo_Sys TaskCPUstats TaskOverload TaskLoadInfo
do
    eval File=\$$i
    eval FileSwitch=\$${i}_Disable
    if [ -f $File ]
        then
            if [ $FileSwitch = 1 ]
            then
                mask_val 0 "$File"
                echo "已关闭：'$i'"
            else
                echo "未修改：'$i'——'$File'"
            fi
        else
            echo "不存在而未处理：'$i'——'$File'"
        fi
done

echo "====================================="

Hmbird_Dir1="/proc/hmbird_sched"
Hmbird_Dir2="/proc/oplus_hmbird"
if [ -e "$Hmbird_Dir1" ]; then
    lock_val "0" $Hmbird_Dir1/scx_enable
    lock_val "0" $Hmbird_Dir1/partial_ctrl
    lock_val "0" $Hmbird_Dir1/isolate_ctrl
    lock_val "0" $Hmbird_Dir1/slim_for_app
    lock_val "0" $Hmbird_Dir1/slim_walt/slim_walt_ctrl
    lock_val "0" $Hmbird_Dir1/slim_walt/slim_walt_dump
    lock_val "0" $Hmbird_Dir1/slim_walt/slim_walt_policy
    lock_val "0" $Hmbird_Dir1/slim_freq_gov/scx_gov_ctrl
    lock_val "0" $Hmbird_Dir1/slim_freq_gov/slim_gov_debug
    lock_val "0" $Hmbird_Dir1/heartbeat_enable
    lock_val "0" $Hmbird_Dir1/watchdog_enable
    lock_val "0" $Hmbird_Dir1/hmbirdcore_debug
    echo "已尝试关闭风驰调度内核模块功能"
elif [ -e "$Hmbird_Dir2" ]; then
    lock_val "-1" $Hmbird_Dir2/manager_pid
    lock_val "-1" $Hmbird_Dir2/gpa_pid
    lock_val "stop" $Hmbird_Dir2/manager_hb_feed
    stop oplusHmbirdBpfManager && echo "已关闭风驰BPF管理器"
    echo "已尝试关闭风驰调度内核模块功能"
else
    echo "本设备没有风驰调度内核模块，不做处理"
fi

echo "====================================="













