MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){
    
    #避免空函数异常
    echo OKAY
    
    #运行所有子模块的uninstall卸载脚本
    #在post-fs-data阶段执行的代码，立刻执行
    #在service阶段执行的代码，各子卸载脚本各并行延迟到进入桌面后执行
    run_uninstall(){
        for i in $(find ${0%/*}/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
            sh $i/uninstall.sh
        done
    }
    run_uninstall
    CACHE_Remover


}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){

    #避免空函数异常
    echo OKAY


}

#————————————————————————————————————————

AtPost
{
    wait_until_login;sleep 30
    AtService
} &