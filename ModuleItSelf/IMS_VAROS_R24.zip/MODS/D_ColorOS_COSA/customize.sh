CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



echo "- ①安装模块时，如果已安装且已启用[应用增强服务]，"
echo "-   将清空其数据，以避免可能的异常"
echo "- ②卸载模块时，如果已安装[应用增强服务]，"
echo "-   将清空其数据，以尝试确保[应用性能调度配置表]能够恢复"

echo

echo -e "\n⭕————开始处理[应用增强服务]，需要大约30秒，请等待\n"
touch $CURMODDIR/ClearCOSA
sh $CURMODDIR/service.sh 2>&1
echo -e "\n⭕————处理结束\n"






