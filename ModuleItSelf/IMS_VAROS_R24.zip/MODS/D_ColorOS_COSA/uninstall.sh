CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】

#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){

    #避免空函数异常
    echo OKAY

}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){

    echo "【阶段零】检测[应用增强服务]是否已安装"
    if $(AppStateChecker "i" "com.oplus.cosa")
    then
        echo "[应用增强服务]已安装，开始处理"
    else
        echo "[应用增强服务]未安装，不做处理"
        return 1
    fi

    echo

    echo "【阶段一】启用[应用增强服务]中被模块禁用的组件"
    DEnable "e" "com.oplus.cosa/.gpalibrary.service.GPAService" >/dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.HyperBoostService" >/dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.CosaHyperBoostService" >/dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.oiface.OifaceService" >/dev/null 2>&1
    echo "已确保开启会被模块关闭的[应用增强服务]组件：俩Hyper GPA OiFace(如果有)"
    
    echo
    
    echo "【阶段二】清空[应用增强服务]以恢复[应用性能调度配置]"
    pm clear "com.oplus.cosa" >/dev/null && \
    echo "✔️ 已成功清空[应用增强服务]数据，以尝试恢复其[应用性能调度配置]"
    
    echo
    
    echo "【阶段三】矫正[应用增强服务]和[游戏助手]的启用状态，并尝试启动[应用增强服务]"
    for i in com.oplus.cosa com.oplus.games
    do
        if $(AppStateChecker "n" "$i"); then
            DEnable "e" "$i" >/dev/null && \
            echo "已为当前用户矫正'$i'的启用状态"
        fi
    done
    echo "矫正检测结束，尝试启动[应用增强服务]"
    if $(AppStateChecker "d" "com.oplus.cosa"); then
        echo "[应用增强服务]已禁用，不尝试启动"
    else
        COSAService=com.oplus.cosa/com.oplus.cosa.service.COSAService
        am startservice -n "$COSAService"
        sleep 3
        if ! pidof "com.oplus.cosa" >/dev/null; then
            echo "× 未能启动[应用增强服务]"
        else
            echo "✔️ 成功启动[应用增强服务]"
        fi
    fi
    
}

#————————————————————————————————————————


AtPost
{
    wait_until_login;sleep 30
    AtService
} &











