CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



PowerHAL(){
    Conf_Empty(){
        echo "===============［挂载PowerHAL配置］==============="
        if [ $PowerHAL_Conf_AppCfg_Empty = 1 ]
        then
            echo "［power_app_cfg(应用配置)］"
            echo "〔尝试卸载已挂载配置〕"
            BatchMount -u "$CURMODDIR/Conf_AppCfg"
            echo
            echo "〔尝试挂载配置〕"
            BatchMount -m "$CURMODDIR/Conf_AppCfg"
        else
            echo "『PowerHAL』不清空［power_app_cfg(应用配置)］"
        fi
        echo "==============="
        if [ $PowerHAL_Conf_Scntbl_Empty = 1 ]
        then
            echo "［powerscntbl(系统场景配置)］"
            echo "〔尝试卸载已挂载配置〕"
            BatchMount -u "$CURMODDIR/Conf_Scntbl"
            echo
            echo "〔尝试挂载配置〕"
            BatchMount -m "$CURMODDIR/Conf_Scntbl"
        else
            echo "『PowerHAL』不清空［powerscntbl(系统场景配置)］"
        fi
        echo "==============="
        if [ $PowerHAL_Conf_Contbl_Empty = 1 ]
        then
            echo "［powercontable(参数表)］"
            echo "〔尝试卸载已挂载配置〕"
            BatchMount -u "$CURMODDIR/Conf_Contbl"
            echo
            echo "〔尝试挂载配置〕"
            BatchMount -m "$CURMODDIR/Conf_Contbl"
        else
            echo "『PowerHAL』不清空［powercontable(参数表)］"
        fi      
        echo "===============［挂载PowerHAL配置］==============="
    }

    if [ $PowerHAL_Conf_AppCfg_Empty = 1 ] || [ $PowerHAL_Conf_Contbl_Empty = 1 ] || [ $PowerHAL_Conf_Scntbl_Empty = 1 ]
    then
        Conf_Empty
        echo "『PowerHAL』已尝试等效清空PowerHAL配置"
    else
        echo "『PowerHAL』没有需要清空的PowerHAL配置"
    fi
}

MAGT(){
    Disable_Process(){
        resetprop -p ro.vendor.magt.mtk_magt_support "$1"
    }
    
    if [ $MAGT_Disable = 1 ]; then
        Disable_Process "0" && \
        echo "『MAGT』已尝试通过修改系统属性［关闭］MAGT"
    else
        Disable_Process "1" && \
        echo "『MAGT』已尝试通过修改系统属性［开启］MAGT"
    fi
}


if [ "$(getprop ro.hardware)" != "qcom" ]
then
    echo -e "\n■ 联发科平台，执行联发科特别屏蔽\n"
    echo "<——————————————————>"
    PowerHAL
    echo "<——————————————————>"
    MAGT
    echo "<——————————————————>"
else
    echo "□ 非联发科平台，不执行联发科特别屏蔽"
fi




