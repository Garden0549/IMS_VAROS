CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】


#——————————————————————————#

FileDir="$CURMODDIR/File"
OriginOrmsConf="/odm/etc/orms/orms_core_config.xml"
EditedOrmsConf="$FileDir/orms_core_config.xml"
CustomOrmsConfDir="/data/system/orms"

UrccConf="/odm/etc/uah/uahconfig.pb"
UrccCache="/data/vendor/uah/ /data/vendor/urcc/"

#——————————————————————————#

if [ -e "$OriginOrmsConf" ]
then
    echo "————［■ Orms配置存在］————"
    echo "开始处理："
    
    Singlemount -u "$OriginOrmsConf" >/dev/null && \
    echo "✔️ 已卸载被挂载的Orms配置"
    
    if Singlemount -m "$EditedOrmsConf" "$OriginOrmsConf" >/dev/null
    then
        echo "✔️ 成功等效替换Orms配置"
    else
        echo "⭕ 未能成功挂载Orms配置"
    fi
    
    if [ -e "$CustomOrmsConfDir" ]; then
        cp -f "$EditedOrmsConf" "$CustomOrmsConfDir" && {
            echo "✔️ 已将处理后的配置复制到自定义Orms配置目录"
        }
    else
        echo "□ 未找到自定义Orms配置目录，不做处理"
    fi
    
    echo "———————————————————————————"
else
    echo "————［□ Orms配置不存在］————"
    echo "不做处理。"
    
    echo "———————————————————————————"
fi


if [ -e "$UrccConf" ]
then
    echo "————［■ Urcc配置存在］————"
    echo "开始处理："
    
    for i in $UrccCache
    do
        rm -r "$i" && \
        echo "✔️ 已清空Urcc缓存：'$i'"
    done
    
    if Empty_mask "$UrccConf" >/dev/null
    then
        echo "✔️ 成功等效清空Urcc配置"
    else
        echo "⭕ 未能成功挂载Urcc配置"
    fi
    
    echo "———————————————————————————"
else
    echo "————［□ Urcc配置不存在］————"
    echo "不做处理。"
    
    echo "———————————————————————————"
fi
#——————————————————————————#


