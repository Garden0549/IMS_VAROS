MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



run_service(){
    echo -e "\n\n"
    echo "【————————LOG_STARTS_HERE————————】"
    echo "【————————LOG_STARTS_HERE————————】"
    echo "【————————LOG_STARTS_HERE————————】"
    echo -e "\n\n\n\n\n"
    
    for i in $(find $MODDIR/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
        if [ -f "$i/service.sh" ]; then
            echo "【 $i： 】"
            echo "###########———［ $(date +"%Y-%m-%d %H:%M:%S") ］———###########"
            sh "$i/service.sh"
            echo "###########———［ $(date +"%Y-%m-%d %H:%M:%S") ］———###########"
            echo -e "\n\n"
        fi
    done

    echo -e "\n\n\n\n\n"
    echo "【————————LOG_ENDS_HERE————————】"
    echo "【————————LOG_ENDS_HERE————————】"
    echo "【————————LOG_ENDS_HERE————————】"
    echo -e "\n\n\n\n\n"
}


wait_until_login;sleep 30

mkdir -p $MODDIR/LOG;rm -f $MODDIR/LOG/LOG_service.txt
run_service 2>&1 | tee -a $MODDIR/LOG/LOG_service.txt






