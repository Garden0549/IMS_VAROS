MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){
    
    run_uninstall(){
        for i in $(find $MODDIR/MODS/ -type d -mindepth 1 -maxdepth 1 | sort); do
            sh $i/uninstall.sh
        done
    }
    run_uninstall


}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){

    #避免空函数异常
    echo OKAY


}

#————————————————————————————————————————

AtPost
{
    wait_until_login;sleep 30
    AtService
} &