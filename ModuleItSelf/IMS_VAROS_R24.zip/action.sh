MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



Main_DealHorae(){
    local Title="①尝试［开启/关闭］Horae进程"
    local Choose_UP="开启"
    local Choose_DOWN="关闭"
    local TimeLimit=""
    
    local HoraeProp=persist.sys.horae.enable
    HoraeChecker(){
        echo "  〔Horae当前状态〕"
        echo "   Horae属性'$HoraeProp'当前值：$(getprop $HoraeProp)"
        if pidof horae > /dev/null 2>&1; then
            echo "   Horae进程已启动，进程PID为'$(pidof horae)'"
        else
            echo "   Horae进程未启动"
        fi
    }
    
    DealHorae(){
        echo "⭕［说明］⭕"
        echo "【1】开启Horae进程的影响："
        echo "      ①去锁帧模块的去锁帧功能失效"
        echo "      ②游戏内温控锁帧严苛"
        echo "【2】关闭Horae进程的可能影响："
        echo "      ①相机对焦或录像帧率异常"
        echo "【3】该功能所做修改，重启失效"
        echo
        HoraeChecker
        echo
        echo "⭕［二次确认］⭕"
        echo "   『$Title』"
        echo "    > [音量 ↑ 键]——[$Choose_UP]"
        echo "    > [音量 ↓ 键]——[$Choose_DOWN]"
        echo "    （若关闭Horae进程无异常，不建议将其开启）"
    
        CASE_DealHorae(){
            if [ -z "$key_click" ]; then
                echo -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    resetprop -n $HoraeProp 1 > /dev/null 2>&1
                    sleep 1
                    start horae > /dev/null 2>&1
                    HoraeChecker
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    resetprop -n $HoraeProp 0 > /dev/null 2>&1
                    sleep 1
                    stop horae > /dev/null 2>&1
                    HoraeChecker
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_DealHorae
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_DealHorae
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_DealHorae" \
                 "跳过" "echo '你选择了[跳过]'"
    else
        DealHorae
    fi
}



Main_GamesCOSA_Uninstallation(){
    local Title="②彻底卸载［应用增强服务］和［游戏助手］"
    
    Uninstallation(){
        for i in com.oplus.games com.oplus.cosa
        do
            echo "卸载'$i'："
            echo $(UInstall "u" "$(am get-current-user)" "$i")
            echo "再次卸载'$i'以确保彻底卸载："
            echo $(UInstall "u" "$(am get-current-user)" "$i")
            echo
        done
    }
    
    GamesCOSA_Uninstallation(){
        local Choose_UP="卸载"
        local Choose_DOWN="不卸载"
        local TimeLimit=""
    
        echo "⭕［说明］⭕"
        echo "【1】如果卸载，可更彻底地去除官方调度，但也会失去［游戏助手］的所有功能"
        echo
        echo "⭕［二次确认］⭕"
        echo "   『$Title』"
        echo "    > [音量 ↑ 键]——[$Choose_UP]"
        echo "    > [音量 ↓ 键]——[$Choose_DOWN]"
    
        CASE_GamesCOSA_Uninstallation(){
            if [ -z "$key_click" ]; then
                echo -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    Uninstallation
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_GamesCOSA_Uninstallation
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_GamesCOSA_Uninstallation
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_GamesCOSA_Uninstallation" \
                 "跳过" "echo '你选择了[跳过]'"
    else
        GamesCOSA_Uninstallation
    fi
}



Main_GamesCOSA_Reinstallation(){
    local Title="③彻底卸载再安装系统自带版本的［游戏助手］与［应用增强服务］"
    
    Reinstallation(){
        COSA_Dir1="/product/app/COSA/COSA.apk"
        COSA_DirFin=""
        OplusGames_Dir1="/my_stock/del-app/OplusGames/OplusGames.apk"
        OplusGames_Dir2="/my_heytap/del-app/OplusGames/OplusGames.apk"
        OplusGames_Dir3="/product/priv-app/OplusGames/OplusGames.apk"
        OplusGames_DirFin=""
        for i in "$COSA_Dir1"
        do
            if [ -e "$i" ]; then
                COSA_DirFin="$i"
            fi    
        done
        for i in "$OplusGames_Dir1" "$OplusGames_Dir2" "$OplusGames_Dir3"
        do
            if [ -e "$i" ]; then
                OplusGames_DirFin="$i"
            fi    
        done
        if [ -z "$COSA_DirFin" ] || [ -z "$OplusGames_DirFin" ]; then
            echo "   功能中止，因为找不到［游戏助手］或［应用增强服务］的安装包"
            return 1
        else
            for i in "$OplusGames_DirFin" "$COSA_DirFin"
            do
                if FindMount "$i" > /dev/null 2>&1; then
                    echo "   功能中止，因为下述安装包被破坏："
                    echo "     $i"
                    echo "   如果想要继续恢复，请检查此路径指向的模块并关闭之："
                    echo "     $(FindMount "$i")"
                    return 1
                fi
            done
        fi
                
        echo "正在重新安装［应用增强服务］和［游戏助手］"
        
        echo
        
        for i in com.oplus.games com.oplus.cosa
        do
            echo "卸载'$i'："
            echo $(UInstall "u" "$(am get-current-user)" "$i")
            echo "再次卸载'$i'以确保彻底卸载："
            echo $(UInstall "u" "$(am get-current-user)" "$i")
            echo
        done

        echo
        
        UInstall "ie" "$(am get-current-user)" "com.oplus.cosa"
        if ! UInstall "ie" "$(am get-current-user)" "com.oplus.games" 2>/dev/null
        then
            echo -e "\n在本设备上［游戏助手］不是系统应用"
            echo "尝试使用安装包安装并启用之"
            UInstall "i" "$(am get-current-user)" "$OplusGames_DirFin"
            DEnable "e" "com.oplus.games"
        fi

        echo
        
        echo "> 重装结束。"
        echo "> 请通过模块附加程序启动［游戏助手］，并在里面启动游戏一次，观察［游戏助手侧边栏］是否出现"
        echo "> ④如果已将游戏加入［游戏助手］，游戏内［游戏助手侧边栏］不出现，其核心原理是："
        echo "  【［游戏助手侧边栏］依赖［应用增强服务］，后者无法启动时前者亦无法启动】"
        echo "  可尝试以下方法："
        echo "  ［1］开启安卓系统的'APP数据隔离'： "
        echo "    - 安装应用［隐藏应用列表］并授予其ROOT权限"
        echo "    - 打开其内'App data 隔离'这个开关"
        echo "    - 最后，重启设备"
        echo "  【原理】若安卓系统的'APP数据隔离'关闭，可能会导致［应用增强服务］无法读写其数据目录而崩溃并终止，无法启动"
        echo "  ［2］在LSPosed中，关闭Thanox，重启设备"
        echo "  【原理】Thanox的某个功能可能阻止了［应用增强服务］［游戏助手］在游戏里自启动"
        echo "  ［3］彻底关闭已安装的“墓碑”，重启设备"
        echo "  【原理】“墓碑”可能冻结而阻止了［应用增强服务］［游戏助手］在游戏里自启动"
        echo "  ［4］卸载再安装［应用增强服务］"
        echo "  【原理】确保［应用增强服务］已安装且已启用"
    }
    
    GamesCOSA_Reinstallation(){
        local Choose_UP="重新安装"
        local Choose_DOWN="不重新安装"
        local TimeLimit=""
    
        echo "⭕［说明］⭕"
        echo "【1】重新安装时，将卸载现已安装的并安装系统自带的［游戏助手］与［应用增强服务］"
        echo
        echo "⭕［二次确认］⭕"
        echo "   『$Title』"
        echo "    > [音量 ↑ 键]——[$Choose_UP]"
        echo "    > [音量 ↓ 键]——[$Choose_DOWN]"
    
        CASE_GamesCOSA_Reinstallation(){
            if [ -z "$key_click" ]; then
                echo -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    Reinstallation
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_GamesCOSA_Reinstallation
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_GamesCOSA_Reinstallation
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_GamesCOSA_Reinstallation" \
                 "跳过" "echo '你选择了[跳过]'"
    else
        GamesCOSA_Reinstallation
    fi
}



Main_GamesStart(){
    local Title="④便捷打开［游戏助手］页面"
    
    GamesStart(){
        if ! AppStateChecker e "com.oplus.games"; then
            echo "  发现［游戏助手］没有安装或启用，无法打开"
            return 1
        fi
        AppStateChecker e "com.oplus.cosa" || echo "注意：［应用增强服务］没有正常启用，这会导致进入游戏时［游戏助手］侧边栏依然不会自启动"
        echo "  5秒后启动游戏助手"
        echo "  -  为避免因模块附加程序未结束而极易触发的按键误触，"
        echo "  -  将在游戏助手打开后立即退出模块附加程序"
        sleep 5;am start -n com.oplus.games/business.module.desktop.JumpSpaceActivity;exit
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "打开" "Main_GamesStart" \
                 "不打开" "echo '你选择了[不打开]'"
    else
        GamesStart
    fi
}



#——————————————————————————————#



echo "——————————————————————————————"
echo "『模块附加程序，具有以下功能：』"
echo
for i in Main_DealHorae Main_GamesCOSA_Uninstallation Main_GamesCOSA_Reinstallation Main_GamesStart
do
    $i "Symbol"
done
echo
echo "————————————————————————————————————————"
echo "『如何操作附加程序：』"
echo
echo "  - 即将执行上述功能前，按下机身上的[非音量键]即可退出附加程序"
echo "  - 按下机身上的[音量 ↑ 键]或[音量 ↓ 键]以执行对应功能"
echo
echo "————————————————————————————————————————"
echo -e "\n\n\n"


echo ">—————————————↓↓↓—————————————<"
echo "  ⭕ 是否【直接退出附加程序】？"
echo "  [音量 ↑ 键]：退出  [音量 ↓ 键]：继续"
echo -e "  （5秒后选择超时，将自动退出附加程序）\n"
ConvenientExport(){
    if [ -z "$key_click" ]; then
        echo "  > 【选择超时，立即退出附加程序】"
        echo -e ">—————————————↑↑↑—————————————<"
        exit
    fi
    case "$key_click" in
        "KEY_VOLUMEUP")
            echo "  > 【你按下了[音量 ↑ 键]，确认[退出]】"
            echo -e ">—————————————↑↑↑—————————————<"
            exit
            ;;
        "KEY_VOLUMEDOWN")
            echo "  > 【你按下了[音量 ↓ 键]，确认[继续]】"
            echo -e ">—————————————↑↑↑—————————————<"
            ;;
        *)
            key_checker "$TimeLeft";ConvenientExport
            ;;
    esac
}
sleep 0.5
key_checker "5";ConvenientExport



echo -e "\n\n\n\n"
echo "［—————————————————————————————————————］"
echo -e "\n\n\n\n"



key_running_full
echo -e "\n\n\n\n\n\n"