#!/bin/sh


LB_STEP_FinValue=4

# 假设 LB_STEP_FinValue 已经设置
# LB_STEP_FinValue=$(( (LB_STEP_UltraLow << 8) | LB_STEP_UltraHigh ))

# 解析 LB_STEP_UltraLow (左移8位后的值)
LB_STEP_UltraLow=$(( LB_STEP_FinValue >> 8 ))

# 解析 LB_STEP_UltraHigh (低8位的值)
LB_STEP_UltraHigh=$(( LB_STEP_FinValue & 0xFF ))

# 输出结果
echo "LB_STEP_UltraLow: $LB_STEP_UltraLow"
echo "LB_STEP_UltraHigh: $LB_STEP_UltraHigh"