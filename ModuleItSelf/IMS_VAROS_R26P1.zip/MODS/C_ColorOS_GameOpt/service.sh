CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】

#——————————————————————————#

Dir="/proc/game_opt"

#——————————————————————————#

if [ -e "$Dir" ]
then
    mask_val "0" "$Dir/game_pid"
    mask_val "1" "$Dir/disable_cpufreq_limit"
    mask_val "0" "$Dir/early_detect/ed_enable"
    mask_val "0" "/proc/oplus_cpu_game/early_detect/ed_enable"
    mask_val "0" "$Dir/frame_load_track/flt_enable"
    mask_val "0" "$Dir/task_boost/ct_enable"
    mask_val "0" "$Dir/task_boost/htb_enable"
    mask_val "0" "$Dir/multi_task/multi_task_util_enable"
    
    mask_val "0" "$Dir/fake_cpu7_cpuinfo_max_freq"
    mask_val "0 120 10" "$Dir/yield_opt"
    mask_val "0" "$Dir/yield_pid"
    mask_val "0 0" "$Dir/lock_stealing"
    mask_val "0" "$Dir/rt_info"
    mask_val "0" "$Dir/ui_assist_thread"
    mask_val "0" "$Dir/multi_task/multi_task_pid"
    mask_val "0" "$Dir/debug_enable"
    mask_val "0" "$Dir/skip_gameself_setaffinity"
    mask_val "0" "$Dir/lpm_disable"
    mask_val "0 0 0" "$Dir/tt_user"
    mask_val "0:0 1:0 2:0 3:0 4:0 5:0 6:0 7:0" "$Dir/chtb_cpu_min_freq"
    mask_val "0:2147483647 1:2147483647 2:2147483647 3:2147483647 4:2147483647 5:2147483647 6:2147483647 7:2147483647" "$Dir/chtb_cpu_max_freq"
else
    echo "GameOpt配套内核模块疑似不存在，不做处理"
fi

#——————————————————————————#










