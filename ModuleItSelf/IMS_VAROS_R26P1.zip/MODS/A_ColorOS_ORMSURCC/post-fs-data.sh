CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】


#——————————————————————————#

FileDir="$CURMODDIR/File"


OriginORMSConf="/odm/etc/orms/orms_core_config.xml"
CustomORMSConf="$FileDir/orms_core_config.xml"
CustomORMSConfDir="/data/system/orms"

OriginUAHConf="/odm/etc/uah/uahconfig.pb"
CustomUAHConf="$FileDir/uahconfig.pb"
CustomUAHConfDir="/data/vendor/uah"

#——————————————————————————#

if [ -e "$OriginORMSConf" ]
then
    echo "————［■ ORMS配置存在］————"

    SingleMount -u "$OriginORMSConf" >/dev/null 2>&1 && \
    echo "✔️ 已卸载被挂载的ORMS配置"
    
    if SingleMount -m "$CustomORMSConf" "$OriginORMSConf" >/dev/null
    then
        echo "✔️ 成功等效替换ORMS配置"
    else
        echo "⭕ 未能成功挂载ORMS配置"
    fi
    
    for i in $CustomORMSConfDir
    do
        if [ -e "$i" ]; then
            rm -r "$i" && \
            echo "✔️ 已删除ORMS自定义配置目录：'$i'"
        fi
    done
    
    echo "———————————————————————————"
else
    echo "————［□ ORMS配置不存在］————"
    echo "略过。"
    
    echo "———————————————————————————"
fi



if [ -e "$OriginUAHConf" ]
then
    echo "————［■ UAH配置存在］————"
    
    SingleMount -u "$OriginUAHConf" >/dev/null 2>&1 && \
    echo "✔️ 已卸载被挂载的UAH配置"
    
    if SingleMount -m "$CustomUAHConf" "$OriginUAHConf" >/dev/null
    then
        echo "✔️ 成功等效替换UAH配置"
    else
        echo "⭕ 未能成功挂载UAH配置"
    fi
    
    for i in $CustomUAHConfDir
    do
        if [ -e "$i" ]; then
            rm -r "$i" && \
            echo "✔️ 已删除UAH自定义配置目录：'$i'"
        fi
    done
    
    echo "———————————————————————————"
else
    echo "————［□ UAH配置不存在］————"
    echo "略过。"
    
    echo "———————————————————————————"
fi












