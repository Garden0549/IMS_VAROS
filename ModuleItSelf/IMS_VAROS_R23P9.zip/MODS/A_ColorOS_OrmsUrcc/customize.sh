CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】


#——————————————————————————#

FileDir="$CURMODDIR/File"
Tool="$ROOTMODDIR/Bin/ORMEncryption"
OriginOrmsConf="/odm/etc/orms/orms_core_config.xml"
OrmsConfTemp="$FileDir/Temp.xml"
EditedOrmsConf="$FileDir/orms_core_config.xml"
CustomOrmsConfDir="/data/system/orms"
umount "$OriginOrmsConf" >/dev/null 2>&1
rm -rf "$FileDir";mkdir "$FileDir"

#——————————————————————————#

if [ -e "$OriginOrmsConf" ]
then
    echo "————［Orms配置存在，开始处理］————"

    "$Tool" decrypt -i "$OriginOrmsConf" -o "$OrmsConfTemp" >/dev/null || {
        echo "× 第1步：Orms解密出错，结束处理"
        exit
    }  
    #第2步：简化、关闭配置
    sed -i -n '/<filter-conf>/,/<\/filter-conf>/p' "$OrmsConfTemp"
    sed -i 's|<isOpen>true</isOpen>|<isOpen>false</isOpen>|g' "$OrmsConfTemp"
    echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>
<resources>
$(cat $OrmsConfTemp)
</resources>" > "$OrmsConfTemp"
    "$Tool" encrypt -i "$OrmsConfTemp" -o "$EditedOrmsConf" >/dev/null || {
        echo "× 第3步：Orms加密出错，结束处理"
        exit
    }
    #第4步：清理残留，给出提示
    rm -f "$OrmsConfTemp"
    echo "已复制Orms配置到模块目录并将其处理"

  
    if [ -e "$CustomOrmsConfDir" ]; then
        cp -f "$EditedOrmsConf" "$CustomOrmsConfDir" && {
            echo "已将处理后的配置复制到自定义Orms配置目录"
            echo "（为确保修改生效，每次开机仍将复制配置到此目录）"
        }
    else
        echo "未找到自定义Orms配置目录！可能受到误删，也可能系统不再创建此目录"
        echo "（为确保修改生效，每次开机将尝试复制配置到此目录）"
    fi
else
    echo "————［Orms配置不存在，不做处理］————"
fi



