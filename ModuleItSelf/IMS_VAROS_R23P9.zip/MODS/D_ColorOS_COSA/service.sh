CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



Rectifying(){
    if [ -f $CURMODDIR/ClearCOSA ]; then
        rm -f $CURMODDIR/ClearCOSA
        pm clear "com.oplus.cosa" > /dev/null 2>&1 && \
        echo "为避免可能的异常，已为当前用户清空'com.oplus.cosa'的数据"
    fi
    for i in com.oplus.cosa com.oplus.games
    do
        if $(AppStateChecker "n" "$i"); then
            DEnable "e" "$i" > /dev/null 2>&1
            pm clear "$i" > /dev/null 2>&1
            echo
            echo "为避免可能的异常，已为当前用户矫正'$i'的启用状态并清空其数据"
        fi
    done
    echo "矫正检测结束"
}
DealComponents(){
    DEnable "d" "com.oplus.cosa/.gpalibrary.service.GPAService" > /dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.gamemanagersdk.HyperBoostService" > /dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.gamemanagersdk.CosaHyperBoostService" > /dev/null 2>&1
    DEnable "d" "com.oplus.cosa/.oiface.OifaceService" > /dev/null 2>&1
    echo "已关闭应用增强服务组件：俩Hyper GPA OiFace(如果有)"
}
Cleaning(){
    COSA_Database=/data/data/com.oplus.cosa/databases/db_game_database
    sqlite3=$ROOTMODDIR/Bin/sqlite3
    COSAService=com.oplus.cosa/com.oplus.cosa.service.COSAService
    AB_COSA=$CURMODDIR/AB_COSA.txt
    
    echo "【阶段一】启动[应用增强服务]，检测其是否异常，等待数据库创建"
    #1.启动[应用增强服务]，等待5秒以确保检测到其异常时的自行终止
    #  未能启动，报未能启动，采集日志并提示提交模块开发者，报停止处理
    #  成功启动，报成功启动，等待10秒以等待数据库的创建，再检查数据库是否存在：
    #   不存在，报不存在，报停止处理
    #   存在，报存在、将删除其中的[应用性能调度配置表]
    DEnable "e" "$COSAService" > /dev/null 2>&1
    am startservice -n "$COSAService" > /dev/null 2>&1
    sleep 5
    if ! pidof "com.oplus.cosa" > /dev/null 2>&1; then
        echo "未能启动[应用增强服务]，已采集其日志，请提交模块开发者"
        echo "日志位于：'$AB_COSA'"
        echo "停止处理"
        timeout 3 logcat | grep -i "cosa" > "$AB_COSA"
        return 1
    else
        echo "成功启动[应用增强服务]，等待10秒以确保数据库正常创建"
        sleep 10
        if [ ! -f $COSA_Database ]; then
            echo "[应用增强服务]数据库不存在，停止处理"
            return 1
        else
            echo "[应用增强服务]数据库存在，尝试删除其中的[应用性能调度配置表]"
        fi
    fi
    
    echo
    
    echo "【阶段二】删除[应用性能调度配置表]"
    #2.杀死[应用增强服务]和[游戏助手]以彻底关闭数据库保护
    #  再删除[应用增强服务]数据库中的[应用性能调度配置表]
    #  等待sqlite3运行3秒
    am force-stop com.oplus.games
    am force-stop com.oplus.cosa
    $sqlite3 "$COSA_Database" "DROP TABLE IF EXISTS PackageConfigBean;"
    sleep 3
    echo "已尝试删除[应用性能调度配置表]"
    
    echo
    
    echo "【阶段三】启动[应用增强服务]，检测其是否异常，检测[应用性能调度配置表]是否存在"
    #3.复启动[应用增强服务]，等待5秒以确保检测到其异常时的自行终止
    #  未能启动，报未能启动，采集日志并提示提交模块开发者，报停止处理
    #  成功启动，报成功启动，检查[应用性能调度配置表]是否存在：
    #    存在，报未能删除
    #    不存在，报成功删除
    am startservice -n "$COSAService" > /dev/null 2>&1
    sleep 5
    if ! pidof "com.oplus.cosa" > /dev/null 2>&1; then
        echo "未能复启动[应用增强服务]，已采集其日志，请提交模块开发者"
        echo "日志位于：'$AB_COSA'"
        echo "停止处理"
        timeout 3 logcat | grep -i "cosa" > "$AB_COSA"
        return 1
    else
        echo "成功复启动[应用增强服务]，检查[应用性能调度配置表]是否存在："
        if $sqlite3 "$COSA_Database" "SELECT 1 FROM sqlite_master WHERE name='PackageConfigBean';" | grep -q "1"; then
            echo "[应用性能调度配置表]未能删除！！"
        else
            echo "[应用性能调度配置表]成功删除"
        fi
    fi
}


if $(AppStateChecker "i" "com.oplus.cosa")
then
    if $(AppStateChecker "n" "com.oplus.cosa") || $(AppStateChecker "e" "com.oplus.cosa")
    then
        echo -e "\n[应用增强服务]已安装且已启用，开始处理\n"
        echo "<——————————>"
        Rectifying
        echo "<——————————>"
        DealComponents
        echo "<——————————>"
        Cleaning
        echo "<——————————>"
    else
        echo "[应用增强服务]已冻结，不做处理"
    fi
else
    echo "[应用增强服务]未安装，不做处理"
fi







