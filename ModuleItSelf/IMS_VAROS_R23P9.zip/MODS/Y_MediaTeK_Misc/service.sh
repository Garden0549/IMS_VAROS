CURFILE="$0"
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】



#————————————————————————————————————————

PowerHAL(){
    #注意：必须在重启PowerHAL之后再修改后续参数以避免其被重置
    Restart(){
        local SVC1="power-hal-1-0"
        local SVC2="vendor.mtkpower-service.mediatek"
        local SVC3="vendor.mtkpower_applist-default"
        for SVC in "$SVC1" "$SVC2" "$SVC3"; do
            if stop "$SVC" > /dev/null 2>&1; then
                start "$SVC" && echo "『PowerHAL』PowerHAL服务'$SVC'存在，且已重启"
            else
                echo "『PowerHAL』PowerHAL服务'$SVC'不存在"
            fi
        done
    }
    
    if [ $PowerHAL_Conf_AppCfg_Empty = 1 ] || [ $PowerHAL_Conf_Contbl_Empty = 1 ] || [ $PowerHAL_Conf_Scntbl_Empty = 1 ]
    then
        Restart
        echo "『PowerHAL』【已尝试重启PowerHAL进程，以重载已等效清空的PowerHAL配置】"
    else
        echo "『PowerHAL』【没有需要清空的PowerHAL配置，不重启PowerHAL进程】"
    fi
}

#————————————————————————————————————————

FPSGO(){
    local KernelDir="/sys/kernel/fpsgo"
    local ModuleDir="/sys/module/mtk_fpsgo/parameters"
    [ ! -e "$KernelDir" ] || [ ! -e "$ModuleDir" ] && {
        echo "『FPSGO』本设备不存在FPSGO，不做处理"
        return 0
    }
    
    Disable(){
        mask_val 0 $KernelDir/common/force_onoff
        stop fpsgo
        echo "『FPSGO』已关闭FPSGO的全局开关"
        
        if [ -e /sys/kernel/gbe/ ]; then
            mask_val 0 /sys/kernel/gbe/gbe_enable1
            mask_val 0 /sys/kernel/gbe/gbe_enable2
            stop gbe > /dev/null 2>&1
            echo "『FPSGO』已关闭FPSGO外置子模块GBE的全局开关"
        else
            echo "『FPSGO』未找到FPSGO外置子模块GBE，不做处理"
        fi
    }
    CPUFreqControl_Disable(){
        mask_val "0" $KernelDir/fbt/enable_ceiling
        mask_val "0" $KernelDir/fbt/enable_uclamp_boost
        mask_val "0" $KernelDir/fbt/boost_ta
        mask_val "0" $KernelDir/fbt/blc_boost
        mask_val "0" $KernelDir/fbt/enable_switch_cap_margin
        mask_val "0" $KernelDir/fbt/enable_switch_sync_flag
        mask_val "0" $KernelDir/fbt/enable_switch_down_throttle
        mask_val "0" $KernelDir/fbt/engine_cooler_enable
        mask_val "0" $KernelDir/fbt/ultra_rescue
        mask_val "-1" $KernelDir/fbt/fbt_attr_by_pid
        mask_val "-1" $KernelDir/fbt/fbt_attr_by_tid
        
        mask_val "0" $ModuleDir/rescue_second_enable
        mask_val "0" $ModuleDir/rescue_second_g_enable
        mask_val "0" $ModuleDir/cfp_onoff
        mask_val "0" $ModuleDir/variance_control_enable
        mask_val "0" $ModuleDir/loading_enable
        mask_val "0" $ModuleDir/qr_enable
        mask_val "0" $ModuleDir/thrm_enable
        mask_val "0" $ModuleDir/gcc_enable
        mask_val "0" $ModuleDir/boost_LR
    }
    AffinityBoost_Disable(){
        mask_val 0 $KernelDir/fbt/switch_idleprefer
        mask_val 0 $KernelDir/minitop/enable
        mask_val 0 $ModuleDir/boost_affinity
        mask_val 0 /sys/module/fbt_cpu/parameters/boost_affinity
    }


    if [ $FPSGO_Disable = 1 ]
    then
        Disable
    else
        echo "『FPSGO』不关闭FPSGO"
    fi
    
    if [ $FPSGO_CPUFreqControl_Disable = 1 ]
    then
        CPUFreqControl_Disable > /dev/null 2>&1
        echo "『FPSGO』已尝试关闭'CPU频率限制功能'"
    else
        echo "『FPSGO』不关闭'CPU频率限制功能'"
    fi
        
    if [ $FPSGO_AffinityBoost_Disable = 1 ]
    then
        AffinityBoost_Disable > /dev/null 2>&1
        echo "『FPSGO』已尝试关闭'线程放置功能'"
    else
        echo "『FPSGO』不关闭'线程放置功能'"
    fi
}

MAGT(){
    local Dir1="/sys/module/mtk_perf_ioctl_magt/parameters"
    local Dir2=""
    local DirFin=""
    for i in $Dir1 $Dir2
    do
        [ -e "$i" ] && DirFin="$i"
    done
    [ -z "$DirFin" ] && {
        echo "『MAGT』未找到参数目录，不做处理"
        return 1
    }
    
    
    Disable_KernelModule(){
        for i in thermal_aware_threshold fpsdrop_aware_threshold advice_bat_avg_current advice_bat_max_current targetfps_throttling_temp thermal_aware_light_threshold game_suggestion_jobworker
        do
            mask_val "-1" $DirFin/$i
        done
    }

    
    if [ $MAGT_Disable = 1 ]; then
        Disable_KernelModule > /dev/null 2>&1
        echo "『MAGT』已尝试通过修改参数文件［关闭］MAGT"
    else
        echo "『MAGT』不修改MAGT相关的参数文件"
    fi
}

MTK_CoreCtl(){
    mask_val 0 /sys/module/mtk_core_ctl/parameters/policy_enable
    
    for i in /sys/devices/system/cpu/cpu*; do
        [ -f $i/core_ctl/enable ] && {
          lock_val 1 $i/core_ctl/enable
        }
        
        [ -f $i/core_ctl/min_cpus ] && {
          lock_val 99 $i/core_ctl/min_cpus
        }
        
        [ -f $i/core_ctl/max_cpus ] && {
          lock_val 99 $i/core_ctl/max_cpus
        }
        
        [ -f $i/core_ctl/enable ] && {
          lock_val 0 $i/core_ctl/enable
        }
    done
    
    echo "『MTK_CoreCtl』已阻止系统自动关闭CPU核心"
}

GPU(){
    sh $CURMODDIR/GPU.sh
}

OtherCPULimiters(){
    cpudvfs_cpuhvfs(){
        cpudvfs_Dir="/proc/cpudvfs/cpufreq_debug"
        cpuhvfs_Dir="/proc/cpuhvfs/cpufreq_debug"
        for Dir in $cpudvfs_Dir $cpuhvfs_Dir; do
            [ -e "$Dir" ] && {
                for CPUID in $(seq 0 7); do
                    lock_val "$CPUID 1 10000000" $Dir
                done
            }
        done
    }
    powerhal_cpu_ctrl(){
        powerhal_cpu_ctrl_Dir="/proc/powerhal_cpu_ctrl"
        [ -e "$powerhal_cpu_ctrl_Dir" ] && {
            #MT6985及同年平台，不存在adpf_enable
            #MT6989及同年平台，存在sf_hint_low_power_enabled
            #MT6991及及同年或更新平台，不存在sf_hint_low_power_enabled
            [ -e "$powerhal_cpu_ctrl_Dir/adpf_enable" ] && {
                echo 0 > $powerhal_cpu_ctrl_Dir/adpf_enable > /dev/null 2>&1
                if [ -e "$powerhal_cpu_ctrl_Dir/sf_hint_low_power_enabled" ]; then
                    echo "0" > $powerhal_cpu_ctrl_Dir/sf_hint_low_power_enabled
                    echo "1 10000000 1 10000000 1 10000000" > $powerhal_cpu_ctrl_Dir/perfserv_freq
                else
                    for CPUID in $(seq 0 7); do
                        echo "$CPUID 1 10000000" > $powerhal_cpu_ctrl_Dir/perfserv_freq
                    done
                fi
                
                FindMount $powerhal_cpu_ctrl_Dir/perfserv_freq >/dev/null || {
                    mount --bind $powerhal_cpu_ctrl_Dir/adpf_enable $powerhal_cpu_ctrl_Dir/perfserv_freq
                }
            }
        }
    }
    perfmgr(){
        perfmgr_Dir="/proc/perfmgr"
        [ -e "$perfmgr_Dir" ] && {
            FindMount $perfmgr_Dir/perf_ioctl >/dev/null || {
                #考虑到读写失败即无限尝试的特性 和 安全上下文无法恢复，
                #用同目录文件挂载之以避免之
                mount --bind $perfmgr_Dir/xgff_ioctl $perfmgr_Dir/perf_ioctl
            }
        }
    }
    mtk_game(){
        mtk_game_Dir="/sys/module/mtk_game/parameters"
        [ -e "$mtk_game_Dir" ] && {
            mask_val "0" "$mtk_game_Dir/engine_cooler_enable" > /dev/null 2>&1
        }
    }
    MTKSpecThermal(){
        MTKSpecThermal="/sys/kernel/thermal"
        if [ -e "$MTKSpecThermal" ]; then
            mask_val "MAX_TTJ 105000 105000 105000" $MTKSpecThermal/max_ttj
            mask_val "MIN_TTJ 105000" $MTKSpecThermal/min_ttj
            mask_val "TTJ 105000 105000 105000" $MTKSpecThermal/ttj
            mask_val "1" $MTKSpecThermal/sports_mode
            mask_val "1" $MTKSpecThermal/cg_policy_mode > /dev/null 2>&1
        fi
    }
    
    cpudvfs_cpuhvfs
    powerhal_cpu_ctrl
    perfmgr
    mtk_game
    MTKSpecThermal
    
    echo "『OtherCPULimiters』已尝试屏蔽其它内核模块的控制"
}

#————————————————————————————————————————

if [ "$(getprop ro.hardware)" != "qcom" ]
then
    echo -e "\n联发科平台，执行联发科特别屏蔽\n"
    echo "<——————————————————>"
    PowerHAL
    echo "<——————————————————>"
    FPSGO
    echo "<——————————————————>"
    MAGT
    echo "<——————————————————>"
    MTK_CoreCtl
    echo "<——————————————————>"
    GPU
    echo "<——————————————————>"
    OtherCPULimiters
    echo "<——————————————————>"
else
    echo "非联发科平台，不执行联发科特别屏蔽"
fi

#————————————————————————————————————————





