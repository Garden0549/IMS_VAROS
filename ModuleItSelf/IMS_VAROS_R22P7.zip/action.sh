MODFILE="$0"
MODDIR=${MODFILE%/*}
source $MODDIR/MODS/PublicFuncs.sh
source $MODDIR/MODS/ConfigTable.cfg



Main_DealHorae(){
    local Title="①尝试［开启/关闭］Horae进程"
    local Choose_UP="开启"
    local Choose_DOWN="关闭"
    local TimeLimit=""
    
    local HoraeProp=persist.sys.horae.enable
    HoraeChecker(){
        echo "  〔Horae当前状态〕"
        echo "   Horae属性'$HoraeProp'当前值：$(getprop $HoraeProp)"
        if pidof horae > /dev/null 2>&1; then
            echo "   Horae进程已启动，进程PID为'$(pidof horae)'"
        else
            echo "   Horae进程未启动"
        fi
    }
    
    DealHorae(){
        echo "⭕［说明］⭕"
        echo "【1】开启Horae进程的影响："
        echo "      ①去锁帧模块的去锁帧功能失效"
        echo "      ②游戏内温控锁帧严苛"
        echo "【2】关闭Horae进程的可能影响："
        echo "      ①相机对焦或录像帧率异常"
        echo "【3】该功能所做修改，重启失效"
        echo
        HoraeChecker
        echo
        echo "⭕［二次确认］⭕"
        echo "   『$Title』"
        echo "    > [音量 ↑ 键]——[$Choose_UP]"
        echo "    > [音量 ↓ 键]——[$Choose_DOWN]"
        echo "    （若关闭Horae进程无异常，不建议将其开启）"
    
        CASE_DealHorae(){
            if [ -z "$key_click" ]; then
                echo -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    resetprop -n $HoraeProp 1 > /dev/null 2>&1
                    sleep 1
                    start horae > /dev/null 2>&1
                    HoraeChecker
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    resetprop -n $HoraeProp 0 > /dev/null 2>&1
                    sleep 1
                    stop horae > /dev/null 2>&1
                    HoraeChecker
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_DealHorae
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_DealHorae
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_DealHorae" \
                 "跳过" "echo '你选择了[跳过]'"
    else
        DealHorae
    fi
}



Main_GamesCOSA_Uninstallation(){
    local Title="②快速卸载［应用增强服务］和［游戏助手］"
    
    Uninstallation(){
        UInstall "u" "$(am get-current-user)" "com.oplus.games"
        UInstall "u" "$(am get-current-user)" "com.oplus.cosa"
    }
    
    GamesCOSA_Uninstallation(){
        local Choose_UP="卸载"
        local Choose_DOWN="不卸载"
        local TimeLimit=""
    
        echo "⭕［说明］⭕"
        echo "【1】如果卸载，可更彻底地去除官方调度，但也会失去［游戏助手］的所有功能"
        echo
        echo "⭕［二次确认］⭕"
        echo "   『$Title』"
        echo "    > [音量 ↑ 键]——[$Choose_UP]"
        echo "    > [音量 ↓ 键]——[$Choose_DOWN]"
    
        CASE_GamesCOSA_Uninstallation(){
            if [ -z "$key_click" ]; then
                echo -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    Uninstallation
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_GamesCOSA_Uninstallation
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_GamesCOSA_Uninstallation
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_GamesCOSA_Uninstallation" \
                 "跳过" "echo '你选择了[跳过]'"
    else
        GamesCOSA_Uninstallation
    fi
}



Main_GamesCOSA_Reinstallation(){
    local Title="③尝试重新安装［游戏助手］与［应用增强服务］"
    
    Reinstallation(){
        if [ -e /product/app/COSA/COSA.apk ]; then
            if FindMount /product/app/COSA/COSA.apk > /dev/null 2>&1; then
                echo "程序中止，因为［应用增强服务］被其它模块等效彻底删除"
                echo "如果想要继续恢复，请检查此路径指向的模块并关闭之："
                echo "$(FindMount /product/app/COSA/COSA.apk)"
                return 1
            fi
        else
            echo "程序中止，因为系统［应用增强服务］不存在，可能被彻底删除，请排查"
            return 1
        fi
        if [ -e /my_stock/del-app/OplusGames/OplusGames.apk ]; then
            if FindMount /my_stock/del-app/OplusGames/OplusGames.apk > /dev/null 2>&1; then
                echo "程序中止，因为［游戏助手］被其它模块等效彻底删除"
                echo "如果想要继续恢复，请检查此路径指向的模块并关闭之："
                echo "$(FindMount /my_stock/del-app/OplusGames/OplusGames.apk)"
                return 1
            fi
        else
            echo "程序中止，因为系统［游戏助手］不存在，可能被彻底删除，请排查"
            return 1
        fi    
    
        echo "正在重新安装［应用增强服务］和［游戏助手］"
        UInstall "u" "$(am get-current-user)" "com.oplus.games"
        UInstall "u" "$(am get-current-user)" "com.oplus.cosa"
        echo
        UInstall "i" "$(am get-current-user)" "/my_stock/del-app/OplusGames/OplusGames.apk"
        UInstall "ie" "$(am get-current-user)" "com.oplus.games"
        UInstall "ie" "$(am get-current-user)" "com.oplus.cosa"
        echo
        echo "重装结束，若［游戏助手］侧边栏不会自启动，尝试以下提示："
        echo "①检查下列两个文件是否存在，大小是否为0B"
        echo "  若满足上述任一条件，尝试排查并卸载引起问题的模块"
        echo "  【/product/app/COSA/COSA.apk】"
        echo "  【/my_stock/del-app/OplusGames/OplusGames.apk】"
        echo "②如果已安装［隐藏应用列表］，打开'App data 隔离'"
        echo "③恢复使用其它应用对［游戏助手］和［应用增强服务］做的修改"
        echo "  (例如：使用Thanox阻止［应用增强服务］和［游戏助手］后台启动)"
        echo "④重启设备"
    }
    
    GamesCOSA_Reinstallation(){
        local Choose_UP="重新安装"
        local Choose_DOWN="不重新安装"
        local TimeLimit=""
    
        echo "⭕［说明］⭕"
        echo "【1】重新安装时，将卸载现已安装的并安装系统自带的［游戏助手］与［应用增强服务］"
        echo
        echo "⭕［二次确认］⭕"
        echo "   『$Title』"
        echo "    > [音量 ↑ 键]——[$Choose_UP]"
        echo "    > [音量 ↓ 键]——[$Choose_DOWN]"
    
        CASE_GamesCOSA_Reinstallation(){
            if [ -z "$key_click" ]; then
                echo -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    Reinstallation
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_GamesCOSA_Reinstallation
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_GamesCOSA_Reinstallation
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_GamesCOSA_Reinstallation" \
                 "跳过" "echo '你选择了[跳过]'"
    else
        GamesCOSA_Reinstallation
    fi
}



Main_GamesFuncRecover(){
    local Title="④尝试恢复［游戏助手］部分功能"
    
    ModName="D_ColorOS_COSA"
    CusArg="/data/adb/modules/$MOD_ID/MODS/$ModName/customize.sh"
    UniArg="/data/adb/modules/$MOD_ID/MODS/$ModName/uninstall.sh"
    I_Dir=$MODDIR/MODS/
    U_Dir=$MODDIR/UnusedMODS/
    mkdir -p $U_Dir
    
    Uninstall(){
        if [ -d $U_Dir/$ModName ]
        then
            echo "   <<——'$ModName'子模块［已卸载］，退出程序——>>"
            return 1
        else
            echo "<<————开始卸载子模块，请等待————>>"
            sh $I_Dir/$ModName/uninstall.sh "$UniArg"
            mv -f $I_Dir/$ModName $U_Dir
            echo "<<————'$ModName'子模块卸载结束————>>"
        fi
    }
    Install(){
        if [ -d $I_Dir/$ModName ]
        then
            echo "   <<——'$ModName'子模块［已安装］，退出程序——>>"
            return 1
        else
            echo "<<————开始安装子模块，请等待————>>"
            mv -f $U_Dir/$ModName $I_Dir
            sh $I_Dir/$ModName/customize.sh "$CusArg"
            echo "<<————'$ModName'子模块安装结束，重启以恢复其屏蔽效果————>>"
        fi
    }
    
    GamesFuncRecover(){
        local Choose_UP="恢复(卸载子模块)"
        local Choose_DOWN="不恢复(安装子模块)"
        local TimeLimit=""
    
        echo "⭕［说明］⭕"
        echo "【1】[恢复/不恢复]［游戏助手］部分功能的原理，是[卸载/安装]子模块'$ModName'"
        echo "【2】如果卸载子模块'$ModName'，模块将不再处理［应用增强服务］，这会带来如下影响："
        echo "    ①对于'联发科机型'：在使用联发科调度方案的设备上，可能不会影响官调屏蔽效果"
        echo "      在不使用联发科调度方案的设备上，影响同'骁龙机型'↓"
        echo "    ②对于'骁龙机型'：在正常使用［游戏助手］和［应用增强服务］的情况下，将导致无法屏蔽游戏中甚至部分日用的官调"
        echo "    （注：联发科机型中，已知不使用联发科调度方案的有：一加ACE5Ultra）"
        echo
        echo "⭕［二次确认］⭕"
        echo "   『$Title』"
        echo "    > [音量 ↑ 键]——[$Choose_UP]"
        echo "    > [音量 ↓ 键]——[$Choose_DOWN]"
        if [ -d $U_Dir/$ModName ] && [ -d $I_Dir/$ModName ]; then
            echo "【子模块'$ModName'的安装状态异常，建议重装模块。关闭程序...】"
            return 1
        elif [ -d $I_Dir/$ModName ]; then
            echo "   （选[不恢复]可退出程序，当前子模块'$ModName'状态：［已安装］）"
        elif [ -d $U_Dir/$ModName ]; then
            echo "   （选[恢复]可退出程序，当前子模块'$ModName'状态：［已卸载］）"
        fi 
    
        CASE_GamesFuncRecover(){
            if [ -z "$key_click" ]; then
                echo -e "   【选择超时，跳过当前选项】\n"
               return 1
            fi
            case "$key_click" in
                "KEY_VOLUMEUP")
                    echo -e "   【你按下了[音量 ↑ 键]，确认[$Choose_UP]】\n"
                    Uninstall
                    ;;
                "KEY_VOLUMEDOWN")
                    echo -e "   【你按下了[音量 ↓ 键]，确认[$Choose_DOWN]】\n"
                    Install
                    ;;
                *)
                    key_checker "$TimeLeft";CASE_GamesFuncRecover
                    ;;
            esac
        }
        key_checker "$TimeLimit";CASE_GamesFuncRecover
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "查看说明" "Main_GamesFuncRecover" \
                 "跳过" "echo '你选择了[跳过]'"
    else
        GamesFuncRecover
    fi
}



Main_GamesStart(){
    local Title="⑤便捷打开［游戏助手］页面"
    
    GamesStart(){
        if ! AppStateChecker e "com.oplus.games"; then
            echo "  发现［游戏助手］没有安装或启用，无法打开"
            return 1
        fi
        AppStateChecker e "com.oplus.cosa" || echo "注意：［应用增强服务］没有正常启用，这会导致进入游戏时［游戏助手］侧边栏依然不会自启动"
        echo "  5秒后启动游戏助手"
        echo "  -  为避免因程序未结束而极易触发的按键误触，"
        echo "  -  将在游戏助手打开后立即退出模块附加程序"
        sleep 5;am start -n com.oplus.games/business.module.desktop.SoftwareStoreStartActivity;exit
    }
    
    if [ -n "$1" ]; then
        echo "  > $Title"
        key_register "$Title" \
                 "打开" "Main_GamesStart" \
                 "不打开" "echo '你选择了[不打开]'"
    else
        GamesStart
    fi
}

#——————————————————————————————#



echo "——————————————————————————————"
echo "『模块附加程序，具有以下功能：』"
echo
for i in Main_DealHorae Main_GamesCOSA_Uninstallation Main_GamesCOSA_Reinstallation Main_GamesFuncRecover Main_GamesStart
do
    $i "Symbol"
done
echo
echo "————————————————————————————————————————"
echo "『如何操作附加程序：』"
echo
echo "  - 即将执行上述功能前，按下机身上的[非音量键]即可退出附加程序"
echo "  - 按下机身上的[音量 ↑ 键]或[音量 ↓ 键]以执行对应功能"
echo
echo "————————————————————————————————————————"
echo -e "\n\n\n"


echo ">—————————————↓↓↓—————————————<"
echo "  ⭕ 是否【直接退出附加程序】？"
echo "  [音量 ↑ 键]：退出  [音量 ↓ 键]：继续"
echo -e "  （5秒后选择超时，将自动退出附加程序）\n"
ConvenientExport(){
    if [ -z "$key_click" ]; then
        echo "  > 【选择超时，立即退出附加程序】"
        echo -e ">—————————————↑↑↑—————————————<"
        exit
    fi
    case "$key_click" in
        "KEY_VOLUMEUP")
            echo "  > 【你按下了[音量 ↑ 键]，确认[退出]】"
            echo -e ">—————————————↑↑↑—————————————<"
            exit
            ;;
        "KEY_VOLUMEDOWN")
            echo "  > 【你按下了[音量 ↓ 键]，确认[继续]】"
            echo -e ">—————————————↑↑↑—————————————<"
            ;;
        *)
            key_checker "$TimeLeft";ConvenientExport
            ;;
    esac
}
sleep 0.5
key_checker "5";ConvenientExport



echo -e "\n\n\n\n"
echo "［—————————————————————————————————————］"
echo -e "\n\n\n\n"



key_running_full
echo -e "\n\n\n\n\n\n"