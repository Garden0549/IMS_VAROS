
LB_STEP_UltraHigh=2
LB_STEP_UltraLow=1


LB_STEP_FinValue=$(( (LB_STEP_UltraLow << 8) | LB_STEP_UltraHigh ))

echo "LB_STEP_FinValue：$LB_STEP_FinValue"