

FB_MARGIN=550
FB_MARGIN_MinStep=1
FB_MARGIN_MinMargin=50




if [[ ($FB_MARGIN -ge 401 && $FB_MARGIN -le 499) || ($FB_MARGIN -ge 501 && $FB_MARGIN -le 599) ]]; then
    FB_MARGIN_FinValue=$(( FB_MARGIN | (FB_MARGIN_MinStep << 10) | (FB_MARGIN_MinMargin << 16) ))
    echo "FB_MARGIN_FinValue：$FB_MARGIN_FinValue"
fi

