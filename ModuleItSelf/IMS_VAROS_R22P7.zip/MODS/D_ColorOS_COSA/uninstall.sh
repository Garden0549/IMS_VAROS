if [ -n "$1" ]; then
    #解决使用action.sh执行该脚本时"$0（本脚本地址）"异常引起的变量错误问题
    CURFILE="$1"
else
    CURFILE="$0"
fi
CURMODDIR="${CURFILE%/*}"
CURMODDIR_NAME="${CURMODDIR##*/}"
SUBMODDIR="${CURFILE%/*/*}"
ROOTMODDIR="${CURFILE%/*/*/*}"
source $SUBMODDIR/PublicFuncs.sh
source $SUBMODDIR/ConfigTable.cfg
#【脚本公用扩展变量】
# CURFILE——当前脚本地址
# CURMODDIR——当前脚本所处目录地址
# CURMODDIR_NAME——当前脚本所处目录之名
# SUBMODDIR——子模块根目录
# ROOTMODDIR——主模块根目录
#【已引用公共函数和配置表】

#————————————————————————————————————————

Backup_Dir=$CURMODDIR/COSABackup
Backup=$Backup_Dir/GameSchedulingConf.sql
Last_Backup=/data/cache/GameSchedulingConf.sql
COSA_Database_Dir=/data/data/com.oplus.cosa/databases
COSA_Database=$COSA_Database_Dir/db_game_database
sqlite3=$ROOTMODDIR/Bin/sqlite3
new_sqlite3=/data/cache/sqlite3

#————————————————————————————————————————

#此处加入在post-fs-data阶段执行的代码
AtPost(){

    ##向[应用增强服务]的数据库注入应用性能调度配置
    #准备工具和备份
    cp -f $sqlite3 $new_sqlite3
    cp -f $Backup $Last_Backup

}

#————————————————————————————————————————

#此处加入在[进入桌面后]执行的代码
AtService(){
    if [ ! -f $Backup ]; then
        echo "[应用性能调度配置]备份不存在，不执行注入"
        exit
    fi
    
    ReceiverCOSA=com.oplus.cosa/androidx.work.impl.background.systemalarm.RescheduleReceiver
    ReceiverGames=com.oplus.games/androidx.work.impl.background.systemalarm.RescheduleReceiver
    ReceiverIntent=android.intent.action.BOOT_COMPLETED

    #恢复[应用增强服务]被禁用的组件、清除[应用增强服务]和[游戏助手]数据、矫正启用状态，以避免可能的异常
    DEnable "e" "com.oplus.cosa/.gpalibrary.service.GPAService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.HyperBoostService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.gamemanagersdk.CosaHyperBoostService" > /dev/null 2>&1
    DEnable "e" "com.oplus.cosa/.oiface.OifaceService" > /dev/null 2>&1
    echo "已确保开启会被模块关闭的[应用增强服务]组件：俩Hyper GPA OiFace(如果有)"
    for i in com.oplus.cosa com.oplus.games
    do
        if $(AppStateChecker "n" "$i"); then
            DEnable "e" "$i" > /dev/null 2>&1
            pm clear "$i" > /dev/null 2>&1
            echo
            echo "为避免可能的异常，已为当前用户矫正'$i'的启用状态并清空其数据"
        fi
    done
    
    ##向[应用增强服务]的数据库注入应用性能调度配置
    #启动[应用增强服务]和[游戏助手(若已启用)]并等待其运行15秒以确保数据库正常创建
    DEnable "e" "$ReceiverCOSA" > /dev/null 2>&1
    am broadcast -a $ReceiverIntent -n $ReceiverCOSA > /dev/null 2>&1
    sleep 1
    if ps -A | grep "com.oplus.cosa" > /dev/null 2>&1; then
        echo "成功启动[应用增强服务]"
    else
        echo "未能启动[应用增强服务]，停止处理"
        return 1
    fi
    if $(AppStateChecker "e" "com.oplus.games"); then
        DEnable "e" "$ReceiverGames" > /dev/null 2>&1
        am broadcast -a $ReceiverIntent -n $ReceiverGames > /dev/null 2>&1
        sleep 1
        if ps -A | grep "com.oplus.games" > /dev/null 2>&1; then
            echo "成功启动[游戏助手]"
        else
            echo "未能启动[游戏助手]"
        fi
    fi
    echo "等待[应用增强服务]数据库构建中";sleep 15
    
    #杀死[应用增强服务]和[游戏助手]以关闭数据库保护，注入应用性能调度配置并清理残留
    am force-stop com.oplus.games
    am force-stop com.oplus.cosa
    $new_sqlite3 "$COSA_Database" "DROP TABLE IF EXISTS PackageConfigBean;"
    $new_sqlite3 $COSA_Database < $Last_Backup
    rm -rf $Last_Backup $new_sqlite3
    
    #重启动[应用增强服务]和[游戏助手(若已启用)]以避免未知异常
    am broadcast -a $ReceiverIntent -n $ReceiverCOSA > /dev/null 2>&1
    sleep 1
    if ps -A | grep "com.oplus.cosa" > /dev/null 2>&1; then
        echo "成功复启动[应用增强服务]"
    else
        echo "未能复启动[应用增强服务]"
    fi
    if $(AppStateChecker "e" "com.oplus.games"); then
        am broadcast -a $ReceiverIntent -n $ReceiverGames > /dev/null 2>&1
        sleep 1
        if ps -A | grep "com.oplus.games" > /dev/null 2>&1; then
            echo "成功复启动[游戏助手]"
        else
            echo "未能复启动[游戏助手]"
        fi
    fi
    
    #检查[应用性能调度配置表]是否已恢复
    if $sqlite3 "$COSA_Database" "SELECT 1 FROM sqlite_master WHERE name='PackageConfigBean';" | grep -q "1"; then
        echo "[应用性能调度配置表]已恢复"
    else
        echo "[应用性能调度配置表]未恢复"
    fi
}

#————————————————————————————————————————


AtPost
if [ -n "$1" ]; then
    if $(AppStateChecker "e" "com.oplus.cosa"); then
        echo "[应用增强服务]已安装且已启用，开始处理"
        AtService
    else
        echo "[应用增强服务]未安装或未启用，不做处理"
    fi
else
    {
        wait_until_login;sleep 60
        AtService
    } &
fi












